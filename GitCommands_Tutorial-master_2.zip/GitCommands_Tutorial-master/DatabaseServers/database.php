<?php

/* for shell scripts "EXPORT USE_PRODUCTION_DB=1;" will force prod to be used for db */
if((strstr($_SERVER['HTTP_HOST'], '.local') && empty($_SERVER['USE_PRODUCTION_DB']))
    || (php_sapi_name() == 'cli' && (gethostname() == 'simplevagrant' && empty($_SERVER['USE_PRODUCTION_DB'])))) {
        include("database-local.php");
}else if(strstr($_SERVER['HTTP_HOST'], 'jenkins.simpletire.com')){
    include("database-devdb.php");
}else{
    include("database-prod.php");
}
