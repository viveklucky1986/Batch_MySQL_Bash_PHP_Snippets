<?php

class DATABASE_CONFIG {
    var $xd = array(
        'driver' => 'mysql',
        'persistent' => false,
        'host' => 'staging.cluster-c0zzuvbvffka.us-west-2.rds.amazonaws.com',
        'login' => 'root',
        'password' => 't1r3s123',
        'database' => 'tirexd',
        'prefix' => ''
    );
    var $ftp = array(
        'driver' => 'mysql',
        'persistent' => false,
        'host' => 'ec2-52-25-125-67.us-west-2.compute.amazonaws.com',
        'login' => 'tpxd',
        'password' => '4nF2BAzRrwZGX2wG',
        'database' => 'simpleinv',
        'prefix' => '',
    );
    var $tcsparts = array(
        'driver' => 'mysql',
        'persistent' => false,
        'host' => 'staging.cluster-c0zzuvbvffka.us-west-2.rds.amazonaws.com',
        'login' => 'root',
        'password' => 't1r3s123',
        'database' => 'tcsparts',
        'prefix' => ''
    );
    var $tireguide = array(
        'driver' => 'mysql',
        'persistent' => false,
        'host' => 'staging.cluster-c0zzuvbvffka.us-west-2.rds.amazonaws.com',
        'login' => 'root',
        'password' => 't1r3s123',
        'database' => 'TireGuide',
        'prefix' => ''
    );
    var $tireguide_combined = array(
        'driver' => 'mysql',
        'persistent' => false,
        'host' => 'staging.cluster-c0zzuvbvffka.us-west-2.rds.amazonaws.com',
        'login' => 'root',
        'password' => 't1r3s123',
        'database' => 'tireguide_combined',
        'prefix' => ''
    );
    var $tgp = array(
        'driver' => 'mysql',
        'persistent' => false,
        'host' => 'staging.cluster-c0zzuvbvffka.us-west-2.rds.amazonaws.com',
        'login' => 'root',
        'password' => 't1r3s123',
        'database' => 'tgp',
        'prefix' => ''
    );
    var $default = array(
        'driver' => 'mysql',
        'persistent' => false,
        'host' => 'staging.cluster-c0zzuvbvffka.us-west-2.rds.amazonaws.com',
        'login' => 'root',
        'password' => 't1r3s123',
        'database' => 'rpm_simpletire',
        'prefix' => ''
    );
}