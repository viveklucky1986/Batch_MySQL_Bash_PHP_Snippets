### Composer Update a specific Repository and Install the changes:
```bash
composer update [RepoName] && composer install
composer update simpletire/common && composer install
```

### Install Composer PHP Version in Webroot ###
```bash
#!C:\Progra~1\Git\usr\bin\bash.exe

# Please make sure "extension=php_openssl.dll" is uncommented in php.ini used by CLI
# Set your windows PHP path in below variable
php="C:/Webroot/php5633/php.exe"
$php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
$php -r "if (hash_file('SHA384', 'composer-setup.php') === '544e09ee996cdf60ece3804abc52599c22b1f40f4323403c44d44fdfdd586475ca9813a858088ffbc1f233e9b180f061') { echo 'Installer verified'; } else { echo 'Installer corrupt'; unlink('composer-setup.php'); } echo PHP_EOL;"
$php composer-setup.php
$php -r "unlink('composer-setup.php');"
$php -r "copy('composer.phar', 'composer_bak.phar');"
```
#### Or ####
```bash
#!C:\Progra~1\Git\usr\bin\bash.exe

# Please make sure "extension=php_openssl.dll" is uncommented in php.ini used by CLI
# Set your windows PHP path in below variable
# php="C:/Webroot/php5633/php.exe"
php="C:\Webroot\php5633\php.exe"
$php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
$php -r "if (hash_file('SHA384', 'composer-setup.php') === '544e09ee996cdf60ece3804abc52599c22b1f40f4323403c44d44fdfdd586475ca9813a858088ffbc1f233e9b180f061') { echo 'Installer verified'; } else { echo 'Installer corrupt'; unlink('composer-setup.php'); } echo PHP_EOL;"
$php composer-setup.php
$php -r "unlink('composer-setup.php');"
$php -r "copy('composer.phar', 'composer_bak.phar');"
```
#### Or ####
```bash
#!C:\Progra~1\Git\usr\bin\bash.exe

# Please make sure "extension=php_openssl.dll" is uncommented in php.ini used by CLI
# Set your windows PHP path in below variable
php="C:\Webroot\php5633\php.exe"
$php -r "readfile('https://getcomposer.org/installer');" | $php
$php -r "copy('composer.phar', 'composer_bak.phar');"
```
