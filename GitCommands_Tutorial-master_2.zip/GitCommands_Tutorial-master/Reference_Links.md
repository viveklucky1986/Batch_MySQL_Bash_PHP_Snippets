### MySQL Documentation: ###
<a href="https://dev.mysql.com/doc/refman/5.7/en/columns-table.html" target="new">MySQL Columns Table</a>  
