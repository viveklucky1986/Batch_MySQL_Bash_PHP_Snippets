#### Show message on any page that has controller-action dedicated to it and redirect it elsewhere ####
```php
$this->Session->setFlash('[Message to display]');
$this->redirect('[Redirect_relative_url_path]');
$this->Session->setFlash('Group Management is now done via the Back Office.');
$this->redirect('/MyInstallers');
```
