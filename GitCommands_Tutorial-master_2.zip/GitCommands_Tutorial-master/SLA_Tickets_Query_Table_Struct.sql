-- Queries that need to be run to finally finish the SIM-4744 ticket where I have to change the Table structure as some field types are different and re-insert the data.

DROP TABLE IF EXISTS my_distributors_warehouses_slascore;

CREATE TABLE `my_distributors_warehouses_slascore` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `WHid` int(11) DEFAULT NULL,
  `Warehouse` varchar(100) DEFAULT NULL,
  `CreatedYear` year(4) DEFAULT NULL,
  `CreatedMonth` tinyint(3) DEFAULT NULL,
  `CostAccur` decimal(5,2) DEFAULT NULL,
  `QtyAccur` decimal(5,2) DEFAULT NULL,
  `DOTAccur` decimal(5,2) DEFAULT NULL,
  `TireAccur` decimal(5,2) DEFAULT NULL,
  `NoDefectAccur` decimal(5,2)  DEFAULT NULL,
  `OnTimeAccur` decimal(5,2) DEFAULT NULL,
  `InventoryWeight` decimal(5,2) DEFAULT NULL,
  `ShippingWeight` decimal(5,2) DEFAULT NULL,
  `Grade` decimal(5,2) DEFAULT NULL,
  `CostAccurPerc` float  DEFAULT NULL,
  `QtyAccurPerc` float  DEFAULT NULL,
  `DOTAccurPerc` float  DEFAULT NULL,
  `TireAccurPerc` float  DEFAULT NULL,
  `NoDefectAccurPerc` float  DEFAULT NULL,
  `OnTimeAccurPerc` float  DEFAULT NULL,
  `WHSales` decimal(10,2) DEFAULT NULL,
  `TotalSales` decimal(10,2) DEFAULT NULL,
  `PercSales` float DEFAULT NULL,
  `Quantity` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

SHOW CREATE TABLE my_distributors_warehouses_slascore;

-- Query to re-insert the data into table "my_distributors_warehouses_slascore" with the updated select query as part of main Insert Query

INSERT INTO my_distributors_warehouses_slascore (
  WHid,
  Warehouse,
  CreatedYear,
  CreatedMonth,
  CostAccur,
  QtyAccur,
  DOTAccur,
  TireAccur,
  NoDefectAccur,
  OnTimeAccur,
  InventoryWeight,
  ShippingWeight,
  Grade,
  CostAccurPerc,
  QtyAccurPerc,
  DOTAccurPerc,
  TireAccurPerc,
  NoDefectAccurPerc,
  OnTimeAccurPerc,
  WHSales,
  TotalSales,
  PercSales,
  Quantity
) 
SELECT 
    a1.*,
    ROUND((CostAccur / 57), 2) AS CostAccurPerc,
    ROUND((QtyAccur / 38), 2) AS QtyAccurPerc,
    ROUND((DOTAccur / 5), 2) AS DOTAccurPerc,
    ROUND((TireAccur / 12), 2) AS TireAccurPerc,
    ROUND((NoDefectAccur), 2) AS NoDefectAccurPerc,
    ROUND((OnTimeAccur / 88), 2) AS OnTimeAccurPerc,
    b1.WHSales,
    b1.TotalSales,
    b1.Perc AS PercSales,
    b1.Quantity
FROM
    (SELECT WHid,
        Warehouse,
            CreatedYear,
            CreatedMonth,
            SUM(CostAccur) CostAccur,
            SUM(QtyAccur) QtyAccur,
            SUM(DOTAccur) DOTAccur,
            SUM(TireAccur) TireAccur,
            SUM(NoDefectAccur) NoDefectAccur,
            SUM(OnTimeAccur) OnTimeAccur,
            ROUND(SUM(InventoryWeight), 2) InventoryWeight,
            ROUND(SUM(ShippingWeight), 2) ShippingWeight,
            SUM(Grade) Grade
    FROM
        (SELECT WHid,
        Warehouse,
            CreatedYear,
            CreatedMonth,
            (TotalOrders),
            TotalReasonOrders,
            Perc,
            Cat,
            CostAccur,
            QtyAccur,
            DOTAccur,
            TireAccur,
            NoDefectAccur,
            OnTimeAccur,
            ((CostAccur + QtyAccur + DOTAccur) * 0.26) AS InventoryWeight,
            ((TireAccur + NoDefectAccur + OnTimeAccur) * 0.74) AS ShippingWeight,
            ROUND((((CostAccur + QtyAccur + DOTAccur) * 0.26) + ((TireAccur + NoDefectAccur + OnTimeAccur) * 0.74)), 2) AS Grade
    FROM
        (SELECT WHid,
        Warehouse,
            CreatedYear,
            CreatedMonth,
            Reason,
            TotalOrders,
            TotalReasonOrders,
            Perc,
            Cat,
            IFNULL(CASE
                WHEN Cat = 'CS' AND Rid = 3 THEN ROUND((Perc * 0.57), 2)
            END, 0) AS CostAccur,
            IFNULL(CASE
                WHEN Cat = 'CS' AND Rid = 4 THEN ROUND((Perc * 0.38), 2)
            END, 0) AS QtyAccur,
            IFNULL(CASE
                WHEN Cat = 'CS' AND Rid = 2 THEN ROUND((Perc * 0.05), 2)
            END, 0) AS DOTAccur,
            IFNULL(CASE
                WHEN Cat = 'Return' AND Rid = 4 THEN ROUND((Perc * 0.12), 2)
            END, 0) AS TireAccur,
            IFNULL(CASE
                WHEN Cat = 'Return' AND Rid = 6 THEN ROUND((Perc * 0), 2)
            END, 0) AS NoDefectAccur,
            IFNULL(CASE
                WHEN Cat = 'OnTime' THEN ROUND((Perc * 0.88), 2)
            END, 0) AS OnTimeAccur
    FROM
        (SELECT WHid,
        Warehouse,
            CreatedYear,
            CreatedMonth,
            Reason,
            TotalOrders,
            TotalReasonOrders,
            Perc,
            Cat,
            Rid
    FROM
        (SELECT 
        t1.WHid,
        t1.Warehouse,
            t1.CreatedYear,
            t1.CreatedMonth,
            t1.Reason,
            (t1.TotalOrders + IFNULL(t3.TotalCSOrders, 0)) AS TotalOrders,
            IFNULL(t2.TotalReasonOrders, 0) AS TotalReasonOrders,
            (100 - (ROUND((100 * (IFNULL(t2.TotalReasonOrders, 0) / (t1.TotalOrders + IFNULL(t3.TotalCSOrders, 0)))), 2))) AS Perc,
            'CS' AS Cat,
            t1.Rid
    FROM
        (SELECT 
        WHid,
            Warehouse,
            CreatedYear,
            CreatedMonth,
            r.id AS Rid,
            reason_message AS Reason,
            OrderId AS TotalOrders
    FROM
        (SELECT DISTINCT
        mdw.id AS WHid,
            mdw.name AS Warehouse,
            YEAR(mo.created) AS CreatedYear,
            MONTH(mo.created) AS CreatedMonth,
            COUNT(DISTINCT mo.id) AS OrderId
    FROM
        my_orders mo
    LEFT JOIN my_distributors_warehouses_orders mdwo ON mdwo.my_order_id = mo.id
    LEFT JOIN my_distributors_warehouses mdw ON mdwo.warehouse_id = mdw.id
    WHERE
        mdw.name IS NOT NULL
            AND YEAR(mo.created) > 2016
            AND mdw.deleted = 0
    GROUP BY mdw.id , mdw.name , YEAR(mo.created) , MONTH(mo.created)) i
    CROSS JOIN my_order_cannot_ship_reasons r) t1
    LEFT JOIN (SELECT 
        YEAR(mo.created) AS CreatedYear,
            MONTH(mo.created) AS CreatedMonth,
            mol.original_value AS Warehouse,
            mcsr.reason_message AS Reason,
            COUNT(DISTINCT mo.id) AS TotalReasonOrders,
            mcsr.id AS Rid
    FROM
        my_order_history_logs mol
    INNER JOIN my_orders mo ON mo.id = mol.order_id
    LEFT JOIN my_order_cannot_ship_reasons mcsr ON mol.ref_id = mcsr.id
    WHERE
        mol.log_type_id = 39
            AND YEAR(mo.created) > 2016
            AND mol.original_value IS NOT NULL
    GROUP BY YEAR(mo.created) , MONTH(mo.created) , Warehouse , Reason , mcsr.id) t2 ON t1.Warehouse = t2.Warehouse
        AND t1.CreatedYear = t2.CreatedYear
        AND t1.CreatedMonth = t2.CreatedMonth
        AND t1.Rid = t2.Rid
    LEFT JOIN (SELECT 
        YEAR(mo.created) AS CreatedYear,
            MONTH(mo.created) AS CreatedMonth,
            mol.original_value AS Warehouse,
            COUNT(DISTINCT mol.id) AS TotalCSOrders
    FROM
        my_order_history_logs mol
    INNER JOIN my_orders mo ON mo.id = mol.order_id
    WHERE
        mol.log_type_id = 39
            AND YEAR(mo.created) > 2016
            AND mol.original_value IS NOT NULL
    GROUP BY YEAR(mo.created) , MONTH(mo.created) , mol.original_value) t3 ON t1.CreatedYear = t3.createdYear
        AND t1.CreatedMonth = t3.CreatedMonth
        AND t1.Warehouse = t3.Warehouse
    WHERE
        t1.Rid IN (2 , 3, 4)) cs 
        
        UNION (SELECT 
        t1.WHid,
            t1.Warehouse,
            t1.CreatedYear,
            t1.CreatedMonth,
            t1.title AS Reason,
            t1.TotalOrders,
            IFNULL(t2.ReturnedOrders, 0) AS ReturneReasonOrders,
            (100 - (ROUND((100 * (IFNULL(t2.ReturnedOrders, 0) / t1.TotalOrders)), 2))) AS Perc,
            'Return' AS Cat,
            t1.Rid
    FROM
        (SELECT 
        WHid,
            Warehouse,
            CreatedYear,
            CreatedMonth,
            r.id AS Rid,
            title,
            OrderId AS TotalOrders
    FROM
        (SELECT DISTINCT
        mdw.id AS WHid,
            mdw.name AS Warehouse,
            YEAR(mo.created) AS CreatedYear,
            MONTH(mo.created) AS CreatedMonth,
            COUNT(DISTINCT mo.id) AS OrderId
    FROM
        my_orders mo
    LEFT JOIN my_distributors_warehouses_orders mdwo ON (mdwo.my_order_id = mo.id)
    LEFT JOIN my_distributors_warehouses mdw ON (mdw.id = mdwo.warehouse_id)
    WHERE
        YEAR(mo.created) > 2016
            AND mdw.name IS NOT NULL
            AND mdw.deleted = 0
    GROUP BY mdw.id , mdw.name , YEAR(mo.created) , MONTH(mo.created)) i
    CROSS JOIN my_order_return_reasons r) t1
    LEFT JOIN (SELECT 
        WHid,
            Warehouse,
            CreatedYear,
            CreatedMonth,
            Rid,
            title,
            COUNT(DISTINCT orderid) AS TotalOrders,
            COUNT(DISTINCT returnorderid) AS ReturnedOrders
    FROM
        (SELECT 
        mdw.id AS WHid,
            mdw.name AS Warehouse,
            mdwo.my_order_return_reason_id,
            mors.title,
            mors.id AS Rid,
            mo.id AS orderid,
            CASE
                WHEN mohl.order_id IS NOT NULL THEN mo.id
            END AS returnorderid,
            YEAR(mo.created) AS CreatedYear,
            MONTH(mo.created) AS CreatedMonth
    FROM
        my_orders mo
    LEFT JOIN my_distributors_warehouses_orders mdwo ON (mdwo.my_order_id = mo.id)
    LEFT JOIN my_order_return_reasons mors ON (mors.id = mdwo.my_order_return_reason_id)
    LEFT JOIN my_distributors_warehouses mdw ON (mdw.id = mdwo.warehouse_id)
    LEFT JOIN (SELECT 
        order_id, my_distributors_warehouses_order_id
    FROM
        my_order_history_logs
    WHERE
        log_type_id = 16) mohl ON mohl.order_id = mo.id
        AND mohl.my_distributors_warehouses_order_id = mdwo.id
    WHERE
        mo.created IS NOT NULL
            AND mdw.name IS NOT NULL
            AND YEAR(mo.created) > 2016) t
    GROUP BY CreatedYear , CreatedMonth , Warehouse , my_order_return_reason_id) t2 ON t1.Warehouse = t2.Warehouse
        AND t1.CreatedYear = t2.CreatedYear
        AND t1.CreatedMonth = t2.CreatedMonth
        AND t1.Rid = t2.Rid
    WHERE
        t1.Rid IN (4 , 6)) 
        
        UNION (SELECT WHid,
        Warehouse,
            CreatedYear,
            CreatedMonth,
            'OnTimeShipped' AS Reason,
            COUNT(DISTINCT OrderId) TotalOrders,
            COUNT(DISTINCT OnTimeOrderId) AS OnTimeOrders,
            ROUND((100 * (COUNT(DISTINCT OnTimeOrderId) / COUNT(DISTINCT OrderId))), 2) AS Perc,
            'OnTime' AS Cat,
            0 AS Rid
    FROM
        (SELECT WHid,
        Warehouse,
            CreatedYear,
            CreatedMonth,
            OrderId,
            IF(required_ship_date >= DATE_FORMAT(CONVERT_TZ(ActualShipDate, 'UTC', TimeZone), '%Y-%m-%d'), 1, 0) AS ShippedOnTime,
            IF(required_ship_date >= DATE_FORMAT(CONVERT_TZ(ActualShipDate, 'UTC', TimeZone), '%Y-%m-%d'), OrderId, NULL) AS OnTimeOrderId
    FROM
        (SELECT 
        mdw.id as WHid,
        mdw.name AS Warehouse,
            YEAR(mo.created) CreatedYear,
            MONTH(mo.created) CreatedMonth,
            mo.id AS OrderId,
            mdwo.required_ship_date,
            IF(mdwo.warehouse_delivers = 1, mdwo.delivery_date, mdwo.fulfill_shipped_at) AS ActualShipDate,
            IF(IF(IFNULL(mdw.time_zone, '') IN ('' , '0'), z.timezone, mdw.time_zone) = '', 'America/New_York', IF(IFNULL(mdw.time_zone, '') IN ('' , '0'), z.timezone, mdw.time_zone)) AS TimeZone
    FROM
        my_orders mo
    LEFT JOIN my_distributors_warehouses_orders mdwo ON mdwo.my_order_id = mo.id
    LEFT JOIN my_distributors_warehouses mdw ON mdwo.warehouse_id = mdw.id
    LEFT JOIN zips z ON z.zip = mdw.zip
    WHERE
        mo.status IN ('Shipped' , 'Completed')
            AND mdw.name IS NOT NULL
            AND mo.created IS NOT NULL
            AND mdw.deleted = 0
            AND YEAR(mo.created) > 2016) t) a
    GROUP BY Warehouse , CreatedYear , CreatedMonth)) a) b) c
    GROUP BY Warehouse , CreatedYear , CreatedMonth) a1
        LEFT JOIN
    (SELECT 
        a.CreatedYear,
            a.CreatedMonth,
            a.Warehouse,
            a.Sales AS WHSales,
            b.TotalSales,
            ((a.Sales / b.TotalSales)) AS Perc,
            Quantity
    FROM
        (SELECT 
        YEAR(mo.created) AS CreatedYear,
            MONTH(mo.created) AS CreatedMonth,
            mdw.name AS Warehouse,
            SUM(mop.price * mdwop.quantity) AS Sales,
            SUM(mdwop.quantity) AS Quantity
    FROM
        my_orders mo
    LEFT JOIN my_distributors_warehouses_orders mdwo ON mdwo.my_order_id = mo.id
    LEFT JOIN my_order_products mop ON mop.my_order_id = mo.id
    CROSS JOIN my_distributors_warehouses_orders_products mdwop ON mop.id = mdwop.my_order_product_id
        AND mdwo.id = mdwop.my_distributors_warehouses_order_id
    LEFT JOIN my_distributors_warehouses mdw ON mdwo.warehouse_id = mdw.id
    WHERE
        mdw.name IS NOT NULL
            AND YEAR(mo.created) > 2016
            AND mdw.deleted = 0
    GROUP BY CreatedYear , CreatedMonth , Warehouse) a
    LEFT JOIN (SELECT 
        YEAR(mo.created) AS CreatedYear,
            MONTH(mo.created) AS CreatedMonth,
            SUM(mop.price * mdwop.quantity) AS TotalSales
    FROM
        my_orders mo
    LEFT JOIN my_distributors_warehouses_orders mdwo ON mdwo.my_order_id = mo.id
    LEFT JOIN my_order_products mop ON mop.my_order_id = mo.id
    CROSS JOIN my_distributors_warehouses_orders_products mdwop ON mop.id = mdwop.my_order_product_id
        AND mdwo.id = mdwop.my_distributors_warehouses_order_id
    LEFT JOIN my_distributors_warehouses mdw ON mdwo.warehouse_id = mdw.id
    WHERE
        YEAR(mo.created) > 2016
            AND mdw.deleted = 0
            AND mdw.name IS NOT NULL
    GROUP BY CreatedYear , CreatedMonth) b ON a.CreatedYear = b.CreatedYear
        AND a.CreatedMonth = b.CreatedMonth
    ORDER BY a.Warehouse ASC) b1 ON a1.CreatedYear = b1.CreatedYear
        AND a1.CreatedMonth = b1.CreatedMonth
        AND a1.Warehouse = b1.Warehouse
ORDER BY a1.Warehouse;

-- Query to check and verify the data since Jan 2017

SELECT * FROM my_distributors_warehouses_slascore;
