#!/bin/bash -i
## Open this file with following commands:
## start notepad++.exe "$EXEPATH\etc\profile.d\aliases.sh"
## start notepad++.exe "C:\Program Files\Git\etc\profile.d\aliases.sh"

# Some good standards, which are not used if the user
# creates his/her own .bashrc/.bash_profile

export USERFOLDER="/c/Users/WMIND2004/"
export PROJECTSDIR="$USERFOLDER/Projects/simple"
export GIT_INSTALL_DIR="C:\Program Files\Git"
export GIT_PROFILE_DIR="$GIT_INSTALL_DIR\etc\profile.d"

COMMITMSG=
setCommitMessage() {
    read -e -p "Commit message: " COMMITMSG
}
appendToEnvPath() {
    read -e -p "Path to append: " DirPath
    # PATH=$PATH:$DirPath
    PATH="$PATH:$DirPath"
}
declarePHP7Path() {
    read -e -p "PHP7 Executable Path upto Parent Directory: " Php7Path
    export PHP7DIR=$Php7Path
}
declarePHP5Path() {
    read -e -p "PHP5 Executable Path upto Parent Directory: " Php5Path
    export PHP5DIR=$Php5Path
}

# --show-control-chars: help showing Korean or accented characters
alias ls='ls -F --color=auto --show-control-chars'
alias ll='ls -l'
alias purgehist='history -cw && reset && clear && history -cw'
alias purgehist2='history -cw && reset && clear && history -cw && cat /dev/null > ~/.bash_history && rm ~/.bash_history'
alias purgehist3='history -cw && \
        reset && clear && history -cw && \
        cat /dev/null > ~/.bash_history && \
        rm ~/.bash_history'
alias gstat='git status'
alias gpll='read -e -p "Branch Id: " branchId && git pull origin && git pull origin $branchId && git pull origin HEAD'
alias gpll_full='read -e -p "Branch Id: " branchId && git pull && git pull origin && git pull origin $branchId && git pull origin HEAD'
alias gpll_total='read -e -p "Branch Id: " branchId && git pull && git pull origin && git pull origin $branchId && git pull origin HEAD'
alias gpll_complete='read -e -p "Branch Id: " branchId && git pull && git pull origin && git pull origin $branchId && git pull origin HEAD'
alias gpsh='git push origin'
alias gmov='git merge -X theirs master'
alias gcln='git clean -fd'
alias gituploadmods='read -e -p "Commit message: " commit_note && git commit -am "$commit_note" && git push origin HEAD'
alias gcb='read -e -p "Branch Id: " branchId && git checkout $branchId'
alias gpm_master='read -e -p "Branch Id: " branchId && git checkout $branchId && git pull origin master && git merge master'
alias SIMPLETIREPROJ='cd ~/Projects/simple'
alias openAliasFile='start notepad++.exe "$GIT_PROFILE_DIR\aliases.sh"'
alias setBranchTrack='read -e -p "Branch Id: " branchId && git branch --set-upstream-to="origin/$branchId" "$branchId"'
alias simplevagssh='cd "$PROJECTSDIR/simplevagrant" && ssh -F ~/simplevagrant-ssh master'
alias switchToRepo='read -e -p "Last Directory in Path: " folderName && cd "$PROJECTSDIR/$folderName"'
alias gzipdir='read -e -p "Folder to compress: " dirName && export GZIP=-9 && tar cvzf "$dirName.tgz" "$dirName"'
alias bakallfilesup='mkdir -p _baks_/"$(date +%Y-%m-%d_%H:%M:%S)" && cp -r *.* ./_baks_/"$(date +%Y-%m-%d_%H:%M:%S)"/'
alias bakallphpfilesup='mkdir -p _baks_/"$(date +%Y-%m-%d_%H:%M:%S)" && cp -r *.{php,ctp,phtml,phps} ./_baks_/"$(date +%Y-%m-%d_%H:%M:%S)"/'
alias openBOVendorCommon='start explorer $HOME/Projects/simple/backoffice/vendor/simpletire/common'
alias openBOVendorCommon2='cd $HOME/Projects/simple/backoffice/vendor/simpletire/common && start .'
alias openST3SnippetsFolder='start explorer "%AppData%\Sublime Text 3\Packages\User"'
alias openST3SnipsFldr='start explorer "%AppData%\Sublime Text 3\Packages\User"'
alias 'subl="/c/Program Files/Sublime Text 3/subl.exe"'
alias openGitConfigFile='subl $HOME/.gitconfig'

bakmultifilesup() {
    read -e -p "Comma separated list of filenames: " fileNameCs
    currDir=$(pwd)
    mkdir -p "$currDir/_baks_"
    for fileName in $(echo $fileNameCs | sed "s/,/ /g")
    do
        cp "$fileName" "_baks_/$fileName.bak.$(date +%Y%m%d-%H%M%S)"
    done
}

git_pull_merge_master() {
    read -e -p "Branch Id: " branchId
    git pull
    git pull origin
    git pull origin $branchId
    git pull origin HEAD
    git checkout master
    git pull origin
    git checkout $branchId
    git merge master
}

git_pull_total() {
    read -e -p "Branch Id: " branchId
    git pull
    # git pull --all
    git pull origin
    git pull origin $branchId
    git pull origin HEAD
}

git_pull_full() {
    read -e -p "Branch Id: " branchId
    git pull
    # git pull --all
    git pull origin
    git pull origin $branchId
    git pull origin HEAD
}

git_pull_complete() {
    read -e -p "Branch Id: " branchId
    git pull
    # git pull --all
    git pull origin
    git pull origin $branchId
    git pull origin HEAD
}

git_merge_master_multirepos() {
    currPath=$(pwd)
    read -e -p "Branch Id: " branchId
    read -e -p "Comma separated repo-folders list: " foldersRepoGPull
    for fldRepoName in $(echo $foldersRepoGPull | sed "s/,/ /g")
    do
        cd "$HOME/Projects/simple/$fldRepoName"
        echo "Now inside $HOME/Projects/simple/$fldRepoName"
        git checkout $branchId
        git pull origin master
        git merge master
    done
    cd $currPath
}

bakdirup() {
    #!/bin/bash
    read -e -p "Folder to backup: " dirName
    nowTimeSt=`date '+%Y-%m-%d_%H:%M:%S'`
    mkdir -p "$(pwd)/_baks_/$nowTimeSt"
    cp -avr $(pwd)/$dirName "$(pwd)/_baks_/$nowTimeSt"
}

gpll_multirepos() {
    currPath=$(pwd)
    read -e -p "Comma separated repo-folders list: " foldersGPull
    for fldName in $(echo $foldersGPull | sed "s/,/ /g")
    do
        cd "$PROJECTSDIR/$fldName"
        echo "Now inside $PROJECTSDIR/$fldName"
        # cd "$HOME/Projects/simple/$fldName"
        # echo "Now inside $HOME/Projects/simple/$fldName"
        git pull && git pull origin
    done
    cd $currPath
}

gstat_multirepos() {
    currPath=$(pwd)
    read -e -p "Comma separated repo-folders list: " foldersGPull
    for fldName in $(echo $foldersGPull | sed "s/,/ /g")
    do
        cd "$HOME/Projects/simple/$fldName"
        echo "Now inside $HOME/Projects/simple/$fldName"
        git status
    done
    cd $currPath
}

gstat_allrepos() {
    currPath=$(pwd)
    foldersRepoGPull='api,backend,backoffice,common,devdb,frontend,inventory,simplevagrant,supplier,staging-tools,wholesale'
    for fldRepoName in $(echo $foldersRepoGPull | sed "s/,/ /g")
    do
        cd "$HOME/Projects/simple/$fldRepoName"
        echo "Now inside $HOME/Projects/simple/$fldRepoName"
        git status
    done
    cd $currPath
}

gpll_allrepos() {
    currPath=$(pwd)
    foldersRepoGPull='api,backend,backoffice,common,devdb,frontend,inventory,simplevagrant,supplier,staging-tools,wholesale'
    for fldRepoName in $(echo $foldersRepoGPull | sed "s/,/ /g")
    do
        cd "$HOME/Projects/simple/$fldRepoName"
        echo "Now inside $HOME/Projects/simple/$fldRepoName"
        git pull && git pull origin
    done
    cd $currPath
}

gitpushedits() {
    if [[ ! -z $COMMITMSG ]]; then
        git status && git commit -am "$COMMITMSG" && git push origin HEAD
    else
        git status && read -e -p "Commit message: " commit_note && git commit -am "$commit_note" && git push origin HEAD
    fi
}

git_create_branch_with_tracking() {
    read -e -p "Branch Id: " branchId
    git checkout -b $branchId
    git pull && git pull origin
    git pull origin $branchId
    git branch --set-upstream-to="origin/$branchId" $branchId
}

win2lin() { f="${1/C://c}"; printf '%s\n' "${f//\\//}"; }

bakfileup() {
    read -e -p "Name of file to backup: " filename
    currDir=$(pwd)
    # cp "$filename" "_baks_/$filename.bak.$(date +%Y%m%d-%H%M%S)"
    # cp --parents "$filename" "_baks_/$filename.bak.$(date +%Y%m%d-%H%M%S)"
    # install -D "$filename" "_baks_/$filename.bak.$(date +%Y%m%d-%H%M%S)"
    mkdir -p "$currDir/_baks_"
    cp "$filename" "_baks_/$filename.bak.$(date +%Y%m%d-%H%M%S)"
}

makeJenkinsUrl() {
    read -e -p "Ticket ID for which URL is to be created: " ticketId
    read -e -p "Area for which the URL is to be created: " areaName
    read -e -p "Order ID: " OrderId
    printf "https://$ticketId-$areaName.jenkins.simpletire.com"
    printf "Distributor Order Url format: https://$ticketId-backend.jenkins.simpletire.com/MyDistributorsOrders/view/[OrderId]"
    printf "Distributor Order Url format: https://$ticketId-backend.jenkins.simpletire.com/MyDistributorsOrders/view/$OrderId"
    start firefox.exe "https://$ticketId-$areaName.jenkins.simpletire.com"
    start iexplore.exe "https://$ticketId-$areaName.jenkins.simpletire.com"
    # taskkill /IM chrome.exe
    start chrome --enable-webgl --ignore-gpu-blacklist "https://$ticketId-$areaName.jenkins.simpletire.com"
}

gitPullAndMergeMaster() {
    branchId=$(git describe --contains --all HEAD)
    git checkout $branchId
    git pull && git pull origin
    if [[ "$branchId" != "master" ]]; then
        git stash && git merge master && git stash pop
    fi
} >> "GitMergeResult.txt"

case "$TERM" in
xterm*)
    # The following programs are known to require a Win32 Console
    # for interactive usage, therefore let's launch them through winpty
    # when run inside `mintty`.
    for name in node ipython php php5 psql python2.7
    do
        case "$(type -p "$name".exe 2>/dev/null)" in
        ''|/usr/bin/*) continue;;
        esac
        alias $name="winpty $name.exe"
    done
    ;;
esac
