<?php
    include 'email.php';

    if (php_sapi_name() == 'cli') { // get rid of various errors thrown with shell scrips
        $_SERVER['HTTP_HOST'] = 'cli';
    }

    ini_set('session.cookie_domain', '.'. $_SERVER['HTTP_HOST']);

    // Setup a 'default' cache configuration for use in the application.
    Cache::config('default', array(
        'engine' => 'Memcached',
        'duration'=> '+30 minutes',
        'probability'=> 100,
        'servers' => array('127.0.0.1:11211'),
        'persistent' => true,
        'compress' => true,
        'prefix' => ''
    ));

    // Cache configuration to use Memcached Engine for storing data.
    Cache::config('memcachedStore', array(
        'engine' => 'Memcached',
        'duration'=> '+7 days',
        'probability'=> 100,
        'servers' => array('127.0.0.1:11211'),
        'persistent' => true,
        'compress' => true,
        'prefix' => ''
        //'prefix' => Inflector::slug(APP_DIR) . '_'
    ));

    // Adding dispatcher for Memcached engine
    Configure::write('Dispatcher.filters', array(
        'AssetDispatcher',
        'CacheDispatcher'
    ));

    // Cache configuration for data that can be cached for a short time only.
    Cache::config('shortStore', array(
        'engine' => 'File',
        'duration' => '+30 minutes',
        'path' => CACHE,
        'prefix' => 'cake_short_'
    ));

    // Cache configuration for data that can be cached for a long time.
    Cache::config('longStore', array(
        'engine' => 'File',
        'duration' => '+1 week',
        'probability' => 100,
        'path' => CACHE . 'long' . DS
    ));

    App::uses('CakeLog', 'Log');
    CakeLog::config('not_found', array(
            'engine' => 'FileLog',
            'types' => array('404'),
            'file' => 'error',
    ));
    CakeLog::config('debug', array(
        'engine' => 'File',
        'types' => array(
            'notice',
            'info',
            'debug'
        ),
        'file' => 'debug',
    ));
    CakeLog::config('error', array(
        'engine' => 'File',
        'types' => array(
            'warning',
            'error',
            'critical',
            'alert',
            'emergency'
        ),
        'file' => 'error',
    ));

    Configure::write('Recaptcha.publicKey', '6Lf7NPcSAAAAAM06hLSce8y81uCExA8eouhVkQP_');
    Configure::write('Recaptcha.privateKey', '6Lf7NPcSAAAAAChsUtCiGKnbY5ZLNDe72pAo-UcL');

    function isAdmin($key = 'id') {
        if (isset($_SESSION['Auth']['User']['id'])) {
            return $_SESSION['Auth']['User']['id'];
        } else {
            return false;
        }
    }

    function isCustomer() {
        if (isset($_SESSION['Auth']['MyCustomer']['id'])) {
            return $_SESSION['Auth']['MyCustomer']['id'];
        } else {
            return false;
        }
    }

    function getModel($name) {
        App::import('Model', $name);
        $expl = explode('.', $name);
        $model = end($expl);
        return new $model;
    }


    //initialize debugger with debug 2 and then reset to original value
    $debug = Configure::read('debug');
    Configure::write('debug', 2);
    load_settings();
    Configure::write('debug', $debug);


    function getContents($label, $wrapper = true, $defaultText = '') {
        $Content = getModel('Content');
        $content = $Content->find('first', array('conditions' => array('Content.label' => $label)));

        // wrapping all content module markup in this div with this class, so all classes can be overwritten
        if (!empty($content)) {
            if ($wrapper) return '<div class="content-module-container">' . $content['Content']['body_text'] . '</div>'; else
                return $content['Content']['body_text'];
        } else {
            return $defaultText;
        }
    }

    function _slug_it($string) {
        $string = strtolower($string);
        $string = preg_replace('/\//i', '-', $string);
        $string = preg_replace('/[^a-z0-9_\.]/i', '-', $string);
        $string = preg_replace('/--/i', '', $string);
        return $string;
    }

    function maxmind($ip) {
        $s = array();
        $ctx = stream_context_create(array('http' => array('timeout' => 1)));
        $url = "http://geoip3.maxmind.com/f?l=VKI0gTKgIaRR&i=" . $ip;
        $buf = file_get_contents($url, 0, $ctx);
        if ($buf && $geoip = str_getcsv($buf)) {
            if (is_array($geoip[0])) $geoip = $geoip[0];
            $s['country'] = @$geoip[0];
            $s['state'] = @$geoip[1];
            $s['city'] = @$geoip[2];
            $s['zip'] = @$geoip[3];
            $s['latitude'] = @$geoip[4];
            $s['longitude'] = @$geoip[5];

            $s['state'] = $s['state'] == "(null)" ? "" : $s['state'];
        }
        return $s;
    }

    function isBlackFriday() {
        $dt = new DateTime();
        $est = new DateTimeZone('America/New_York'); // or whatever zone you're after
        $dt->setTimezone($est);
        $d = $dt->format('Ymd');
        return $d >= 20151127 && $d <= 20151130;
    }

    function ck($obj,$index,$return,$suffix = ''){
        if(isset($obj[$index]) && $obj[$index] != '') {
            if(is_numeric($obj[$index])){
                return number_format($obj[$index]) . $suffix;
            } else {
                return $obj[$index] . $suffix;
            }
        } else {
            return $return;
        }
    }

    function get_geocode($q = NULL, $type = 'zip') {

        $ret = array();
        $Zip = getModel('Zip');

        $res['error'] = 'true';
        if ($type == 'zip' && !empty($q)) {
            $zip = $q;
            if (strlen($zip) < 5) $zip = '00000';
            $zip = preg_replace('/[^0-9]/', '', $zip);
            //$zip = mysql_real_escape_string($zip);
            if (strlen($zip) == 5) {
                $zD = $Zip->query('SELECT * FROM zips WHERE `zip` = "' . $zip . '" LIMIT 1');
                if (!empty($zD) && isset($zD[0]['zips']['zip']) && !empty($zD[0]['zips']['zip'])) {
                    $zD['Zip'] = $zD[0]['zips'];
                    $ret['zip'] = $zip;
                    $ret['lat'] = $zD['Zip']['latitude'];
                    $ret['lng'] = $zD['Zip']['longitude'];
                    $ret['city'] = $zD['Zip']['city'];
                    $ret['state'] = $zD['Zip']['state'];
                    $ret['country'] = 'United States';
                    $ret['fedex_sameday'] = $zD['Zip']['fedex_sameday'];
                    $ret['ok'] = true;
                    return $ret;
                }
            }
        }

        if ($type == 'state' && !empty($q)) {
            $zD = $Zip->query('SELECT * FROM zips WHERE `state` = "' . $q . '" LIMIT 1');
            if (!empty($zD) && isset($zD[0]['zips']['zip']) && !empty($zD[0]['zips']['zip'])) {
                $zD['Zip'] = $zD[0]['zips'];
                $ret['zip'] = $zD['Zip']['zip'];
                $ret['lat'] = $zD['Zip']['latitude'];
                $ret['lng'] = $zD['Zip']['longitude'];
                $ret['city'] = $zD['Zip']['city'];
                $ret['state'] = $zD['Zip']['state'];
                $ret['country'] = 'United States';
                $ret['fedex_sameday'] = $zD['Zip']['fedex_sameday'];
                $ret['ok'] = true;
                return $ret;
            }
        }

        $ret['ok'] = !empty($ret) ? true : false;
        return $ret;
    }

// found on https://en.gravatar.com/site/implement/images/php
// added in / version from 2012-11
    /**
     * Get either a Gravatar URL or complete image tag for a specified email address.
     *
     * @param string $email The email address
     * @param string $s Size in pixels, defaults to 80px [ 1 - 2048 ]
     * @param string $d Default imageset to use [ 404 | mm | identicon | monsterid | wavatar ]
     * @param string $r Maximum rating (inclusive) [ g | pg | r | x ]
     * @param boole $img True to return a complete IMG tag False for just the URL
     * @param array $atts Optional, additional key/value attributes to include in the IMG tag
     * @return String containing either just a URL or a complete image tag
     * @source http://gravatar.com/site/implement/images/php/
     */
    function get_gravatar($email, $s = 80, $d = 'mm', $r = 'g', $img = false, $atts = array()) {
        $url = 'https://www.gravatar.com/avatar/';
        $url .= md5(strtolower(trim($email)));
        $url .= "?s=$s&d=$d&r=$r";
        if ($img) {
            $url = '<img src="' . $url . '"';
            foreach ($atts as $key => $val) $url .= ' ' . $key . '="' . $val . '"';
            $url .= ' />';
        }
        return $url;
    }

    function round_to_half($num) {
        if ($num >= ($half = ($ceil = ceil($num)) - 0.5) + 0.25) return $ceil; else if ($num < $half - 0.25) return floor($num); else
            return $half;
    }

    function is_selected($array, $key, $value) {
        if(!empty($array[$key]) && $array[$key] == $value) {
            // TODO: remove is_mobile
            return 'selected="selected"';
        } else {
            return '';
        }
    }

    function tcspart_image_url($type = NULL, $type_id = NULL, $image_mode = NULL, $not_found_image = 'unavailable.jpg') {
        if($type == 'Manufacturer') {
            $image_url = '//dki3ho7vp1wav.cloudfront.net/' . $type_id . '.png?v=4';
        } else {
            $image_url = '//s3.amazonaws.com/simpletire/tires/view/' . $type . '/logos/' . $type_id . '.png?v=6';
        }
        return $image_url;
    }

    function tireSize($p = array(),$advance = true) {

        $width_int = (isset($p['MyProduct']['width_int']) ? $p['MyProduct']['width_int'] : @$p['MyProduct']['width']);
        $width = @$p['MyProduct']['width'];
        $ratio = @$p['MyProduct']['ratio'];
        if ($ratio != '-') {
            $ratio = str_replace('-', '', $ratio);
        }
        $rim = @$p['MyProduct']['rim'];

        //remove invalid UTF characters
        $rim = iconv("UTF-8", "UTF-8//IGNORE", $rim);

        // our default size format
        $size = $width . (!empty($ratio) ? "/" . $ratio : "") . "-" . $rim;

        if (isset($p['MyProductSubType']) && isset($p['MyProductSubType']['name']) && !empty($p['MyProductSubType']['name']) && $advance) {
            $subtype = $p['MyProductSubType']['name'];
            if ($subtype == 'Farm') {
                $size = $width . '-' . $rim;
            } else if ($subtype == 'Industrial') {
                if ($ratio == '-') {
                    $ratio = '';
                    $size = $width . $ratio . '-' . $rim;
                } else {
                    $size = $width . 'x' . $ratio . '-' . $rim;
                }
            } else if ($subtype == 'Light Truck') {
                $size = $width . 'x' . $ratio . $rim;
            } else if ($subtype == 'ATV/UTV') {
                $size = $width . 'x' . $ratio . '-' . $rim;
            }
        }

        return $size;
    }

    function purgeAPCCache() {
        apc_clear_cache();
        apc_clear_cache('user');
        apc_clear_cache('opcode');
    }

    function addDataToCache($data, $cacheName, $timeout) {
        if (!apc_exists($cacheName)) {
            apc_add($cacheName, $data, $timeout);
            return true;
        }
        return false;
    }

    function getDataFromCache($cacheName) {
        if ($data = apc_fetch($cacheName)) {
            return $data;
        }
        return null;
    }

    function canApplyCache($arrayA, $arrayB) {
        $keysA = array_keys($arrayA);
        if (isset($arrayA['subtype']) && strpos($arrayA['subtype'], ',') !== false) {
            return false;
        }
        if (in_array('zip', $keysA)) {
            $keyZip = array_search('zip', $keysA);
            unset($keysA[$keyZip]);
        }
        sort($keysA);
        sort($arrayB);
        return $keysA == $arrayB;
    }

    function setPhpTweaks() {
        set_time_limit(0);
        ignore_user_abort(1);
        ini_set('mysql.connect_timeout','0');
        ini_set('max_execution_time', '0');
        ini_set('memory_limit', '-1');
    }

    function getCurrentUrl($getUrlParams = false) {
        $s = empty($_SERVER["HTTPS"]) ? '' : ($_SERVER["HTTPS"] == "on") ? "s" : "";
        $protocol = substr(strtolower($_SERVER["SERVER_PROTOCOL"]), 0, strpos(strtolower($_SERVER["SERVER_PROTOCOL"]), "/")) . $s;
        $port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":".$_SERVER["SERVER_PORT"]);
        $currentUrl = $protocol . "://" . $_SERVER['SERVER_NAME'] . $port . $_SERVER['REQUEST_URI'];
        if ($getUrlParams === true) {
            parse_str(parse_url($currentUrl, PHP_URL_QUERY), $params);
            return array('currUrl' => $currentUrl, 'params' => $params);
        }
        return $currentUrl;
    }

    CakePlugin::load('AssetCompress', array('bootstrap' => true));
    CakePlugin::load('Composer', array('bootstrap' => true));
    CakePlugin::load('BoostCake');
    CakePlugin::load('Migrations');
    CakePlugin::load('DebugKit');
