Hi [~josh] & QA Team,

This ticket is ready to be tested and verified by following steps:

1. First login to Backoffice(https://sim-4294-backoffice.jenkins.simpletire.com/login) with your credentials and click on "Legacy Admin" link in sidebar.

2. Then in Backend, click on Menu > My Products and then in the next page click on Manufacturers(https://sim-4294-backend.jenkins.simpletire.com/MyManufacturers/index).

3. Now read the CSV Upload Instructions carefully and try to upload the attached CSV file and check if it shows message "Brand Tier Ratings imported successfully".

4. Now click on the "Download Manufacturer Brand Ratings CSV" link and download the CSV and check by comparing the id(Id of Manufacturer) of both the CSVs (the one you uploaded and the one you just got) to see if the *brand_tier_rating* has been successfully associated or not.

Let me know if any doubts or concerns. Please make sure the CSV format is as stated in the bold instructions in [there|https://sim-4294-backend.jenkins.simpletire.com/MyManufacturers/index].

 [^manufacturerBrandRatings_Test.csv] 

CC: [~cj] [~mahesh] [~manoj] [~james] [~anil] [~kevink] [~umair]

Permalink - https://simpletire.atlassian.net/browse/SIM-4294?focusedCommentId=50502&page=com.atlassian.jira.plugin.system.issuetabpanels%3Acomment-tabpanel#comment-50502
