-- select table_name, column_name from information_schema.columns where column_name like '%search_keyword%';

SELECT COUNT(*) FROM my_distributors_warehouses_products INTO OUTFILE '/var/lib/mysql-files/sql_res.txt';
exit;
mv -f /var/lib/mysql-files/sql_res.txt /var/www/devdb/sql_res.txt

-- Find columns by name from entire database --
SELECT table_name, column_name, extra
	FROM INFORMATION_SCHEMA.COLUMNS
	WHERE ((column_name LIKE '%customer_id%' AND extra LIKE '%auto_increment%')
		OR column_name LIKE '%is_admin%'
		OR (column_name LIKE '%warehouse_id%' AND extra LIKE '%auto_increment%'))
	AND TABLE_SCHEMA = 'rpm_simpletire'
	INTO OUTFILE '/var/lib/mysql-files/query_result1.txt';
exit;
-- Then move the output file to /var/www/devdb/
mv -f /var/lib/mysql-files/query_result1.txt /var/www/devdb/query_result1.txt

-- Or --

SELECT table_name, column_name, extra
	FROM INFORMATION_SCHEMA.COLUMNS
	WHERE (column_name LIKE '%customer_id%'
		OR column_name LIKE '%is_admin%'
		OR column_name LIKE '%warehouse_id%')
	AND TABLE_SCHEMA = 'rpm_simpletire'
	INTO OUTFILE '/var/lib/mysql-files/query_result1.txt';
exit;
cp -a /var/lib/mysql-files/query_result1.txt /var/www/devdb/
mv -f /var/lib/mysql-files/query_result1.txt /var/www/devdb/query_result1.txt

-- Check if given database exists or not --
SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '[DATABASE_NAME]';
SHOW DATABASES LIKE '[DATABASE_NAME]';
SELECT IF('database_name' IN(SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA), 1, 0)
	AS FOUND_ENTRIES;

-- Check if a given table exists in database or not --
USE [DATABASE_NAME];
USE rpm_simpletire;
SHOW TABLES LIKE '[TABLE_NAME]';
SHOW TABLES LIKE '%[TABLE_NAME]%';

-- Find the output directory that has been configured securely --
SHOW VARIABLES LIKE "secure_file_priv";
