#!C:\Progra~1\Git\usr\bin\bash.exe -u

cd $PROJECTSDIR/simplevagrant
vagrant up
gpll_allrepos
# OR #
# cd $PROJECTSDIR/simplevagrant && vagrant up && gpll_allrepos

# Set this file in GitBash > Context Menu > Properties > Target > "C:\Program Files\Git\git-bash.exe" -l "C:\Users\WMIND2004\Downloads\GitBashLaunchScript.sh"
# Set this file in GitBash > Context Menu > Properties > Target > "C:\Program Files\Git\git-bash.exe" -l "Path\To\GitBashLaunchScript.sh"
