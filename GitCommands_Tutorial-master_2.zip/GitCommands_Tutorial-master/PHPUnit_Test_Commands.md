### Generate Code Coverage Report for all or specific tests: ###
```bash
vendor/bin/phpunit --coverage-html code-coverage
vendor/bin/phpunit --coverage-html code-coverage [filePath] or [folderPath]
vendor/bin/phpunit --coverage-html code-coverage tests/AppBundle/Admin/ServicesAdminUnitTest.php
```

### Execute the Unit Test and generate the Test Report with Output status: ###
```bash
vendor/bin/phpunit
make all-tests
vendor/bin/phpunit [filePath] or [folderPath]
make all-tests [filePath] or [folderPath]
vendor/bin/phpunit tests/AppBundle/Admin/ServicesAdminUnitTest.php
make code-coverage-report
```
