### Display most of the Server and System Info along with present DateTime ###
```php
# Save this in file named "System_Server_Info.php"
<?php
header('Content-Type: text/plain');
echo "Hostname: ". @php_uname(n) ."\n";
if (function_exists( 'shell_exec' )) {
    echo "Hostname: ". @gethostbyname(trim(`hostname`)) . "\n";
} else {
    echo "Server IP: ". $_SERVER['SERVER_ADDR'] . "\n";
}
echo "Platform: ". @php_uname(s) ." ". @php_uname(r) ." ". @php_uname(v) ."\n";
echo "Architecture: ". @php_uname(m) ."\n";
echo "Username: ". get_current_user () ." ( UiD: ". getmyuid() .", GiD: ". getmygid() ." )\n";
echo "Curent Path: ". getcwd () ."\n";
echo "Server Name: ". $_SERVER['SERVER_NAME'] . "\n";
echo "Server Type: ". $_SERVER['SERVER_SOFTWARE'] . "\n";
echo "Server Admin: ". $_SERVER['SERVER_ADMIN'] . "\n";
echo "Server Signature: ". $_SERVER['SERVER_SIGNATURE'] ."\n";
echo "Server Protocol: ". $_SERVER['SERVER_PROTOCOL'] ."\n";
echo "Server Mode: ". $_SERVER['GATEWAY_INTERFACE'] ."\n";
$dateObj = new DateTime(null, new DateTimeZone('Asia/Kolkata'));
# echo "Today: " . $dateObj->format('Y-m-d H:i:s'); # MySQL DateTime Format
echo "Today: " . $dateObj->format('D M j G:i:s T Y'); # General DateTime Display Format
?>
```
https://stackoverflow.com/questions/470617/how-to-get-the-current-date-and-time-in-php  
http://php.net/manual/en/function.date.php  
https://tecadmin.net/get-current-date-and-time-in-php/  

### PHP MySQL Create Database-Table Structure ###
```php
<?php
# Execute this script only once
try {
    if ( $db->connect_errno ) throw new Exception("Connection Failed: ".$db->connect_error);
    $db = new mysqli('localhost','root','[PasswordText]','mysql');
    # $resource = $db->query("CREATE DATABASE `playground` CHARACTER SET utf8 COLLATE utf8_general_ci;");
    $resource = $db->query("CREATE DATABASE `Playground` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
    $resource = $db->select_db("Playground");
    $createTableSql = "CREATE TABLE Users (
                        user_id INT(7) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                        firstname VARCHAR(128) NOT NULL,
                        lastname VARCHAR(128) NOT NULL,
                        username VARCHAR(128) NOT NULL,
                        password VARCHAR(256) NOT NULL,
                        email VARCHAR(192) NOT NULL,
                        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                    )";
    $resource = $db->query($createTableSql);
    if ( !$resource ) throw new Exception($db->error);
    $resource->free();
    $db->close();
} catch (Exception $e) {
    echo "DB Exception: ",$e->getMessage(),"\n";
}
?>
```

### PHP MySQL Set Root Password ###
```php
<?php
# Execute this script only once
try {
    if ( $db->connect_errno ) throw new Exception("Connection Failed: ".$db->connect_error);
    $db = new mysqli('localhost','root','','information_schema');
    $resource = $db->query("SET PASSWORD FOR 'root'@'localhost' = PASSWORD('[PasswordText]');");
    if ( !$resource ) throw new Exception($db->error);
    $resource->free();
    $db->close();
} catch (Exception $e) {
    echo "DB Exception: ",$e->getMessage(),"\n";
}
?>
```

### PHP Ping MySQL Server to check if it exists and running ###
```php
<?php
echo @mysql_ping() ? 'true' : 'false';
exit();
?>
```
