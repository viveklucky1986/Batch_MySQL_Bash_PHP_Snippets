# GitCommands_Tutorial

```bash
git diff --name-only <notMainDev> $(git merge-base <notMainDev> <mainDev>)
git diff --name-only sim-3521 `$(git merge-base sim-3521 master)`
git diff --name-only --right-only master
git diff --name-only  master...branch
git diff --name-only  master...sim-3521
```

### Git Fetch & Merge Master changes with overwriting:
```bash
# If needed run this command first #
git reset --hard HEAD
# or #
git reset --hard
git fetch origin master
git merge -s recursive -X theirs origin/master
```

### Git Create Directory & Bundle of Repository and Put the Bundle in that folder:
```bash
mkdir -m 755 [DirName] && git bundle create "[DirName]/[BundleName].bundle" --all
mkdir -p -m 755 [DirName] && git bundle create "[DirName]/[BundleName].bundle" --all
mkdir -m 755 _baks_ && git bundle create "_baks_/backoffice.bundle" --all
mkdir -p -m 755 _baks_ && git bundle create "_baks_/backend.bundle" --all
mkdir -p -m 755 [DirName] && git bundle create "[DirName]/[BundleName]_[TodayDate].bundle" --all
mkdir -p -m 755 [DirName] && git bundle create "[DirName]/[BundleName]_$(date +%Y%m%d).bundle" --all
mkdir -p -m 755 [DirName] && git bundle create "[DirName]/[BundleName]_[NowDateTime].bundle" --all
```

### Add Bash Command Aliases in Vagrant SSH:
```BASH
sudo nano ~/.bash_aliases
# OR #
sudo nano ~/.bashrc
# Declare Global Variables with Commands like below: #
export simpledir='cd /var/www/'
# Usage of above command: #
$simpledir/backend
# Add Aliases like below: #
alias purgehist='history -cw && reset && clear && history -cw'
# Shortcut to Save and Exit #
## Ctrl + O > Enter (Save with given filename, don't change it) > Ctrl + X
```

## Vagrant SSH Bash Aliases File ##
```BASH
export simpledir='cd /var/www/'
export dirInfo='ls -lha --color=always'
export aliasFile='sudo nano ~/.bash_aliases'
alias purgehist='history -cw && reset && clear && history -cw'
```

### Bash Get Info about all installed Packages: ###
```bash
dpkg-query -l
dpkg-query -f '${binary:Package}\n' -W
dpkg -l \*php-\*
dpkg -l \*php-mem\*
dpkg -l *php-m*
dpkg -l *php-memcached*
```

### Vagrant Bash SSH Aliases File (R) ###
```bash
export simpledir='cd /var/www/'
export dirInfo='ls -lha --color=always'
export compDir='/var/www/composer-packages'
export aliasFile='sudo nano /home/vagrant/.bash_aliases'
export aliasFileVi='sudo vi /home/vagrant/.bash_aliases'
alias phpcsexec="$compDir/vendor/squizlabs/php_codesniffer/bin/phpcs"
alias purgehist='history -cw && reset && clear && history -cw'
```

### MySQL Get the table matching by name from the database ###
```sql
SELECT table_name FROM information_schema.tables
	WHERE table_schema='[DatabaseName]' AND table_name LIKE '%[SearchTerm/Pattern]%';
SELECT table_name FROM information_schema.tables
	WHERE table_schema='rpm_simpletire' AND table_name LIKE '%service%';
```

### Symfony Generate the Entity class(es) for existing table in database ###
```bash
php bin/console list > Symfony_Commands.list
php bin/console doctrine:generate:entity
php bin/console doctrine:generate:entities
# OR #
bin/console list > Symfony_Commands.list
bin/console doctrine:generate:entity
bin/console doctrine:generate:entities
```

### Symfony Cache Clearing Command ###
```bash
bin/console cache:clear
php bin/console cache:clear
```

### Symfony 3.4.4 Commands List ###
```
Symfony 3.4.4 (kernel: app, env: dev, debug: true)

Usage:
  command [options] [arguments]

Options:
  -h, --help            Display this help message
  -q, --quiet           Do not output any message
  -V, --version         Display this application version
      --ansi            Force ANSI output
      --no-ansi         Disable ANSI output
  -n, --no-interaction  Do not ask any interactive question
  -e, --env=ENV         The Environment name. [default: "dev"]
      --no-debug        Switches off debug mode.
  -v|vv|vvv, --verbose  Increase the verbosity of messages: 1 for normal output, 2 for more verbose output and 3 for debug

Available commands:
  about                                   Displays information about the current project
  help                                    Displays help for a command
  list                                    Lists commands
 acl
  acl:set                                 Sets ACL for objects
 assets
  assets:install                          Installs bundles web assets under a public directory
 cache
  cache:clear                             Clears the cache
  cache:create-cache-class                Generate the classes.php files
  cache:pool:clear                        Clears cache pools
  cache:pool:prune                        Prune cache pools
  cache:warmup                            Warms up an empty cache
 config
  config:dump-reference                   Dumps the default configuration for an extension
 debug
  debug:autowiring                        Lists classes/interfaces you can use for autowiring
  debug:config                            Dumps the current configuration for an extension
  debug:container                         Displays current services for an application
  debug:event-dispatcher                  Displays configured listeners for an application
  debug:form                              Displays form type information
  debug:router                            Displays current routes for an application
  debug:swiftmailer                       [swiftmailer:debug] Displays current mailers for an application
  debug:translation                       Displays translation messages information
  debug:twig                              Shows a list of twig functions, filters, globals and tests
 doctrine
  doctrine:cache:clear-collection-region  Clear a second-level cache collection region
  doctrine:cache:clear-entity-region      Clear a second-level cache entity region
  doctrine:cache:clear-metadata           Clears all metadata cache for an entity manager
  doctrine:cache:clear-query              Clears all query cache for an entity manager
  doctrine:cache:clear-query-region       Clear a second-level cache query region
  doctrine:cache:clear-result             Clears result cache for an entity manager
  doctrine:cache:contains                 Check if a cache entry exists
  doctrine:cache:delete                   Delete a cache entry
  doctrine:cache:flush                    [doctrine:cache:clear] Flush a given cache
  doctrine:cache:stats                    Get stats on a given cache provider
  doctrine:database:create                Creates the configured database
  doctrine:database:drop                  Drops the configured database
  doctrine:database:import                Import SQL file(s) directly to Database.
  doctrine:ensure-production-settings     Verify that Doctrine is properly configured for a production environment
  doctrine:generate:crud                  [generate:doctrine:crud] Generates a CRUD based on a Doctrine entity
  doctrine:generate:entities              [generate:doctrine:entities] Generates entity classes and method stubs from your mapping information
  doctrine:generate:entity                [generate:doctrine:entity] Generates a new Doctrine entity inside a bundle
  doctrine:generate:form                  [generate:doctrine:form] Generates a form type class based on a Doctrine entity
  doctrine:mapping:convert                [orm:convert:mapping] Convert mapping information between supported formats
  doctrine:mapping:import                 Imports mapping information from an existing database
  doctrine:mapping:info                   
  doctrine:query:dql                      Executes arbitrary DQL directly from the command line
  doctrine:query:sql                      Executes arbitrary SQL directly from the command line.
  doctrine:schema:create                  Executes (or dumps) the SQL needed to generate the database schema
  doctrine:schema:drop                    Executes (or dumps) the SQL needed to drop the current database schema
  doctrine:schema:update                  Executes (or dumps) the SQL needed to update the database schema to match the current mapping metadata
  doctrine:schema:validate                Validate the mapping files
 fos
  fos:oauth-server:clean                  Clean expired tokens
  fos:user:activate                       Activate a user
  fos:user:change-password                Change the password of a user.
  fos:user:create                         Create a user.
  fos:user:deactivate                     Deactivate a user
  fos:user:demote                         Demote a user by removing a role
  fos:user:promote                        Promotes a user by adding a role
 generate
  generate:bundle                         Generates a bundle
  generate:command                        Generates a console command
  generate:controller                     Generates a controller
 init
  init:acl                                Mounts ACL tables in the database
 lint
  lint:twig                               Lints a template and outputs encountered errors
  lint:xliff                              Lints a XLIFF file and outputs encountered errors
  lint:yaml                               Lints a file and outputs encountered errors
 router
  router:match                            Helps debug routes by simulating a path info match
 security
  security:check                          Checks security issues in your project dependencies
  security:encode-password                Encodes a password.
 server
  server:log                              Starts a log server that displays logs in real time
  server:run                              Runs a local web server
  server:start                            Starts a local web server in the background
  server:status                           Outputs the status of the local web server for the given address
  server:stop                             Stops the local web server that was started with the server:start command
 simpletire
  simpletire:oauth:consumer:create        Creates an OAuth consumer (i.e. client).
 sonata
  sonata:admin:explain                    Explain an admin service
  sonata:admin:generate                   Generates an admin class based on the given model class
  sonata:admin:generate-object-acl        Install ACL for the objects of the Admin Classes.
  sonata:admin:list                       List all admin services available
  sonata:admin:setup-acl                  Install ACL for Admin Classes
  sonata:block:debug                      Debug all blocks available, show default settings of each block
  sonata:core:dump-doctrine-metadata      Get information on the current Doctrine's schema
  sonata:easy-extends:dump-mapping        Dump some mapping information (debug only)
  sonata:easy-extends:generate            Create entities used by Sonata's bundles
  sonata:user:two-step-verification       Generate a two step verification process to secure an access (Ideal for super admin protection)
 swiftmailer
  swiftmailer:email:send                  Send simple email message
  swiftmailer:spool:send                  Sends emails from the spool
 translation
  translation:update                      Updates the translation file
```

### Clear all the Temporary Files from Windows System ###
```bat
@echo off
cd %Temp%
for /d %%D in (*) do rd /s /q "%%D"
del /f /q *
del /q/f/s %TEMP%\*
rd /s /q %WINDIR%\temp\
mkdir %WINDIR%\temp\
pause > nul
```
```cmd
@echo off
cd %Temp%
for /d %%D in (*) do rd /s /q "%%D"
del /f /q *
del /q/f/s %TEMP%\*
rd /s /q %WINDIR%\temp\
mkdir %WINDIR%\temp\
pause > nul
```

### Create Shortcut or Link from Command Prompt in Windows ###
```cmd
@echo off
set "LinkName=Backend-Simpletire"
echo Set oWS = WScript.CreateObject("WScript.Shell") > CreateShortcut.vbs
echo sLinkFile = "%UserProfile%\Desktop\%LinkName%.lnk" >> CreateShortcut.vbs
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> CreateShortcut.vbs
::echo oLink.TargetPath = "%ProgramFiles%\Git\cmd\git-gui.exe" >> CreateShortcut.vbs
echo oLink.TargetPath = "%ProgramFiles%\Git\git-bash.exe" >> CreateShortcut.vbs
echo oLink.WorkingDirectory = "%HOMEDRIVE%%HOMEPATH%/Projects/simple/backend" >> CreateShortcut.vbs
echo oLink.Description = "%LinkName%" >> CreateShortcut.vbs
echo oLink.IconLocation = "%SystemDrive%\Program Files\Git\mingw64\share\git\git-for-windows.ico" >> CreateShortcut.vbs
echo oLink.Save >> CreateShortcut.vbs
cscript CreateShortcut.vbs
pause > nul
del CreateShortcut.vbs
exit
```
```bat
@echo off
set "LinkName=Backend-Simpletire"
echo Set oWS = WScript.CreateObject("WScript.Shell") > CreateShortcut.vbs
echo sLinkFile = "%UserProfile%\Desktop\%LinkName%.lnk" >> CreateShortcut.vbs
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> CreateShortcut.vbs
::echo oLink.TargetPath = "%ProgramFiles%\Git\cmd\git-gui.exe" >> CreateShortcut.vbs
echo oLink.TargetPath = "%ProgramFiles%\Git\git-bash.exe" >> CreateShortcut.vbs
echo oLink.WorkingDirectory = "%HOMEDRIVE%%HOMEPATH%/Projects/simple/backend" >> CreateShortcut.vbs
echo oLink.Description = "%LinkName%" >> CreateShortcut.vbs
echo oLink.IconLocation = "%SystemDrive%\Program Files\Git\mingw64\share\git\git-for-windows.ico" >> CreateShortcut.vbs
echo oLink.Save >> CreateShortcut.vbs
cscript CreateShortcut.vbs
pause > nul
del CreateShortcut.vbs
exit
```
