```cmd
"C:\Program Files\Git\git-bash.exe" --login -i -c "echo 'Hello World!'; read"
"C:\Program Files\Git\git-bash.exe" -i -c "cd $HOME/Projects/simple/simplevagrant && vagrant up"
"C:\Program Files\Git\git-bash.exe" -l "D:\test.sh"
""%SYSTEMDRIVE%\Program Files\Git\bin\sh.exe" --login"
"C:\Program Files\Git\git-bash.exe" -l -c "cd $HOME/Projects/simple/simplevagrant && vagrant up && $SHELL"
"C:\Program Files\Git\git-bash.exe" -c "cd $HOME/Projects/simple/simplevagrant && vagrant up && $SHELL"
```
```bat
"C:\Program Files\Git\git-bash.exe" --login -i -c "echo 'Hello World!'; read"
"C:\Program Files\Git\git-bash.exe" -i -c "cd $HOME/Projects/simple/simplevagrant && vagrant up"
"C:\Program Files\Git\git-bash.exe" -l "D:\test.sh"
""%SYSTEMDRIVE%\Program Files\Git\bin\sh.exe" --login"
"C:\Program Files\Git\git-bash.exe" -l -c "cd $HOME/Projects/simple/simplevagrant && vagrant up && $SHELL"
"C:\Program Files\Git\git-bash.exe" -c "cd $HOME/Projects/simple/simplevagrant && vagrant up && $SHELL"
```
```gitbash
"C:\Program Files\Git\git-bash.exe" --login -i -c "echo 'Hello World!'; read"
"C:\Program Files\Git\git-bash.exe" -i -c "cd $HOME/Projects/simple/simplevagrant && vagrant up"
"C:\Program Files\Git\git-bash.exe" -l "D:\test.sh"
"C:\Program Files\Git\git-bash.exe" -l -c "cd $HOME/Projects/simple/simplevagrant && vagrant up && $SHELL"
"C:\Program Files\Git\git-bash.exe" -c "cd $HOME/Projects/simple/simplevagrant && vagrant up && $SHELL"
```
```bash
"C:\Program Files\Git\git-bash.exe" --login -i -c "echo 'Hello World!'; read"
"C:\Program Files\Git\git-bash.exe" -i -c "cd $HOME/Projects/simple/simplevagrant && vagrant up"
"C:\Program Files\Git\git-bash.exe" -l "D:\test.sh"
"C:\Program Files\Git\git-bash.exe" -l -c "cd $HOME/Projects/simple/simplevagrant && vagrant up && $SHELL"
"C:\Program Files\Git\git-bash.exe" -c "cd $HOME/Projects/simple/simplevagrant && vagrant up && $SHELL"
```
```sh
"C:\Program Files\Git\git-bash.exe" --login -i -c "echo 'Hello World!'; read"
"C:\Program Files\Git\git-bash.exe" -i -c "cd $HOME/Projects/simple/simplevagrant && vagrant up"
"C:\Program Files\Git\git-bash.exe" -l "D:\test.sh"
"C:\Program Files\Git\git-bash.exe" -l -c "cd $HOME/Projects/simple/simplevagrant && vagrant up && $SHELL"
"C:\Program Files\Git\git-bash.exe" -c "cd $HOME/Projects/simple/simplevagrant && vagrant up && $SHELL"
```
