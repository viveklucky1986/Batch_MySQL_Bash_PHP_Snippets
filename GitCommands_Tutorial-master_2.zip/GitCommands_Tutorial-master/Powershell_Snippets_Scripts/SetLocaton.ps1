::"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" "-NoExit" "-ExecutionPolicy" "AllSigned"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" "-NoExit" "-ExecutionPolicy" "Unrestricted" "-Command" "Set-Location 'C:\Users\VICKY\Downloads\escprrmm.wb72_300mbfilms.org'"
