git add .
git commit -m "Initial & Final Commit"
# git remote add origin "https://github.com/vivek-simpletire/GitCommands_Tutorial.git"
git remote add origin "git@github.com:vivek-simpletire/GitCommands_Tutorial.git"
git push origin master
$SHELL