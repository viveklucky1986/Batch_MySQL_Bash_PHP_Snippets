#!C:\Python27\python.exe

import sublime, sublime_plugin, random, re, os

def addToClipBoard(text):
    command = 'echo ' + text.strip() + '| clip'
    os.system(command)

class GetCommitIdCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        selection = self.view.sel()
        for region in selection:
            print(region)
            url = self.view.substr(region)
            final_text = url.split("/")[-1]
            # Replace the selection with modified
            self.view.replace(edit, region, final_text)
            addToClipBoard(final_text)