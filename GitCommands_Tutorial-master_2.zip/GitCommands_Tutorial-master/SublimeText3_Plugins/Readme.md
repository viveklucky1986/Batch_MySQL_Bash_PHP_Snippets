#### Extract the plugin .rar file contents into "%AppData%\\..\Roaming\Sublime Text 3\Packages" directory ####
