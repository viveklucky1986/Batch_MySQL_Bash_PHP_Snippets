<?php
function purgeAPCCache() {
    apc_clear_cache();
    apc_clear_cache('user');
    apc_clear_cache('opcode');
}

function addDataToCache($data, $cacheName, $timeout) {
    if (!apc_exists($cacheName)) {
        apc_add($cacheName, $data, $timeout);
        return true;
    }
    return false;
}

function getDataFromCache($cacheName) {
    if ($data = apc_fetch($cacheName)) {
        return $data;
    }
    return null;
}
?>
