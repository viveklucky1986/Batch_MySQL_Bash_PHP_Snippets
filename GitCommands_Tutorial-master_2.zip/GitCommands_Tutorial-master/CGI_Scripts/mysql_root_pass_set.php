<?php
# Execute this script only once
try {
    if ( $db->connect_errno ) throw new Exception("Connection Failed: ".$db->connect_error);
    $db = new mysqli('localhost','root','','information_schema');
    $resource = $db->query("SET PASSWORD FOR 'root'@'localhost' = PASSWORD('[PasswordText]');");
    if ( !$resource ) throw new Exception($db->error);
    $resource->free();
    $db->close();
} catch (Exception $e) {
    echo "DB Exception: ",$e->getMessage(),"\n";
}
