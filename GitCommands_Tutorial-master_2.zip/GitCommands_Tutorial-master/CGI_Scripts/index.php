<?php
exit("This is a test php cgi script");
?>