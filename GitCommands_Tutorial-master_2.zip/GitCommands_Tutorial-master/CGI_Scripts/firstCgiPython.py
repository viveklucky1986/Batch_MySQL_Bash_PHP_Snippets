#!C:\Python27\python.exe
#!/Python27/python

print "Content-type:text/html\r\n\r\n"
print '<html>'
print '<head>'
print '<title>Hello Word - First CGI Program in Python54543534</title>'
print '</head>'
print '<body>'
print '<h2>Hello Word! This is my first CGI program54354435345345</h2>'
print '</body>'
print '</html>'