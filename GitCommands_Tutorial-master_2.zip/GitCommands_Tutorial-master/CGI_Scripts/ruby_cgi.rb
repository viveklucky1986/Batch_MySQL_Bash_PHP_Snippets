#!C:\Ruby25\bin\ruby.exe
#!\Ruby25\bin\ruby

# require 'cgi'
# cgi = CGI.new
# h = cgi.params  # =>  {"FirstName"=>["Vivek"],"LastName"=>["Shah"]}
# h['FirstName']  # =>  ["Vivek"]
# h['LastName']   # =>  ["Shah"]
puts "HTTP/1.0 200 OK"
puts "Content-type: text/html\n\n"
puts "<html><body>This is a test</body></html>"