if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit }
cd "C:\Program Files\MySQL\MySQL Workbench 6.3 CE\snippets\Custom_MySQL_Snippets_ST"
"Hello World!!!" | Set-Content DESC.txt
Start notepad++ "C:\Program Files\MySQL\MySQL Workbench 6.3 CE\snippets\Custom_MySQL_Snippets_ST\DESC.txt"
ii "C:\Program Files\MySQL\MySQL Workbench 6.3 CE\snippets\Custom_MySQL_Snippets_ST"
Read-Host -Prompt "Press Enter to exit"
