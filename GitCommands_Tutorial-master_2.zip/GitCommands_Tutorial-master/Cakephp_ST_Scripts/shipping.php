<?php
# backend\admin\vendors\shells\shipping.php
Configure::write('debug', 0);
App::import('Component', 'LogTypeEnum');

class ShippingShell extends Shell{

    var $uses = array('MyOrder', 'MyDistributorsWarehousesOrdersTrackingLog', 'MyDistributorsWarehousesOrder', 'MyDistributorsWarehousesOrdersShippingLabel', 'MyOrderReturnStatus');

    private $ignore_statuses = array(
                                    'Shipment information sent to FedEx',
                                    'No information received',
                                    'Billing Information Received'
                                );
    private $shipped_statuses = array(
                                    'Picked up',
                                    'Pickup Scan',
                                    'Arrived at FedEx location',
                                    'Departure Scan',
                                    'Arrival Scan',
                                    'In transit',
                                    'Departed FedEx location',
                                    'Left FedEx origin facility',
                                    'In Transit',
                                    'Origin Scan',
                                    'At FedEx destination facility',
                                    'On FedEx vehicle for delivery',
                                    'Out For Delivery',
                                    'Delivered To Ups Access Point',
                                    'Delivery option requested',
                                    'At local facility',
                                    'Delivery exception',
                                    'Shipment exception',
                                    'The Shipment Has Been Dropped Off And Is Now At A Ups Retail Location',
                                    'At local FedEx facility',
                                    'At destination sort facility',
                                    'Out for delivery',
                                    'Destination Scan',
                                    'Arrived at FedEx location',
                                    'On FedEx vehicle for delivery',
                                    'Departed FedEx location',
                                    'Picked up',
                                    'Arrival Scan',
                                    'At FedEx destination facility',
                                    'In FedEx possession',
                                    'Dispatched'
                                );
    private $delivered_statuses = array(
                                    'Delivered',
                                    'Shipment Has Been Delivered To Consignee'
                                );

    // look for labels from recent orders and update with recent tracking information
    function get_updates() {
        $bgmc = new GearmanClient();
        $bgmc->addServer('127.0.0.1', '4730');

        $days_back = !empty($this->params['days_back']) ? $this->params['days_back'] : 15;
        echo "\n".str_repeat("-", 100)."\nRunning get_updates for $days_back days back";
        $this->MyDistributorsWarehousesOrdersShippingLabel->unBindAll();

        $this->MyDistributorsWarehousesOrdersShippingLabel->bindModel(array(
            'belongsTo' => array(
                'MyDistributorsWarehousesOrdersTrackingLog' => array(
                    'foreignKey' => false,
                    'conditions' => array('MyDistributorsWarehousesOrdersShippingLabel.id = MyDistributorsWarehousesOrdersTrackingLog.my_distributors_warehouses_orders_shipping_label_id')
                    )
                )
            ));

        $conditions = array(
                            'MyDistributorsWarehousesOrdersShippingLabel.delivered' => 0,
                            'MyDistributorsWarehousesOrdersShippingLabel.status' => 'Active',
                            'MyDistributorsWarehousesOrdersShippingLabel.shipping_method' => array('Fedex','UPS','FreightQuote'),
                            'NOT' => array('MyDistributorsWarehousesOrdersShippingLabel.tracking_number' => null,
                                            'MyDistributorsWarehousesOrdersShippingLabel.shipping_method' => 'Walmart'),
                            'DATE(MyDistributorsWarehousesOrdersShippingLabel.created) >= DATE_SUB(CURDATE(), INTERVAL '.$days_back.' DAY)'
                        );
        if(!empty($this->params['my_order_id'])) {
            $conditions[] = 'MyDistributorsWarehousesOrdersShippingLabel.my_distributors_warehouses_order_id IN (SELECT id FROM my_distributors_warehouses_orders WHERE my_order_id = '.$this->params['my_order_id'].')';
        }

        $labels = $this->MyDistributorsWarehousesOrdersShippingLabel->find('all', array(
            'conditions'=>$conditions,
            'order'=>array('MyDistributorsWarehousesOrdersShippingLabel.created ASC'),
            'fields'=>array(
                'status', 'tracking_number', 'id', 'shipping_method', 'shipped', 'delivered', 'created', 'my_distributors_warehouses_order_id', 'return_label',
                'GROUP_CONCAT(DISTINCT `MyDistributorsWarehousesOrdersTrackingLog`.`status` ORDER BY `MyDistributorsWarehousesOrdersTrackingLog`.`id` DESC SEPARATOR "|") AS last_track',
                'GROUP_CONCAT(DISTINCT `MyDistributorsWarehousesOrdersTrackingLog`.`desc` ORDER BY `MyDistributorsWarehousesOrdersTrackingLog`.`id` DESC SEPARATOR "|") AS last_track_desc'
                ),
             'group'=>array('MyDistributorsWarehousesOrdersShippingLabel.id')
            ));

        echo "\n\nFound ".count($labels)." labels to process for tracking updates!";
        foreach ($labels as $key => $label) {
            $label['MyDistributorsWarehousesOrdersShippingLabel']['tracking_number'] = trim($label['MyDistributorsWarehousesOrdersShippingLabel']['tracking_number']);
            echo "\n + Processing ".$label['MyDistributorsWarehousesOrdersShippingLabel']['shipping_method']." label, tracking num = ".$label['MyDistributorsWarehousesOrdersShippingLabel']['tracking_number'] ." [".$label['MyDistributorsWarehousesOrdersShippingLabel']['created']."]";

            $label['last_track'] = $label[0]['last_track'];
            unset($label[0]['last_track']);
            $label['last_track_desc'] = $label[0]['last_track_desc'];
            unset($label[0]['last_track_desc']);
            $bgmc->doBackground("track_update", json_encode($label));
        }
    }

    function worker() {
        // primary worker, define method for a given job name
        $gmworker = new GearmanWorker();
        $gmworker->addOptions(GEARMAN_WORKER_GRAB_UNIQ);
        $gmworker->addServer('127.0.0.1', '4730');
        $gmworker->addFunction("track_update", array(
            $this,
            'track_update'
        ));
        $gmworker->setTimeout(3000);

        echo "Waiting for jobs...\n\033[0m";

        while (@$gmworker->work() || $gmworker->returnCode() == GEARMAN_TIMEOUT) {
            if ($gmworker->returnCode() == GEARMAN_TIMEOUT) {
                # Normally one would want to do something useful here ...
                echo "\nTimeout. Waiting for next job...\n";
                continue;
            }

            if ($gmworker->returnCode() != GEARMAN_SUCCESS) {
                echo "\nError. Return code: " . $gmworker->returnCode() . "\n";
                break;
            }
        }
    }

    // get the updated track info
    function track_update($job) {
        $gmc = new GearmanClient();
        $gmc->addServer('127.0.0.1', '4730');

        $workload = json_decode($job->workload());
        echo "\nSTART " . $job->unique() . " | LABEL ID " . $workload->MyDistributorsWarehousesOrdersShippingLabel->id . ", MDWO ID ".$workload->MyDistributorsWarehousesOrdersShippingLabel->my_distributors_warehouses_order_id." [".$workload->MyDistributorsWarehousesOrdersShippingLabel->shipping_method." / ".$workload->MyDistributorsWarehousesOrdersShippingLabel->tracking_number."] @ " . date("Y-m-d H:i:s");


        // make sure we stay connected
        $this->_checkDBConn('MyDistributorsWarehousesOrdersShippingLabel');

        $shipping_method = $workload->MyDistributorsWarehousesOrdersShippingLabel->shipping_method;
        $tracking_number = $workload->MyDistributorsWarehousesOrdersShippingLabel->tracking_number;
        $label_id = $workload->MyDistributorsWarehousesOrdersShippingLabel->id;
        $status = $workload->MyDistributorsWarehousesOrdersShippingLabel->status;
        $shipped =  $workload->MyDistributorsWarehousesOrdersShippingLabel->shipped;
        $my_distributors_warehouses_order_id = $workload->MyDistributorsWarehousesOrdersShippingLabel->my_distributors_warehouses_order_id;
        $last_track = '';
        $last_track_a = explode("|",$workload->last_track);
        if(is_array($last_track_a)) $last_track = $last_track_a[0];
        $last_track_desc_arr = explode("|",$workload->last_track_desc);

        // get various libraries
        App::import('Component', 'Fedex');
        $this->Fedex = new FedexComponent();
        App::import('Component', 'Ups');
        $this->Ups = new UpsComponent();
        App::import('Component', 'FreightQuote');
        $this->FreightQuote = new FreightQuoteComponent();

        $updates = array();
        if($shipping_method == 'Fedex') {
            // for freight down the road
            //$update = $this->Fedex->getFreightTracking(array('TrackingNumber'=>$tracking_number));
            $updates[] = $this->Fedex->getTracking(array('TrackingNumber'=>$tracking_number));
        }else if($shipping_method == 'UPS') {
            $updates[] = $this->Ups->track($tracking_number);
        }else if($shipping_method == 'FreightQuote') {
            $updates = $this->FreightQuote->getTracking($tracking_number);
        }

        if(!empty($updates)) {
            foreach ($updates as $update) {
                if (isset($update['status'])) {
                    $this->MyDistributorsWarehousesOrdersShippingLabel->updateTrackingInfo($label_id, $update);
                    if (in_array($update['status'], $this->delivered_statuses) && empty($workload->MyDistributorsWarehousesOrdersShippingLabel->delivered)) {
                        echo "\n   |- Delivered Label #" . $label_id . " [" . $update['status'] . "]";

                        $this->MyDistributorsWarehousesOrdersShippingLabel->query("UPDATE my_distributors_warehouses_orders_shipping_labels SET shipped='1', delivered='1', delivery_date='" . $update['created'] . "' WHERE id = '" . $label_id . "'");
                        //Check if this is a return label and update warehouse order return status to "Return Finalized" i.e. 2 and add to order log
                        if ($workload->MyDistributorsWarehousesOrdersShippingLabel->return_label == 1) {
                            // save the return_status as 2 for this warehouse_order
                            $wo = $this->MyDistributorsWarehousesOrder->find('first', [
                                'fields' => 'MyDistributorsWarehousesOrder.return_status, MyDistributorsWarehousesOrder.my_order_id',
                                'conditions' => [
                                    'MyDistributorsWarehousesOrder.id' => $my_distributors_warehouses_order_id
                                ],
                            ]);

                            //check if order is added to queue or not
                            $refund_que = $this->MyOrder->find('first', array('fields' => 'MyOrder.id', 'conditions' => array('MyOrder.id' => $wo['MyDistributorsWarehousesOrder']['my_order_id'],'MyOrder.refund_queue'=>'0')));
                            // add to refund queue. if added to queue
                            if(!empty($refund_que)){

                                $this->MyOrder->query('UPDATE my_orders SET refund_queue = "1" WHERE id='.$wo['MyDistributorsWarehousesOrder']['my_order_id']);
                            }
                            $prev_status = $this->MyOrderReturnStatus->find('first', array(
                                'fields' => 'MyOrderReturnStatus.return_status',
                                'conditions' => array('id' => $wo['MyDistributorsWarehousesOrder']['return_status'])
                            ));
                            $curr_status = $this->MyOrderReturnStatus->find('first', array(
                                'fields' => 'MyOrderReturnStatus.return_status',
                                'conditions' => array('id' => 2)
                            ));
                            // Get previous value current value -end
                            $logData = array(
                                'order_id' => $wo['MyDistributorsWarehousesOrder']['my_order_id'],
                                'my_distributors_warehouses_order_id' => $my_distributors_warehouses_order_id,
                                'original_value' => $prev_status['MyOrderReturnStatus']['return_status'],
                                'current_value' => $curr_status['MyOrderReturnStatus']['return_status']
                            );
                            addOrderLog($logData, LogTypeEnumComponent::$ReturnStatusChanged);
                            $this->MyDistributorsWarehousesOrder->id = $my_distributors_warehouses_order_id;
                            $this->MyDistributorsWarehousesOrder->save(array(
                                    'return_status' => 2
                                ));
                        }
                    } else if (in_array($update['status'], $this->shipped_statuses) && empty($workload->MyDistributorsWarehousesOrdersShippingLabel->shipped)) {
                        echo "\n   |- Shipped Label #" . $label_id . " [" . $update['status'] . "]";
                        //Update workload shipped=1 so that label is not set as shipped again for different status
                        $workload->MyDistributorsWarehousesOrdersShippingLabel->shipped = 1;
                        $this->MyDistributorsWarehousesOrdersShippingLabel->query("UPDATE my_distributors_warehouses_orders_shipping_labels SET shipped='1', shipped_date='" . $update['created'] . "' WHERE id = '" . $label_id . "'");
                    } else if (!in_array($update['status'], $this->ignore_statuses) && empty($workload->MyDistributorsWarehousesOrdersShippingLabel->shipped) && empty($workload->MyDistributorsWarehousesOrdersShippingLabel->delivered)) {
                        echo "\n   |- Unknown Status Label #" . $label_id . " [" . $update['status'] . "]";
                    }

                    // only insert a new record if the status has changed
                    if ($update['status'] != $last_track || (!empty($update['desc']))) {
                        if(empty($update['desc']) || (!empty($update['desc']) && !in_array($update['desc'],$last_track_desc_arr))) {
                            echo ".";
                            $save = array(
                                'status' => $update['status'],
                                'my_distributors_warehouses_orders_shipping_label_id' => $label_id
                            );
                            if (!empty($update['desc'])) {
                                $save['desc'] = $update['desc'];
                            }
                            $this->MyDistributorsWarehousesOrdersTrackingLog->create();
                            $this->MyDistributorsWarehousesOrdersTrackingLog->save($save);
                        }
                    } else {
                        echo "-";
                    }
                }
            }
        }
    }

    // updates each warehouse order status as shipped
    function set_shipped() {
        echo "\n".str_repeat("-", 100)."\nRunning set_shipped";

        // get the components ready
        App::import('Controller');
        App::import('Component', 'Email');
        App::import('Component', 'LogTypeEnum');
        $this->Controller = new Controller();
        $this->Email = new EmailComponent();
        $this->Email->startup($this->Controller);

        //Warehouse bind
        $this->MyDistributorsWarehousesOrdersShippingLabel->unbindAll();
        $this->MyDistributorsWarehousesOrdersShippingLabel->recursive = -1;
        $this->MyDistributorsWarehousesOrder->unbindAll();
        $this->MyDistributorsWarehousesOrder->bindModel(array(
            'belongsTo' => array(
                'MyOrder' => array('MyOrder'=>'my_order_id'),
                'MyCustomer' => array(
                    'foreignKey' => false,
                    'conditions' => array('MyOrder.my_customer_id = MyCustomer.id')
                    )
                )
            ));

        $conditions = array(/*'MyDistributorsWarehousesOrder.shipped' => 0,*/ //SIM-1733
                            'DATE(MyDistributorsWarehousesOrder.created) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)',
                            "(MyOrder.effective_date IS NULL OR DATE(MyOrder.effective_date) >= CURDATE() OR (CURDATE() > DATE(MyOrder.effective_date) && MyOrder.status = 'Processed') )",
                            'MyOrder.status NOT IN ("Void","CC","Shipped","Fraud","Completed")'
                        );
        if(!empty($this->params['my_order_id'])) {
            $conditions[] = 'MyDistributorsWarehousesOrder.my_order_id = '.$this->params['my_order_id'];
        }

        // Orders that have not been tagged as shipped
        $wos = $this->MyDistributorsWarehousesOrder->find('all', array(
            'conditions' => $conditions,
            'order' => 'MyOrder.id ASC',
            'fields' => array(
                    'MyDistributorsWarehousesOrder.id',
                    'MyDistributorsWarehousesOrder.ship_notified',
                    'MyOrder.id',
                    'MyOrder.source',
                    'MyOrder.status',
                    'MyOrder.shipping_fname',
                    'MyOrder.shipping_lname',
                    'MyOrder.shipping_company',
                    'MyOrder.shipping_address1',
                    'MyOrder.shipping_address2',
                    'MyOrder.shipping_city',
                    'MyOrder.shipping_state',
                    'MyOrder.shipping_zip',
                    'MyOrder.wholesale_id',
                    'MyCustomer.email'
                )
            ));

        echo "\n\nFound ".count($wos)." orders to process for shipment!";

        //Loop through each warehouse order
        foreach ($wos as $key => $wo) {
            echo "\n + Order #".$wo['MyOrder']['id'] ." - ".$wo['MyOrder']['source']." [".$wo['MyOrder']['status']."] to ". $wo['MyOrder']['shipping_city'] .", ".$wo['MyOrder']['shipping_state'] ." ".$wo['MyOrder']['shipping_zip'];

            $labels = $this->MyDistributorsWarehousesOrdersShippingLabel->find('all', array(
                'conditions' => array(
                        'MyDistributorsWarehousesOrdersShippingLabel.my_distributors_warehouses_order_id' => $wo['MyDistributorsWarehousesOrder']['id'],
                        'NOT' => array('MyDistributorsWarehousesOrdersShippingLabel.status' => 'Cancelled',
                                        'MyDistributorsWarehousesOrdersShippingLabel.shipping_method' => 'Walmart',
                                        'MyDistributorsWarehousesOrdersShippingLabel.return_label' => '1')
                    ),
                'fields' => array('id', 'shipped', 'tracking_number', 'shipping_method', 'shipped_date')
                ));

            if (!(empty($labels))) {
                $carrier = $labels[0]['MyDistributorsWarehousesOrdersShippingLabel']['shipping_method'];
                $labels_shipped = Set::extract('/MyDistributorsWarehousesOrdersShippingLabel/shipped', $labels);
                $labels_shipped_date = Set::extract('/MyDistributorsWarehousesOrdersShippingLabel/shipped_date', $labels);
                $tracking_numbers = Set::extract('/MyDistributorsWarehousesOrdersShippingLabel/tracking_number', $labels);

                $is_shipped = false;
                $shipped_at = max($labels_shipped_date);
                if($wo['MyOrder']['source'] == 'Simple') {
                    $tracking_link = 'https://simpletire.com?track_order='.bin2hex($wo['MyOrder']['id']).'&track_shipping_zip='.bin2hex($wo['MyOrder']['shipping_zip']);
                    $this->Controller->set('tracking_link', $tracking_link);   
                }



                //Marking warehouse order as shipped & email them notified.
                if(in_array(0, $labels_shipped)) {
                    // skip
                } else if(empty($wo['MyCustomer']['email']) ||
                            $wo['MyOrder']['source'] == 'WalMart' ||
                            !empty($wo['MyOrder']['wholesale_id']) ||
                            $wo['MyDistributorsWarehousesOrder']['ship_notified'] == '1') {
                                $is_shipped = true;
                                echo "\n   |- Warehouse Order # " . $wo['MyDistributorsWarehousesOrder']['id'] . " skipping email send!";
                } else {
                    $this->Email->reset();

                    $this->Controller->set('carrier', $carrier);
                    $this->Controller->set('order', $wo['MyOrder']);
                    $this->Controller->set('tracking_numbers', $tracking_numbers);
                    $this->Email->to = trim($wo['MyCustomer']['email']);
                    $this->Email->subject = 'Shipment for SimpleTire Order # : ' . $wo['MyOrder']['id'];
                    $this->Email->from = 'info@simpletire.com';
                    $this->Email->template = 'customer_order_shipped';
                    $this->Email->sendAs = 'html';
                    $this->Email->delivery = 'smtp';
                    $this->Email->send();

                    $logData = array(
                        'order_id' => $wo['MyOrder']['id'],
                        'my_distributors_warehouses_order_id' => $wo['MyDistributorsWarehousesOrder']['id'],
                        'current_value' => $this->Email->to
                    );
                    addOrderLog($logData,LogTypeEnumComponent::$SendCustomerShipped);

                    $is_shipped = true;
                }

                if($is_shipped) {
                    // save the shipped for this item
                    $this->MyDistributorsWarehousesOrder->id = $wo['MyDistributorsWarehousesOrder']['id'];
                    $this->MyDistributorsWarehousesOrder->save(array(
                        'shipped' => 1,
                        'fulfill_shipped_at' => $shipped_at,
                        'status' => 'TRANSIT',
                        'ship_notified' => 1)
                    );
                    echo "\n   |- Warehouse Order # " . $wo['MyDistributorsWarehousesOrder']['id'] . " is shipped @ $shipped_at & notified!";
                    // todo: check and update main order status if all have shipped, for now just assume if one label shipped mark status
                    $this->updateOrderStatus($wo['MyOrder']['id'],'Shipped','TRANSIT');
                }
            }
        }
    }

    function updateOrderStatus($order_id,$order_status,$distributor_status) {
        $res = $this->MyOrder->query("SELECT count(status) as count FROM my_distributors_warehouses_orders WHERE status <> '".$distributor_status."' AND my_order_id = ".$order_id);
        if($res[0][0]['count'] == 0) {
            $this->MyOrder->query("UPDATE my_orders SET status='".$order_status."' WHERE id = $order_id");
        }
    }

    function delivery_notice_test() {
        // get the components ready
        App::import('Controller');
        App::import('Component', 'Email');
        App::import('Component', 'LogTypeEnum');
        $this->Controller = new Controller();
        $this->Email = new EmailComponent();
        $this->Email->startup($this->Controller);

        $this->delivery_notice($this->params['my_order_id']);
    }

    function delivery_notice($woid){
        if(empty($woid)) {
            echo "No WOID Set!";
            return;
        }
        echo "\n   |- Get Shipping and Customer details for Warehouse Order # ".$woid;

        $this->MyDistributorsWarehousesOrder->unbindAll();
        $this->MyDistributorsWarehousesOrder->bindModel(array(
            'belongsTo' => array(
                'MyOrder' => array('MyOrder'=>'my_order_id'),
                'MyCustomer' => array(
                    'foreignKey' => false,
                    'conditions' => array('MyOrder.my_customer_id = MyCustomer.id')
                )
            )
        ));

        $conditions = array('MyDistributorsWarehousesOrder.id' => $woid,'MyOrder.wholesale_id is NULL','MyOrder.status NOT IN ("Void","CC","Fraud")','MyOrder.source != "WalMart"');

        // Get Shipping and customer details of that order
        $warehouse_orders = $this->MyDistributorsWarehousesOrder->find('all', array(
            'conditions' => $conditions,
            'fields' => array(
                'MyDistributorsWarehousesOrder.id',
                'MyDistributorsWarehousesOrder.delivery_date',
                'MyOrder.id',
                'MyOrder.my_installer_id',
                'MyOrder.shipping_fname',
                'MyOrder.shipping_lname',
                'MyOrder.shipping_company',
                'MyOrder.shipping_address1',
                'MyOrder.shipping_address2',
                'MyOrder.shipping_city',
                'MyOrder.shipping_state',
                'MyOrder.shipping_zip',
                'MyOrder.shipping_phone',
                'MyCustomer.fname',
                'MyCustomer.lname',
                'MyCustomer.email'
                )
            ));
        if(empty($warehouse_orders)) {
            echo "\n   |- No MyDistributorsWarehousesOrders Found!";
        } else {
            foreach($warehouse_orders as $wok => $wov){

                $delivery_address = ($wov['MyOrder']['shipping_fname'] ? $wov['MyOrder']['shipping_fname'] : '') . " " . ($wov['MyOrder']['shipping_lname'] ? $wov['MyOrder']['shipping_lname'] : '');
                if (trim($delivery_address) != "") {
                    $delivery_address .= "\n";
                } else {
                    $delivery_address = "";
                }
                if ($wov['MyOrder']['shipping_company'] != "") {
                    $delivery_address .= trim($wov['MyOrder']['shipping_company']) . "\n";
                }
                if ($wov['MyOrder']['shipping_address1'] != "") {
                    $delivery_address .= trim($wov['MyOrder']['shipping_address1']) . "\n";
                }
                if ($wov['MyOrder']['shipping_address2'] != "") {
                    $delivery_address .= trim($wov['MyOrder']['shipping_address2']) . "\n";
                }
                $delivery_address .= trim($wov['MyOrder']['shipping_city']) . ", " . trim($wov['MyOrder']['shipping_state']) . " " . trim($wov['MyOrder']['shipping_zip']) . "\n";
                if ($wov['MyOrder']['shipping_phone'] != "") {
                    $delivery_address .= trim($wov['MyOrder']['shipping_phone']);
                }

                $this->Email->reset();
                $this->Controller->set('customer_name', $wov['MyCustomer']['fname'] . " " . $wov['MyCustomer']['lname']);
                $this->Controller->set('my_installer_id', $wov['MyOrder']['my_installer_id']);

                $this->Controller->set('delivery_address', $delivery_address);
                $this->Controller->set('date_of_delivery', est_short_date(trim($wov['MyDistributorsWarehousesOrder']['delivery_date'])));

                $this->Email->to = trim($wov['MyCustomer']['email']);
                $subject = "Your SimpleTire.com Order Has Been Delivered";

                $this->Email->delivery = 'smtp';
                $this->Email->subject = $subject;
                $this->Email->from = 'info@simpletire.com';
                $this->Email->template = 'shipping_delivery_notice';
                $this->Email->sendAs = 'html';

                if($this->Email->send()) {
                    echo "\n      \- Email Sent Successfully to ".$this->Email->to.".\n\n";

                    $logData = array(
                        'order_id' => $wov['MyOrder']['id'],
                        'my_distributors_warehouses_order_id' => $woid,
                        'current_value' => $this->Email->to
                    );
                    addOrderLog($logData,LogTypeEnumComponent::$SendCustomerDelivered);
                }else{
                    echo "\n      \- Email NOT Sent to ".$this->Email->to.".\n\n";

                    $logData = array(
                        'order_id' => $wov['MyOrder']['id'],
                        'my_distributors_warehouses_order_id' => $woid,
                        'original_value' => 'Failed email send.',
                        'current_value' => $this->Email->to
                    );
                    addOrderLog($logData,LogTypeEnumComponent::$SendCustomerDelivered);
                }
            }
        }
    }

    function test_set_delivered(){
        echo " Running test for set delivered method! \n";
        $this->set_delivered($this->params['order_id'],$this->params['limit']);
    }

    function set_delivered($order_id=null,$limit=null){
        // get the components ready
        App::import('Component', 'LogTypeEnum');

        echo "Locate orders Shipped with 50% delivered labels.\n";
        $sql = "SELECT
                    MyOrder.id,
                    MyDistributorsWarehousesOrder.id,
                    MyOrder.created,
                    DATEDIFF(CURDATE(), MyOrder.created) AS diff_days,
                    DATEDIFF(CURDATE(), MAX(MyDistributorsWarehousesOrdersShippingLabels.delivery_date)) AS diff_delivery_days,
                    SUM(IF(MyDistributorsWarehousesOrdersShippingLabels.delivered = '1',
                        1,
                        0)) AS num_delivered_labels,
                    SUM(IF(MyDistributorsWarehousesOrdersShippingLabels.shipped = '1',
                        1,
                        0)) AS shipped_labels,
                    COUNT(MyDistributorsWarehousesOrdersShippingLabels.id) AS num_labels,
                    MAX(MyDistributorsWarehousesOrdersShippingLabels.delivery_date) AS delivery_date
                FROM
                    my_distributors_warehouses_orders MyDistributorsWarehousesOrder
                        INNER JOIN
                    my_orders MyOrder ON MyDistributorsWarehousesOrder.my_order_id = MyOrder.id
                        INNER JOIN
                    my_distributors_warehouses_orders_shipping_labels MyDistributorsWarehousesOrdersShippingLabels ON MyDistributorsWarehousesOrdersShippingLabels.my_distributors_warehouses_order_id = MyDistributorsWarehousesOrder.id
                        AND MyDistributorsWarehousesOrdersShippingLabels.status = 'Active'
                        AND MyDistributorsWarehousesOrdersShippingLabels.shipping_method NOT IN ('Walmart' , 'Other', 'Other_Ground')
                WHERE
                    MyDistributorsWarehousesOrder.status IN('Transit','Scheduled') and MyDistributorsWarehousesOrder.fulfill_shipped_at IS NOT NULL ";
        if(!empty($order_id) && $order_id>0){
         $sql=$sql."AND MyOrder.id=".$order_id; 
        }
        $sql=$sql." GROUP BY MyDistributorsWarehousesOrder.id
                HAVING (num_delivered_labels >= num_labels / 2 AND diff_delivery_days >= 3)
                    OR (num_delivered_labels > 0 AND diff_delivery_days >= 10)
                    OR (num_delivered_labels = num_labels)
                    OR (shipped_labels >= num_labels/2)
                ORDER BY MyOrder.id ASC ";
        if(!empty($limit) && $limit>0){
          $sql=$sql."LIMIT ".$limit;    
        }
        if(!empty($this->params['debug']) && $this->params['debug']){
            echo $sql."\n";
        }else{
         $orders = $this->MyOrder->query($sql);
        }

        echo "\n\nFound ".count($orders)." orders to process for delivery!";
        foreach($orders as $ordk => $ordv){
            $ordv[0]['diff_delivery_days']=abs($ordv[0]['diff_delivery_days']);
            echo "\n + Delivery for Order #".$ordv['MyOrder']['id']."/".$ordv['MyDistributorsWarehousesOrder']['id'].", ".$ordv[0]['num_delivered_labels']." of ".$ordv[0]['num_labels']." labels,number of labels Shippied ".$ordv[0]['shipped_labels'].", [".$ordv['MyOrder']['created'].", ".$ordv[0]['diff_days']."/".$ordv[0]['diff_delivery_days']." days]";
            $half_label_count=$ordv[0]['num_labels']/2;
            if($ordv[0]['num_labels'] == $ordv[0]['num_delivered_labels'] ||
                $ordv[0]['diff_delivery_days'] != 2 || ($ordv[0]['shipped_labels']>=$half_label_count && $ordv[0]['diff_delivery_days'] >= 1)) {
                if(isset($ordv[0]['delivery_date']) && $ordv[0]['delivery_date']!=''){
                $sql = "UPDATE my_distributors_warehouses_orders SET status = 'DELIVERED', delivered='1', delivery_date='".$ordv[0]['delivery_date']."', fulfill_delivered_at='".$ordv[0]['delivery_date']."' WHERE id = '".$ordv['MyDistributorsWarehousesOrder']['id']."'";
                $this->MyOrder->query($sql);
                $this->updateOrderStatus($ordv['MyOrder']['id'],'Completed','DELIVERED');
               }
            }else{
                echo "\n   |- Skipping, 3 days or more to assume delivered.";
            }
        }
        $this->send_order_delivery_notice($order_id);
    }

    public function test_send_order_delivery_notice() {
        if (!empty($this->params['orderId'])) {
            $orderId = (int) $this->params['orderId'];
            echo "Running Test for Send Order Delivery Notice method for Order:" . $orderId . "\n";
            $this->send_order_delivery_notice($orderId, $this->params['limit'], true);
        } else {
            exit("Empty OrderId passed\n");
        }
    }

    public function send_order_delivery_notice($order_id = null, $limit = null, $allowQaTesting = false) {
        App::import('Controller');
        App::import('Component', 'Email');
        $this->Controller = new Controller();
        $this->Email = new EmailComponent();
        $this->Email->startup($this->Controller);

        echo "Locate orders Shipped with 50% delivered labels.\n";
        $getOrdersSql = "SELECT
                    MyOrder.id,
                    MyDistributorsWarehousesOrder.id,
                    MyOrder.created,
                    DATEDIFF(CURDATE(), MyOrder.created) AS diff_days,
                    DATEDIFF(CURDATE(), MAX(MyDistributorsWarehousesOrdersShippingLabels.delivery_date)) AS diff_delivery_days,
                    SUM(IF(MyDistributorsWarehousesOrdersShippingLabels.delivered = '1',
                        1,
                        0)) AS num_delivered_labels,
                    SUM(IF(MyDistributorsWarehousesOrdersShippingLabels.shipped = '1',
                        1,
                        0)) AS shipped_labels,
                    COUNT(MyDistributorsWarehousesOrdersShippingLabels.id) AS num_labels,
                    MAX(MyDistributorsWarehousesOrdersShippingLabels.delivery_date) AS delivery_date
                FROM
                    my_distributors_warehouses_orders MyDistributorsWarehousesOrder
                        INNER JOIN
                    my_orders MyOrder ON MyDistributorsWarehousesOrder.my_order_id = MyOrder.id
                        INNER JOIN
                    my_distributors_warehouses_orders_shipping_labels MyDistributorsWarehousesOrdersShippingLabels ON MyDistributorsWarehousesOrdersShippingLabels.my_distributors_warehouses_order_id = MyDistributorsWarehousesOrder.id
                        AND MyDistributorsWarehousesOrdersShippingLabels.status = 'Active'
                        AND MyDistributorsWarehousesOrdersShippingLabels.shipping_method NOT IN ('Walmart' , 'Other', 'Other_Ground') WHERE";

        if (!$allowQaTesting) {
            $getOrdersSql .= " MyDistributorsWarehousesOrder.status IN ('Transit','Scheduled') AND MyDistributorsWarehousesOrder.fulfill_shipped_at IS NOT NULL";
            if (!empty($order_id) && $order_id > 0) {
                $getOrdersSql .= " AND MyOrder.id = {$order_id}";
            }
        } else {
            $getOrdersSql .= " MyOrder.id = {$order_id}";
        }

        $getOrdersSql .= " GROUP BY MyOrder.id
                HAVING (num_delivered_labels >= num_labels/2 AND diff_delivery_days >= 3)
                    OR (num_delivered_labels > 0 AND diff_delivery_days >= 10)
                    OR (num_delivered_labels = num_labels)
                    OR (shipped_labels >= num_labels/2)
                ORDER BY MyOrder.id ASC ";

        if (!empty($limit) && $limit > 0) {
            $getOrdersSql .= "LIMIT " . $limit;
        }

        if (!empty($this->params['debug']) && $this->params['debug']) {
            echo $getOrdersSql . "\n";
        } else {
            $orders = $this->MyOrder->query($getOrdersSql);
        }

        echo "\n\nFound " . count($orders) . " orders to process for sending email notifications!";
        foreach($orders as $ordk => $ordv) {
            if ($allowQaTesting) {
                echo "\n\nNow executing delivery_notice method for orderId: " . $ordv['MyDistributorsWarehousesOrder']['id'];
                $this->delivery_notice($ordv['MyDistributorsWarehousesOrder']['id']);
            } else {
                $ordv[0]['diff_delivery_days'] = abs($ordv[0]['diff_delivery_days']);
                $half_label_count = $ordv[0]['num_labels'] / 2;
                if ($ordv[0]['num_labels'] == $ordv[0]['num_delivered_labels'] ||
                    $ordv[0]['diff_delivery_days'] != 2 || ($ordv[0]['shipped_labels'] >= $half_label_count && $ordv[0]['diff_delivery_days'] >= 1)) {
                    if ($ordv[0]['diff_delivery_days'] <= 1 && !empty($ordv[0]['delivery_date'])) {
                        $this->delivery_notice($ordv['MyDistributorsWarehousesOrder']['id']);
                    }
                }
            }
        }
    }

    function locate_no_delivery_or_labels(){
        echo "\n\nLocate orders Shipped but not Completed without Labels or local delivery.\n";
        $sql = "SELECT
                    MyOrder.id,
                    MyDistributorsWarehousesOrder.id,
                    MyOrder.created,
                    DATEDIFF(CURDATE(), MyOrder.created) AS diff_days,
                    MyDistributorsWarehousesOrder.delivered,
                    MyDistributorsWarehousesOrder.warehouse_delivers_confirmed,
                    COUNT(MyDistributorsWarehousesOrdersShippingLabels.id) AS labels
                FROM
                    my_distributors_warehouses_orders MyDistributorsWarehousesOrder
                        INNER JOIN
                    my_orders MyOrder ON MyDistributorsWarehousesOrder.my_order_id = MyOrder.id
                        LEFT JOIN
                    my_distributors_warehouses_orders_shipping_labels MyDistributorsWarehousesOrdersShippingLabels ON MyDistributorsWarehousesOrdersShippingLabels.my_distributors_warehouses_order_id = MyDistributorsWarehousesOrder.id
                        AND MyDistributorsWarehousesOrdersShippingLabels.status = 'Active'
                        AND MyDistributorsWarehousesOrdersShippingLabels.shipping_method NOT IN ('Walmart' , 'Other', 'Other_Ground')
                WHERE
                    MyDistributorsWarehousesOrder.status = 'Transit'
                GROUP BY MyDistributorsWarehousesOrder.id
                HAVING labels = 0
                ORDER BY MyOrder.created ASC";
        $orders = $this->MyOrder->query($sql);
        foreach($orders as $ordk => $ordv){
            echo "   |- Checking for Order #".$ordv['MyOrder']['id']." / local_delivery=".$ordv['MyDistributorsWarehousesOrder']['warehouse_delivers_confirmed']." [".$ordv['MyOrder']['created'].", ".$ordv[0]['diff_days']." days]\n";

            //TODO some sort of report?
        }
    }

    function set_shipped_completed(){
        echo "Locate orders Shipped but not Completed.\n";
        $sql = "SELECT
                    MyOrder.id,
                    MyDistributorsWarehousesOrder.id,
                    MyOrder.created,
                    DATEDIFF(CURDATE(),MyOrder.created) AS diff_days,
                    MyDistributorsWarehousesOrder.delivered
                FROM
                    my_distributors_warehouses_orders MyDistributorsWarehousesOrder
                        INNER JOIN
                    my_orders MyOrder ON MyDistributorsWarehousesOrder.my_order_id = MyOrder.id
                WHERE
                    MyOrder.status = 'Shipped'
                ORDER BY MyOrder.id ASC";
        $orders = $this->MyOrder->query($sql);
        echo " + Found ".count($orders)." orders to review.\n";

        foreach($orders as $ordk => $ordv){
            echo "   |- Checking for Order #".$ordv['MyOrder']['id']." [".$ordv['MyOrder']['created'].", ".$ordv[0]['diff_days']." days]\n";
            $delivered = Set::extract('/MyDistributorsWarehousesOrder/delivered', $ordv);
            if(in_array(0, $delivered)) {
                echo "      \- Order #" . $ordv['MyOrder']['id'] . " is NOT Completed!\n";
            }else{
                $this->MyOrder->query("UPDATE my_orders SET status='Completed' WHERE id = ".$ordv['MyOrder']['id']);
                echo "      \- Order #" . $ordv['MyOrder']['id'] . " is Completed!\n";

                $this->MyOrder->query("UPDATE my_distributors_warehouses_orders SET status = 'DELIVERED', delivered='1', delivery_date='".date("Y-m-d", strtotime("yesterday"))."' WHERE id = '".$ordv['MyDistributorsWarehousesOrder']['id']."' AND status = 'TRANSIT'");
                echo "      \- Warehouse Order ".$ordv['MyDistributorsWarehousesOrder']['id']." in TRANSIT for Order #" . $ordv['MyOrder']['id'] . " marked as DELIVERED!\n";
            }
        }
    }

    function locate_fulfill_shipdeliv_stats(){
        echo "Locate orders missing shipping & delivery stats.\n";

        $last_id = 0;
        do {
            $sql = "SELECT
                        my_distributors_warehouses_orders.id,
                        my_distributors_warehouses_orders.my_order_id,
                        my_distributors_warehouses_orders.created,
                        my_distributors_warehouses_orders.ship_date,
                        my_distributors_warehouses_orders.delivery_date
                    FROM
                        my_distributors_warehouses_orders
                    WHERE
                        my_distributors_warehouses_orders.id > $last_id
                            AND my_distributors_warehouses_orders.created >= DATE_SUB(NOW(), INTERVAL 45 DAY)
                            AND my_distributors_warehouses_orders.status IN ('scheduled' , 'transit', 'delivered')
                            AND (my_distributors_warehouses_orders.fulfill_shipped_at IS NULL
                            OR my_distributors_warehouses_orders.fulfill_delivered_at IS NULL)
                    ORDER BY my_distributors_warehouses_orders.id ASC
                    LIMIT 500";
            $orders = $this->MyOrder->query($sql);
            echo "\n + Found ".count($orders)." orders to review.\n";

            foreach($orders as $ordk => $ordv){
                echo "\n   |- Checking for Order #".$ordv['my_distributors_warehouses_orders']['my_order_id']." [created=".$ordv['my_distributors_warehouses_orders']['created']."]";

                $sql = "SELECT
                            my_distributors_warehouses_orders_shipping_labels.id,
                            my_distributors_warehouses_orders_tracking_logs.*
                        FROM
                            my_distributors_warehouses_orders_shipping_labels
                                INNER JOIN
                            my_distributors_warehouses_orders_tracking_logs ON my_distributors_warehouses_orders_shipping_labels.id = my_distributors_warehouses_orders_tracking_logs.my_distributors_warehouses_orders_shipping_label_id
                        WHERE
                            my_distributors_warehouses_orders_shipping_labels.my_distributors_warehouses_order_id = ".$ordv['my_distributors_warehouses_orders']['id'] ."
                             AND my_distributors_warehouses_orders_shipping_labels.shipping_method != 'Walmart'
                             AND my_distributors_warehouses_orders_shipping_labels.status = 'Active'
                             AND my_distributors_warehouses_orders_shipping_labels.return_label != 1
                        ORDER BY my_distributors_warehouses_orders_tracking_logs.created ASC";
                $labels = $this->MyOrder->query($sql, false);
                $shipped = $delivered = false;
                foreach($labels as $l) {
                    $date = $l['my_distributors_warehouses_orders_tracking_logs']['created'];
                    if(!$shipped && in_array(trim($l['my_distributors_warehouses_orders_tracking_logs']['status']),$this->shipped_statuses)){
                        $shipped = $date;
                    }elseif(!$delivered && in_array(trim($l['my_distributors_warehouses_orders_tracking_logs']['status']),$this->delivered_statuses)){
                        $delivered = empty($ordv['my_distributors_warehouses_orders']['delivery_date']) ? $date : $ordv['my_distributors_warehouses_orders']['delivery_date'];
                    }
                }
                if($shipped || $delivered) {
                    if(empty($shipped) && !empty($delivered)) $shipped = $delivered;
                    echo " = shipped on $shipped, delivered on $delivered";
                    $sql = "UPDATE my_distributors_warehouses_orders SET fulfill_shipped_at='".$shipped."' ";
                    if(!empty($delivered)) $sql .= ", fulfill_delivered_at='".$delivered."' ";
                    $sql .= " WHERE id = ".$ordv['my_distributors_warehouses_orders']['id'];

                    $this->MyOrder->query($sql, false);
                }

                $last_id = $ordv['my_distributors_warehouses_orders']['id'];
            }
        } while(!empty($orders));
    }

    function locate_fulfill_stats(){
        echo "Locate orders missing fulfill stats.\n";
        $sql = "SELECT
                    MyDistributorsWarehousesOrder.id,
                    MyDistributorsWarehousesOrder.my_order_id,
                    MyDistributorsWarehousesOrder.created,
                    MyDistributorsWarehousesOrder.status,
                    MyDistributorsWarehousesOrder.ship_date,
                    MyDistributorsWarehousesOrder.fulfill_assigned_at,
                    MyDistributorsWarehousesOrder.fulfill_picked_at,
                    MyDistributorsWarehousesOrder.fulfill_downloaded_at
                FROM
                    my_distributors_warehouses_orders MyDistributorsWarehousesOrder
                WHERE
                    status IN ('ready', 'scheduled', 'transit')
                        AND (fulfill_assigned_at IS NULL
                        OR fulfill_downloaded_at IS NULL
                        OR fulfill_picked_at IS NULL)
                ORDER BY MyDistributorsWarehousesOrder.id ASC";
        $orders = $this->MyOrder->query($sql);
        echo " + Found ".count($orders)." orders to review.\n";

        foreach($orders as $ordk => $ordv){
            echo "\n   |- Checking for Order #".$ordv['MyDistributorsWarehousesOrder']['my_order_id']." [created=".$ordv['MyDistributorsWarehousesOrder']['created']."] [assigned=".$ordv['MyDistributorsWarehousesOrder']['fulfill_assigned_at']."] [downloaded=".$ordv['MyDistributorsWarehousesOrder']['fulfill_downloaded_at']."] [picked=".$ordv['MyDistributorsWarehousesOrder']['fulfill_picked_at']."]";
            if(empty($ordv['MyDistributorsWarehousesOrder']['fulfill_assigned_at'])){
                $log = $this->MyOrder->query('SELECT created FROM my_order_history_logs WHERE log_type_id = 27 AND my_distributors_warehouses_order_id = '.$ordv['MyDistributorsWarehousesOrder']['id'].' ORDER BY id DESC LIMIT 1');
                if(!empty($log[0]['my_order_history_logs']['created'])) {
                    $sql = 'UPDATE my_distributors_warehouses_orders SET fulfill_assigned_at = "'.$log[0]['my_order_history_logs']['created'].'" WHERE id = "'.$ordv['MyDistributorsWarehousesOrder']['id'].'"';
                    $this->MyOrder->query($sql);
                }else{
                    $sql = 'UPDATE my_distributors_warehouses_orders SET fulfill_assigned_at = "'.$ordv['MyDistributorsWarehousesOrder']['created'].'" WHERE id = "'.$ordv['MyDistributorsWarehousesOrder']['id'].'"';
                    $this->MyOrder->query($sql);
                }
            }
            if(empty($ordv['MyDistributorsWarehousesOrder']['fulfill_downloaded_at'])){
                $log = $this->MyOrder->query('SELECT created FROM my_order_history_logs WHERE log_type_id = 38 AND my_distributors_warehouses_order_id = '.$ordv['MyDistributorsWarehousesOrder']['id'].' ORDER BY id DESC LIMIT 1');
                if(!empty($log[0]['my_order_history_logs']['created'])) {
                    $sql = 'UPDATE my_distributors_warehouses_orders SET fulfill_downloaded_at = "'.$log[0]['my_order_history_logs']['created'].'" WHERE id = "'.$ordv['MyDistributorsWarehousesOrder']['id'].'"';
                    $this->MyOrder->query($sql);
                }
            }
            // if(empty($ordv['MyDistributorsWarehousesOrder']['fulfill_rejected_at'])){
            //  $log = $this->MyOrder->query('SELECT created FROM my_order_history_logs WHERE log_type_id = 39 AND my_distributors_warehouses_order_id = '.$ordv['MyDistributorsWarehousesOrder']['id'].' ORDER BY id DESC LIMIT 1');
            //  if(!empty($log[0]['my_order_history_logs']['created'])) {
            //      $sql = 'UPDATE my_distributors_warehouses_orders SET fulfill_rejected_at = "'.$log[0]['my_order_history_logs']['created'].'" WHERE id = "'.$ordv['MyDistributorsWarehousesOrder']['id'].'"';
            //      $this->MyOrder->query($sql);
            //  }
            // }
            if(empty($ordv['MyDistributorsWarehousesOrder']['fulfill_picked_at']) && $ordv['MyDistributorsWarehousesOrder']['ship_date'] != '0000-00-00 00:00:00'){
                $sql = 'UPDATE my_distributors_warehouses_orders SET fulfill_picked_at = "'.$ordv['MyDistributorsWarehousesOrder']['ship_date'].'" WHERE id = "'.$ordv['MyDistributorsWarehousesOrder']['id'].'"';
                $this->MyOrder->query($sql);
            }
        }
    }

    function populate_sizes(){
        $size_condition = !empty($this->params['qs']) ? " AND my_products.quick_search = ".$this->params['qs'] : "";
        $sql = "SELECT
                    my_products.quick_search,
                    my_products.width,
                    my_products.ratio,
                    my_products.rim,
                    MIN(my_products.weight) AS min_weight,
                    MAX(my_products.weight) AS max_weight,
                    AVG(my_products.weight) AS avg_weight,
                    COUNT(my_products.id) AS num_products,
                    SUM(my_order_products.quantity) AS qty_sold_90d,
                    SUM(IF(my_order_products.id,
                                my_products.weight * my_order_products.quantity,
                                0)) / SUM(my_order_products.quantity) AS avg_weight_90d
                FROM
                    my_products
                        LEFT JOIN
                    my_order_products ON my_order_products.my_product_id = my_products.id
                        AND DATE_SUB(CURDATE(), INTERVAL 90 DAY) <= my_order_products.created
                WHERE
                    my_products.deleted IS NULL $size_condition
                GROUP BY my_products.quick_search
                ORDER BY my_products.quick_search";
        $products = $this->MyOrder->query($sql, false);
        echo "Found ".count($products)." sizes to review.";
        foreach($products as $p) {
            echo "\n\n + ".$p['my_products']['quick_search']." - ".$p['my_products']['width']."/".$p['my_products']['ratio'].$p['my_products']['rim'];
            $dims = tireDimensions($p['my_products']['width'], $p['my_products']['ratio'], $p['my_products']['rim']);
            if($dims['width'] && $dims['height'] && $dims['length']){
                $dim_weight = dimWeight($dims['width'], $dims['height'], $dims['length'], 139);
                $dim_weight2 = dimWeight($dims['width'], $dims['height'], $dims['length'], 166);
                echo "\n   - set the old dim_weight to $dim_weight, was $dim_weight2, using ".$dims['width']."w x ". $dims['height'] ."h x ". $dims['length'] ."l";

                $dimsn = tireDims($p['my_products']['width'], $p['my_products']['ratio'], $p['my_products']['rim']);
                if($dimsn['width'] && $dimsn['height'] && $dimsn['length']){
                    $locked_dimc = $locked_dimc_weight = null;
                    $check_locked = $this->MyOrder->query("SELECT locked, dimc, dimc_weight FROM shipping_sizes WHERE qs='".$p['my_products']['quick_search']."'", false);
                    if(!empty($check_locked) && !empty($check_locked[0]['shipping_sizes']['locked'])) {
                        $locked_dimc = $check_locked[0]['shipping_sizes']['dimc'];
                        $locked_dimc_weight = $check_locked[0]['shipping_sizes']['dimc_weight'];
                    }

                    $dim_weightn = dimWeight($dimsn['width'], $dimsn['height'], $dimsn['length'], 139);
                    echo "\n   - set the dim_weight to $dim_weightn using ".$dimsn['width']."w x ". $dimsn['height'] ."h x ". $dimsn['length'] ."l";
                    if(!empty($locked_dimc_weight)) {
                        echo "\n   - override for locked weight = $locked_dimc_weight";
                        $dim_weightn = $locked_dimc_weight;
                    }

                    if(!empty($locked_dimc)){
                        echo "\n   - override for locked dims = $locked_dimc";
                        list($dim_length,$dim_width,$dim_height) = explode('x',$locked_dimc);
                        $dimsn['width'] = $dim_width;
                        $dimsn['height'] = $dim_height;
                        $dimsn['length'] = $dim_length;
                    }

                    $calced_weight = calcedWeight($dimsn['width'], $dimsn['height'], $dimsn['length']);
                    echo "\n   - calced weight would be $calced_weight";

                    $oversize_girth = getOversize($dimsn['width'], $dimsn['height'], $dimsn['length']);
                    $oversized = $dim_weightn < 150 && $oversize_girth >= 130 ? 1 : 0;
                    echo "\n   - oversize girth is $oversize_girth inches";
                    echo "\n   - oversized = ".$oversized;

                    $binding_info = $this->MyOrder->checkForBinding(
                            'Simple',
                            array('ship_carrier'=>'Fedex', 'tire_binding'=> '1'),
                            2,
                            $dim_weightn,
                            $dimsn['width'],
                            $dimsn['height'],
                            'Ground_Home_Delivery' //'Standard_Shipping'
                        );
                    $bind = !empty($binding_info['is_binding']) ? 1 : 0;
                    echo "\n   - bind-able = ".$bind;

                    $freight = $dim_weightn >= 150 ? 1 : 0;
                    echo "\n   - freight only = ".$freight;

                    $sql = "REPLACE INTO `shipping_sizes`
                            (
                                `qs`,
                                `updated`,
                                `locked`,
                                `width`,
                                `ratio`,
                                `rim`,
                                `min_weight`,
                                `max_weight`,
                                `avg_weight`,
                                `num_products`,
                                `qty_sold_90d`,
                                `avg_weight_90d`,
                                `dima`,
                                `dima_weight`,
                                `dimc`,
                                `dimc_weight`,
                                `calc_weight`,
                                `oversize_girth`,
                                `oversized`,
                                `freight`,
                                `bind`
                            )
                            VALUES
                            (
                                '".$p['my_products']['quick_search']."',
                                NOW(),
                                ".(empty($check_locked[0]['shipping_sizes']['locked']) ? "NULL" : "1").",
                                '".$p['my_products']['width']."',
                                '".$p['my_products']['ratio']."',
                                '".$p['my_products']['rim']."',
                                '".$p[0]['min_weight']."',
                                '".$p[0]['max_weight']."',
                                '".$p[0]['avg_weight']."',
                                '".$p[0]['num_products']."',
                                '".$p[0]['qty_sold_90d']."',
                                '".$p[0]['avg_weight_90d']."',
                                '".$dims['length']."x".$dims['width']."x".$dims['height']."',
                                '".$dim_weight."',
                                '".$dimsn['length']."x".$dimsn['width']."x".$dimsn['height']."',
                                '".$dim_weightn."',
                                '".$calced_weight."',
                                '".$oversize_girth."',
                                '".$oversized."',
                                '".$freight."',
                                '".$bind."'
                            )";
                        $this->MyOrder->query($sql, false);
                }else{
                    echo "\n   - cannot get dims";
                    print_r($dims);
                }
            }else{
                echo "\n   - cannot get dims";
                print_r($dims);
            }
        }
    }

    function _checkDBConn($model) {
        if (!mysql_ping($this->$model->getDatasource()->connection)) {
            $this->$model->getDatasource()->disconnect();
            $this->$model->getDatasource()->connect();
            $this->$model = getModel($model);
        }
    }
}
