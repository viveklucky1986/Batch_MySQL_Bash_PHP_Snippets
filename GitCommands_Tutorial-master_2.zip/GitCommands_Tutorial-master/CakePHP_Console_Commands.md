### CakePHP set 'app' directory path

```bash
cake -app absolute/path/to/app
cake -app /c/Users/WMIND2004/Projects/simple/frontend/app
```

### Execute Inventory Script functions:
```bash
cd /var/www/backend && ./cake_run inventory [name of function]
cd /var/www/backend && ./cake_run inventory update_catalog_qtyprice
cd /var/www/backend && ./cake_run inventory update_catalog_qtyprice -p_id 4702 > InitOutput.txt
cd /var/www/backend && ./cake_run inventory make_catalog_data_brandwise -p_id 4702 > InitOutput.txt
cd /var/www/backend && ./cake_run inventory update_catalog_qtyprice
cd /var/www/backend && ./cake_run inventory make_catalog_data_brandwise
cd /var/www/backend && ./cake_run inventory update_catalog_qtyprice && ./cake_run inventory make_catalog_data_brandwise
```

### Clear Cakephp UI(CSS & JS) Cache:
```BASH
cd /var/www/frontend/app && Console/cake AssetCompress.AssetCompress build --force
mkdir -m 777 /var/www/frontend/app/webroot/cache_js && mkdir -m 777 /var/www/frontend/app/webroot/cache_css
```
#### Or
```bash
cd [RepositoryPath]
cd /var/www/[RepositoryName]
rm -rf app/webroot/cache_js && rm -rf app/webroot/cache_css
mkdir -m 777 app/webroot/cache_js && mkdir -m 777 app/webroot/cache_css
app/Console/cake AssetCompress.AssetCompress build --force
```

### SimpleTire Cakephp Backend Order Automation Command ###
```bash
rm -Rf admin/tmp/cache/models/cake_model_default_*
./cake_run order_automation test -oid [OrderId]
./cake_run order_automation worker
rm -Rf admin/tmp/cache/models/cake_model_default_* && ./cake_run order_automation test -oid [MyOrderId] && ./cake_run order_automation worker
rm -Rf admin/tmp/cache/models/cake_model_default_*
./cake_run order_automation test -oid 1168480
./cake_run order_automation worker
rm -Rf admin/tmp/cache/models/cake_model_default_* && ./cake_run order_automation test -oid 1168480 && ./cake_run order_automation worker
```

### Execute Order Automation Process on Jenkins Staging Server ###
```bash
rm -Rf admin/tmp/cache/models/cake_model_default_*
./cake_run order_automation test -oid [OrderId]
./cake_run order_automation worker
```
```shell
rm -Rf admin/tmp/cache/models/cake_model_default_*
./cake_run order_automation test -oid [OrderId]
./cake_run order_automation worker
```
```bash
rm -Rf admin/tmp/cache/models/cake_model_default_* && ./cake_run order_automation test -oid [OrderId] && ./cake_run order_automation worker
rm -Rf admin/tmp/cache/models/cake_model_default_* && ./cake_run order_automation test -oid 1232403 && ./cake_run order_automation worker
```

### Execute Shipping Shell Script After Order Automation ###
#### Execute the below queries to set the delivered status to 1 to manually send the emails ####
```sql
UPDATE my_distributors_warehouses_orders_shipping_labels SET shipped = 1
WHERE created BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:59')
    AND modified BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:59')
    AND my_distributors_warehouses_order_id IN (SELECT id FROM my_distributors_warehouses_orders WHERE my_order_id = 1266800);

UPDATE my_distributors_warehouses_orders_shipping_labels SET shipped = 1
WHERE created BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:59')
    AND modified BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:59')
    AND my_distributors_warehouses_order_id IN (SELECT id FROM my_distributors_warehouses_orders WHERE my_order_id = 1266801);
		
UPDATE my_distributors_warehouses_orders_shipping_labels SET shipped = 1
WHERE created BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:59')
    AND modified BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:59')
    AND my_distributors_warehouses_order_id IN (SELECT id FROM my_distributors_warehouses_orders WHERE my_order_id = [OrderId]);
		
UPDATE my_distributors_warehouses_orders_shipping_labels SET shipped = 1, delivered = 1
WHERE created BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:59')
    AND modified BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:59')
    AND my_distributors_warehouses_order_id IN (SELECT id FROM my_distributors_warehouses_orders WHERE my_order_id IN ([CS List of OrderIds]));
```
#### Execute the below commands to manually send the delivery notification emails ####
```bash
rm -Rf admin/tmp/cache/models/cake_model_default_*
./cake_run shipping test_send_order_delivery_notice -orderId [OrderId]
```

### Execute shell script to set the Order 'Shipped' for Testing ###
```bash
rm -Rf admin/tmp/cache/models/cake_model_default_* && ./cake_run shipping set_shipped -orderId [OrderId]
rm -Rf admin/tmp/cache/models/cake_model_default_* && ./cake_run shipping set_shipped -my_order_id 1266804
rm -Rf admin/tmp/cache/models/cake_model_default_* && ./cake_run shipping set_shipped -my_order_id 1266804 -is_shipped 1
```

### Execute Shell Script for setting the Order Delivered for Testing ###
```bash
rm -Rf admin/tmp/cache/models/cake_model_default_* && ./cake_run shipping test_set_delivered -orderId [OrderId]
rm -Rf admin/tmp/cache/models/cake_model_default_* && ./cake_run shipping test_set_delivered -my_order_id 1266804
rm -Rf admin/tmp/cache/models/cake_model_default_* && ./cake_run shipping test_set_delivered -debug 1
rm -Rf admin/tmp/cache/models/cake_model_default_* && ./cake_run shipping set_delivered -debug 1
```

### ST Order Flow & Statuses ###
```
Main Order Statuses / Admin Order Status
NEW -> PROCESSED -> SHIPPED -> COMPLETED

Warehouse Order Status
Pending -> Ready -> Scheduled -> Transit -> Delivered
```
