### List out all Tables from the Database matching specific pattern in names ###
```mysql
USE `[DatabaseName]`;
USE `rpm_simpletire`;
SHOW TABLES LIKE '%[pattern]%';
SHOW TABLES LIKE '%sub_types%';
```

### Display all the information about particular Table in Database ###
```mysql
USE `[DatabaseName]`;
USE `rpm_simpletire`;
DESC [TableName];
DESC my_installer_product_sub_types;
```

### Get Column count from specific Table in Database ###
```mysql
SELECT count(*) FROM information_schema.columns WHERE table_name = '[TableName]';
SELECT count(*) FROM information_schema.columns WHERE table_name = 'my_product_sub_types';
```

### Find all Tables from Database matching particular pattern in name ###
```mysql
SELECT table_name FROM information_schema.tables WHERE table_schema='[DatabaseName]' AND table_name LIKE '%[Pattern]%';
SELECT table_name FROM information_schema.tables WHERE table_schema='rpm_simpletire' AND table_name LIKE '%services%';
```

### List all Columns from specific Table and Database ###
```mysql
SELECT COLUMN_NAME,COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = '[DatabaseName]' AND TABLE_NAME LIKE '[TableName]';
SELECT COLUMN_NAME,COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'rpm_simpletire' AND TABLE_NAME LIKE 'services';
```

### Display all values of Column which aren't NULL from the Table ###
```mysql
SELECT [ColumnName] FROM [TableName] WHERE [ColumnName] IS NOT NULL LIMIT [Limit];
SELECT [ColumnName] FROM [TableName] WHERE [ColumnName] IS NOT NULL;
SELECT confirmdate FROM my_installers WHERE confirmdate IS NOT NULL LIMIT 10;
SELECT confirmdate FROM my_installers WHERE confirmdate IS NOT NULL;
```

### Display all Current Date relevant values from MySQL RDBMS ###
```mysql
SELECT CURDATE(), CURTIME(), NOW();
SELECT CURRENT_DATE(), CURRENT_TIME(), CURRENT_TIMESTAMP();
SELECT CURDATE(), CURTIME(), NOW(), CURRENT_DATE(), CURRENT_TIME(), CURRENT_TIMESTAMP();
```

### Add Column to the specific table with necessary settings ###
```mysql
DESC walmart_items;
DESCRIBE walmart_items;
SHOW COLUMNS FROM walmart_items;
SHOW FULL COLUMNS FROM walmart_items;
ALTER TABLE walmart_items DROP `item_number`;
ALTER TABLE walmart_items ADD COLUMN store_item_number BIGINT(20) NULL UNIQUE COMMENT "Walmart Item Number" AFTER walmart_id;
ALTER TABLE `walmart_items` ADD COLUMN `store_item_number` BIGINT(20) NULL UNIQUE COMMENT "Walmart Item Number" AFTER `walmart_id`;
```

### Find all columns matching a specific pattern in their names from database ###
```mysql
SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'rpm_simpletire' AND COLUMN_NAME LIKE '%position%';
```

### Construct the Query and execute it ###
```sql
SET @fieldsNeeded := (SELECT GROUP_CONCAT(COLUMN_NAME SEPARATOR "`,`") AS fieldsNeeded FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'my_distributors_warehouses_orders' AND COLUMN_NAME like '%ship%');
SET @finalFields = CONCAT("SELECT ", CONCAT("`",@fieldsNeeded,"`"), " FROM my_distributors_warehouses_orders WHERE my_order_id = 1167286");
PREPARE stmt FROM @finalFields;
EXECUTE stmt;
```
```mysql
SET @fieldsNeeded := (SELECT GROUP_CONCAT(COLUMN_NAME SEPARATOR "`,`") AS fieldsNeeded FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'my_distributors_warehouses_orders' AND COLUMN_NAME like '%ship%');
SET @finalFields = CONCAT("SELECT ", CONCAT("`",@fieldsNeeded,"`"), " FROM my_distributors_warehouses_orders WHERE my_order_id = 1167286");
PREPARE stmt FROM @finalFields;
EXECUTE stmt;
```
```mysql
SET @fieldsNeeded := (SELECT GROUP_CONCAT(COLUMN_NAME SEPARATOR "`,`") AS fieldsNeeded FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'my_distributors_warehouses_orders' AND COLUMN_NAME like '%deli%');
SET @finalFields = CONCAT("SELECT ", CONCAT("`",@fieldsNeeded,"`"), " FROM my_distributors_warehouses_orders WHERE my_order_id = 1167286");
PREPARE stmt FROM @finalFields;
EXECUTE stmt;
```
```sql
SET @fieldsNeeded := (SELECT GROUP_CONCAT(COLUMN_NAME SEPARATOR "`,`") AS fieldsNeeded FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'my_distributors_warehouses_orders' AND COLUMN_NAME like '%deli%');
SET @finalFields = CONCAT("SELECT ", CONCAT("`",@fieldsNeeded,"`"), " FROM my_distributors_warehouses_orders WHERE my_order_id = 1167286");
PREPARE stmt FROM @finalFields;
EXECUTE stmt;
```

### Execute Update Query for only selected number of rows and then find out which row was affected ###
```mysql
UPDATE my_distributors_warehouses SET can_display_sla_grades = 1 WHERE can_display_sla_grades = 0 LIMIT 1;
UPDATE my_distributors_warehouses SET can_display_sla_grades = 1 WHERE can_display_sla_grades = 0 AND LAST_INSERT_ID(id) LIMIT 1;
SELECT * FROM my_distributors_warehouses WHERE id = LAST_INSERT_ID();
```
```sql
UPDATE my_distributors_warehouses SET can_display_sla_grades = 1 WHERE can_display_sla_grades = 0 LIMIT 1;
UPDATE my_distributors_warehouses SET can_display_sla_grades = 1 WHERE can_display_sla_grades = 0 AND LAST_INSERT_ID(id) LIMIT 1;
SELECT * FROM my_distributors_warehouses WHERE id = LAST_INSERT_ID();
```
