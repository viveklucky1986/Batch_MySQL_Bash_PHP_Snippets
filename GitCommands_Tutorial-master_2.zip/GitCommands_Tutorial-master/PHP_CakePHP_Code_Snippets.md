## Get Current URL & Parameters passed in URL:
```php
<?php
function getCurrentUrl($getUrlParams = false) {
		$s = empty($_SERVER["HTTPS"]) ? '' : ($_SERVER["HTTPS"] == "on") ? "s" : "";
		$protocol = substr(strtolower($_SERVER["SERVER_PROTOCOL"]), 0, strpos(strtolower($_SERVER["SERVER_PROTOCOL"]), "/")) . $s;
		$port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":".$_SERVER["SERVER_PORT"]);
		$currentUrl = $protocol . "://" . $_SERVER['SERVER_NAME'] . $port . $_SERVER['REQUEST_URI'];
		if ($getUrlParams === true) {
				parse_str(parse_url($currentUrl, PHP_URL_QUERY), $params);
				return array($currentUrl, $params);
		}
		return $currentUrl;
}
?>
```

## Set Multiple Cache Configs in the CakePHP Site:
```php
<?php
# Add this code in your cakephp_site_root\app\Config\bootstrap.php file
Configure::write('Dispatcher.filters', array(
		'AssetDispatcher',
		'CacheDispatcher'
));

// Cache configuration for data that can be cached for a short time only. - 05-01-2018
Cache::config('shortStore', array(
		'engine' => 'File',
		'duration' => '+30 minutes',
		'path' => CACHE,
		'prefix' => 'cake_short_'
));

// Cache configuration for data that can be cached for a long time. - 05-01-2018
Cache::config('longStore', array(
		'engine' => 'File',
		'duration' => '+1 week',
		'probability' => 100,
		'path' => CACHE . 'long' . DS
));
?>
```

## Set Memcached as default Cache Engine in CakePHP Site:
```php
<?php
# Add this code in your cakephp_site_root\app\Config\bootstrap.php file
Configure::write('Dispatcher.filters', array(
		'AssetDispatcher',
		'CacheDispatcher',
		'NginxMemcachedFilter'
));

Cache::config('default', array(
		'engine' => 'Memcached',
		'duration'=> '+7 days',
		'probability'=> 100,
		'servers' => array('127.0.0.1:11211'),
		'prefix' => ''
));
?>
```
