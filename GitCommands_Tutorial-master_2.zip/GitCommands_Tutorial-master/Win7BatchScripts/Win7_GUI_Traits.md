### Multiple Searches from Windows 7 Search Bar ###
```
Ctrl + F
[SearchTerm1] OR [SearchTerm2] OR .....
Ctrl + F
vcred OR hardlink
```
