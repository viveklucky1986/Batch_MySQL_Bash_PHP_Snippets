### Start and stop Apache Service & Read any previous warnings generated ###
```cmd
httpd -k start
httpd -k stop
httpd -e warn
rem Below Service Names are as per services.msc list
net stop Apache2.4 && net start Apache2.4
net stop Apache2.4 & net start Apache2.4
```

### Apache Conf Settings for CGI Scripts in Windows ###
```conf
ScriptAlias /cgi-bin/ "C:\\wwwroot\\Apache2433\\cgi-bin\\"
<Directory "C:\\wwwroot\\Apache2433\\cgi-bin\\">
    AllowOverride None
    Options +ExecCGI
    Require all granted
    AddHandler cgi-script .cgi .py
    Order deny,allow
    Deny from all
    Allow from localhost
    Allow from 127.0.0.1
</Directory>
<IfModule dir_module>
    DirectoryIndex index.html index.cgi
</IfModule>

# OR #

ScriptAlias /cgi-bin/ "C:/wwwroot/Apache2433/cgi-bin/"
<Directory "C:/wwwroot/Apache2433/cgi-bin/">
    AllowOverride None
    Options +ExecCGI
    Require all granted
    AddHandler cgi-script .cgi .py
    Order deny,allow
    Deny from all
    Allow from localhost
    Allow from 127.0.0.1
</Directory>
<IfModule dir_module>
    DirectoryIndex index.html index.cgi
</IfModule>
```
```bash
ScriptAlias /cgi-bin/ "C:\\wwwroot\\Apache2433\\cgi-bin\\"
<Directory "C:\\wwwroot\\Apache2433\\cgi-bin\\">
    AllowOverride None
    Options +ExecCGI
    Require all granted
    AddHandler cgi-script .cgi .py
    Order deny,allow
    Deny from all
    Allow from localhost
    Allow from 127.0.0.1
</Directory>
<IfModule dir_module>
    DirectoryIndex index.html index.cgi
</IfModule>

# OR #

ScriptAlias /cgi-bin/ "C:/wwwroot/Apache2433/cgi-bin/"
<Directory "C:/wwwroot/Apache2433/cgi-bin/">
    AllowOverride None
    Options +ExecCGI
    Require all granted
    AddHandler cgi-script .cgi .py
    Order deny,allow
    Deny from all
    Allow from localhost
    Allow from 127.0.0.1
</Directory>
<IfModule dir_module>
    DirectoryIndex index.html index.cgi
</IfModule>
```
