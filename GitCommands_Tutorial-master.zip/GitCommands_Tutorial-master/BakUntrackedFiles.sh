#!/bin/bash
# BakUntrackedFiles.sh
# au = !git add $(git ls-files -o --exclude-standard)
git ls-files --others --exclude-standard
CurrDir=$(PWD)
UntrackdFls=$(git ls-files --others --exclude-standard)
for file in $UntrackdFls
do
	mkdir -pm 755 "$CurrDir/_baks_"
	mv "$file" "$CurrDir/_baks_"
done