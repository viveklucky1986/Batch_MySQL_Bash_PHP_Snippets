### Bash Git Windows Shebangs ###
```bash
#!C:\Progra~1\Git\usr\bin\bash.exe
#!C:/Progra~1/Git/usr/bin/bash.exe
```
