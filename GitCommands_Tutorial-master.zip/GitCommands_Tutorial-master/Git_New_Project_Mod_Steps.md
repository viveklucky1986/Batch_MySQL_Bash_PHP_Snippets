SimpleTire Repository
==========

Clear the old command history
-----------------------------
```bash
history -cw && reset && clear && history -cw
```

Workflow
--------

In general, when working on an item, you should be checking out a new branch to make changes:

1. Create a new branch by typing `git checkout -b name_of_new_branch`
1. Make changes in the branch and commit them
1. Switch to the development branch by typing `git checkout development`
1. Pull latest development changes from the server: `git pull development`
1. Merge your changes into development (use no-ff option): `git merge --no-ff name_of_new_branch`
1. _Important!_ Fix any merge issues
1. Push changes to the server: `git push development`
1. Remove your local changes branch: `git branch -d name_of_new_branch`


Git Add, Commit & Push commands
-------------------------------
```bash
history -cw && reset && clear && history -cw
git commit -am "[Commit Message]" && git push origin HEAD
git commit -am "SIM-3521:Realtime zipcode check" && git push origin HEAD
```
