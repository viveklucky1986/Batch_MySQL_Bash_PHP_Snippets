### Clone All User Repositories at once:
```bash
curl "https://api.github.com/users/vivek-simpletire/repos?page=1&per_page=100" |
	grep -e 'git_url*' |
	cut -d \" -f 4 |
	xargs -L1 git clone
```

### Clone All Repositories of particular Organization with required credentials:
```bash
#!/bin/bash
ORGANIZATION=simpletire
TOKEN=38116c18ffb616879a4ba8527f7711d96b44d75e
USERNAME=vivek-simpletire
PASSWORD='ge9Fraudcad$7389&*'

# for i in `curl -sS "https://api.github.com/orgs/$ORGANIZATION/repos?per_page=200&access_token=$TOKEN" |grep html_url|awk 'NR%2 == 0'|cut -d ':'  -f 2-3|tr -d '",'`; do
for i in `curl -sS "https://api.github.com/orgs/$ORGANIZATION/repos?per_page=200&access_token=$TOKEN" |grep clone_url|cut -d ':'  -f 2-3|tr -d '",'`; do
    # echo git clone $i;
    # git clone $i;
    git clone $i && cd  git pull --all
    # git clone $i.git;
done
# Username: vivek-simpletire
# Password: ge9Fraudcad$7389&*


git clone https://[Username]@github.com/[OrgName]/[RepoName].git
git clone git@github.com:[OrgName]/[RepoName].git

git clone https://vivek-simpletire:ge9Fraudcad\$7389\&\*@github.com/SimpleTire/backoffice-laravel.git
```

#### Or

```bash
#!/bin/bash
ORGANIZATION=simpletire
TOKEN=38116c18ffb616879a4ba8527f7711d96b44d75e
USERNAME=vivek-simpletire
PASSWORD='ge9Fraudcad$7389&*'

# for i in `curl -sS "https://api.github.com/orgs/$ORGANIZATION/repos?per_page=200&access_token=$TOKEN" |grep html_url|awk 'NR%2 == 0'|cut -d ':'  -f 2-3|tr -d '",'`; do
for i in `curl -sS "https://api.github.com/orgs/$ORGANIZATION/repos?per_page=200&access_token=$TOKEN" |grep clone_url|cut -d ':'  -f 2-3|tr -d '",'`; do

    echo git clone $i;
    # git clone $i;
    # git clone $i.git;
done

git clone https://[Username]@github.com/[OrgName]/[RepoName].git
git clone git@github.com:[OrgName]/[RepoName].git

git clone https://vivek-simpletire:ge9Fraudcad\$7389\&\*@github.com/SimpleTire/backoffice-laravel.git
```
