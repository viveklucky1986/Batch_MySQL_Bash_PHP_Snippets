#### Add HTML Tag around every subtitle line in .srt files ####
```regex
Find what: ^([^\d^\n].*)
Replace with: <font color="#FFFF00">\1</font>
```

#### Search and replace in only certain tags and attributes in xml file by Regex ####
```regex
Find what: (?=.*\.phtml)module\/
Replace with: mycompany/module/
```

#### VBScript to remove duplicate numbers from subtitle file by re-numbering ####
```vbs
f = "C:\path\to\your.srt"
n = 1  'global counter

Function Renumber(m, g1, g2, pos, src)
  Renumber = g1 & n & g2
  n = n + 1  'increment global counter after current value was used
End Function

Set re = New RegExp
re.Pattern = "(^|\r\n\r\n)\d+(\r\n)"
re.Global = True

Set fso = CreateObject("Scripting.FileSystemObject")
txt = fso.OpenTextFile(f).ReadAll
txt = re.Replace(txt, GetRef("Renumber"))
fso.OpenTextFile(f, 2).Write txt
```

#### Regex to match a line starting with digit only if the same line contains alphabets later ####
```regex
Find what: ^\d+:\d+:[^-]+-->.*\R+\K.+(?:\R.+)*(?=\s*(?:^\d+$|\z))
```

#### Regex find function by name whose declaration can be in any format ####
```regex
Find what: (?:doFilter\s*[:=]\s*function|function\s*doFilter)\([^)]*\)\s*{((?:[^{}]+|{[^}]+})*)}
```

#### Regex to match any Javascript/jQuery function declaration line ####
```regex
Find what: function.*{|\w* \= function.*{|jquery.*{
```

#### Replace only the first occurrence of a word with regex in text-editor ####
```regex
Find what: ^((?:(?!\bdefault\b).)*)default
Find what: ^(.*?)\bdefault\b
Replace with: \1rwd
```

#### Regex to match PHP Function definition ####
```regex
Find what: function\s+(.*?)\)\s*{
Replace with: function \1\) {\nvar_dump\(debug_backtrace\(\)\);
```

#### Remove xml comments that doesn't contain asterisk character ####
```regex
Find what: (?s)<!--[^*]*?-->
Replace with: [Nothing]
```

#### Add Thousand separator to any number even if it contains special characters ####
```php
$str = preg_replace('/\..*$(*SKIP)(*F)|(?<=\d)(?=(?:\d{3})+(?!\d))/', ' ', $str);
# \..*$(*SKIP)(*F) will ignore/skip part after DOT for this conversion.

# Or

// expects "1.234,00" returns "1 234,-"
//     "1.234.567,00" ==> "1 234 567,-"
//              5,50  ==>          5,50
function kroneDisplayFormat($formalFormat) {
    $intermediate = str_replace(".", " "); // replace . separator with ' ' (space)
    if( endsWith( $intermediate, ",00")) {
       // special display case ",00" ==> ",-"
       $final = str_replace(",00", ",-");
    } else {
       $final = $intermediate
    }
    return $final
}
```
