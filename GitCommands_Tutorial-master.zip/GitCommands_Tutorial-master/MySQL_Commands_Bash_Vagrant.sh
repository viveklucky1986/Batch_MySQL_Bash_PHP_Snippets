debug=
for filename in *.bz2; do
	if [ "${filename}" != "my_orders.sql.bz2" ] || [ "${filename}" != "my_distributors_warehouses_products.sql.bz2" ];then
		# bunzip2 < "${filename}" | mysql -u root simpletireproddb;
		debug bunzip2 < "${filename}" | mysql -u db_user rpm_simpletire
	fi
done
# bunzip2 < my_order_products.sql.bz2 | mysql -u db_user rpm_simpletire
# bunzip2 < my_distributors_warehouses_orders.sql.bz2 | mysql -u db_user rpm_simpletire
# bunzip2 < analytic_orders.sql.bz2 | mysql -u db_user rpm_simpletire

# MySQL Views Creation Code should always be executed only once, then they should be removed as MySQL stores and updates Views on daily basis.
# MySQL Stored Procedures should be avoided whenever possible.
