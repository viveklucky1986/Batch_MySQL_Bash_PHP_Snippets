Steps for new branch work start in Git:
1. `git checkout master && git pull origin && git pull`
2. `git checkout -b [dev_branch_name]`
3. Now keep on doing your necessary changes and do the usual status check and add,commit & push.
