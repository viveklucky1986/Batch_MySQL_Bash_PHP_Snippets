#!C:\Python27\python.exe

import sublime, sublime_plugin, random, re, os
class CopyFilePathUnixCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		filePath = self.view.file_name()
		fileName = os.path.basename(self.view.file_name())
		relativeFilePath = re.sub(r'.*simple', '', filePath)
		unixRelativeFilePath = relativeFilePath.replace('\\', '/').strip('/')
		sublime.set_clipboard(unixRelativeFilePath)