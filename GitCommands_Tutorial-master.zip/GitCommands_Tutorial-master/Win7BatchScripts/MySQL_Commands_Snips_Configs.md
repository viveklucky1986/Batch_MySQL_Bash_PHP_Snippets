### Install, Start or Stop MySQL Service
```cmd
cd [MySQL Executable Path]
cd "C:\Program Files (x86)\MySQL\MySQL Server 5.6\bin"
mysqld --install
net start mysql
net stop mysql
```

### MySQL Config which worked in my Win7 64Bit OS ###
```ini
;; Change the [PasswordText] to your desired password ;;

[client]
user = root
password = "[PasswordText]"
port = 3306
socket = /tmp/mysql.sock

[mysql]
user = root
password = "[PasswordText]"

[mysqldump]
user = root
password = "[PasswordText]"

[mysqldiff]
user = root
password = "[PasswordText]"

[mysqld]
port = 3306
basedir = "C:/Program Files (x86)/MySQL/MySQL Server 5.6/"
datadir = "C:/Program Files (x86)/MySQL/MySQL Server 5.6/data/"
server-id = 1
bind-address = 127.0.0.1
sql-mode = "STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"
explicit_defaults_for_timestamp = TRUE
character-set-server = utf8
default-storage-engine = INNODB
max_connections = 1000
query_cache_type = 1
query_cache_size = 256M
thread_concurrency = 8
query_cache_limit = 768M
table_open_cache = 1024
tmp_table_size = 128M
thread_cache_size = 256
myisam_max_sort_file_size = 2G
; myisam_max_sort_file_size = 128M
; myisam_sort_buffer_size = 256M
myisam_sort_buffer_size = 2G
; key_buffer_size = 512M
key_buffer_size = 1G
read_buffer_size = 64K
read_rnd_buffer_size = 256K
sort_buffer_size = 2M
innodb_additional_mem_pool_size = 16M
innodb_flush_log_at_trx_commit = 1
innodb_log_buffer_size = 6M
innodb_buffer_pool_size = 784M
innodb_log_file_size = 128M
innodb_thread_concurrency = 12
innodb_file_per_table = FALSE
innodb_data_home_dir = "C:/Program Files (x86)/MySQL/MySQL Server 5.6/data/"
; innodb_log_group_home_dir = "C:/wwwroot/mysql_config_logs/"
innodb_log_group_home_dir = "C:/Program Files (x86)/MySQL/MySQL Server 5.6/data/"
```
```cnf
;; Change the [PasswordText] to your desired password ;;

[client]
user = root
password = "[PasswordText]"
port = 3306
socket = /tmp/mysql.sock

[mysql]
user = root
password = "[PasswordText]"

[mysqldump]
user = root
password = "[PasswordText]"

[mysqldiff]
user = root
password = "[PasswordText]"

[mysqld]
port = 3306
basedir = "C:/Program Files (x86)/MySQL/MySQL Server 5.6/"
datadir = "C:/Program Files (x86)/MySQL/MySQL Server 5.6/data/"
server-id = 1
bind-address = 127.0.0.1
sql-mode = "STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"
explicit_defaults_for_timestamp = TRUE
character-set-server = utf8
default-storage-engine = INNODB
max_connections = 1000
query_cache_type = 1
query_cache_size = 256M
thread_concurrency = 8
query_cache_limit = 768M
table_open_cache = 1024
tmp_table_size = 128M
thread_cache_size = 256
myisam_max_sort_file_size = 2G
; myisam_max_sort_file_size = 128M
; myisam_sort_buffer_size = 256M
myisam_sort_buffer_size = 2G
; key_buffer_size = 512M
key_buffer_size = 1G
read_buffer_size = 64K
read_rnd_buffer_size = 256K
sort_buffer_size = 2M
innodb_additional_mem_pool_size = 16M
innodb_flush_log_at_trx_commit = 1
innodb_log_buffer_size = 6M
innodb_buffer_pool_size = 784M
innodb_log_file_size = 128M
innodb_thread_concurrency = 12
innodb_file_per_table = FALSE
innodb_data_home_dir = "C:/Program Files (x86)/MySQL/MySQL Server 5.6/data/"
; innodb_log_group_home_dir = "C:/wwwroot/mysql_config_logs/"
innodb_log_group_home_dir = "C:/Program Files (x86)/MySQL/MySQL Server 5.6/data/"
```
