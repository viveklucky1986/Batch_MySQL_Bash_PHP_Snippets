### Find and Kill the process listening to specific ports ###
```cmd
netstat -ano | findstr [PortNumber]
netstat -ano | findstr 8080
:: Get the ProcessId and apply in below command
taskkill /pid [ProcessId]
taskkill /pid 3060
```

### Get the list of all ports used in Windows System(64Bit WIN7) ###
```cmd
netstat -an
```

### Replace Windows Path string with Linux Path string & copy it to clipboard ###
```cmd
@echo off
setlocal enabledelayedexpansion
set myvar="C:\wwwroot\WinBatchScripts"
call :ReplaceSpecialChar1 myvar "\" "/"
echo Result of ReplaceSpecialChar1: [%myvar%]
rem set myvar="C:\wwwroot\WinBatchScripts"
call :ReplaceSpecialChar2 myvar "C" "/c"
echo Result of ReplaceSpecialChar2: [%myvar%]
set myvar=%myvar:"=%
rem echo %myvar% | clip
rem echo | set /p=%myvar% | clip
set /p="%myvar%" < nul | clip
goto :eof

REM More custom code ...

REM Only subroutines from here ...
goto :eof
REM Will only replace the first occurrence of the character to be replaced:
:ReplaceSpecialChar1
for /f "tokens=1* delims=%~2" %%a in ("!%1!") do (
  if "%%b"=="" (set %1=%%a) else (set %1=%%a%~3%%b)
)
rem goto :eof

REM Will replace all occurrences of the character to be replaced:
:ReplaceSpecialChar2
set work=!%1!
set /a i = 0
:ReplaceLoop
if "!work:~%i%,1!"=="" (set %1=!work!&goto :eof)
if not "!work:~%i%,1!"=="%~2" (set /a i += 1&goto ReplaceLoop)
set head=!work:~0,%i%!
set /a i += 1
set work=!head!%~3!work:~%i%!
goto :ReplaceLoop
```

### Shutdown System after specific amount of time (seconds) ###
```cmd
@echo off
:PrintMsg
shutdown /s /f /t 2700
set /p ProcessGoOn="Your computer is about to shutdown in 45 mins do you want to abort (y/n): "
if %ProcessGoOn% equ y (
    shutdown /a
    timeout /t 2700 /nobreak
    goto PrintMsg
)
exit /b
```
```bat
@echo off
:PrintMsg
shutdown /s /f /t 2700
set /p ProcessGoOn="Your computer is about to shutdown in 45 mins do you want to abort (y/n): "
if %ProcessGoOn% equ y (
    shutdown /a
    timeout /t 2700 /nobreak
    goto PrintMsg
)
exit /b
```

### Make HTTPS Url from HTTP Url ###
```cmd
@echo off
setlocal EnableDelayedExpansion
set /p Url="Enter Url to Convert: "
set HttpsUrl=%Url:http=https%
echo %HttpsUrl%
start firefox %HttpsUrl%
exit /b
```
```bat
@echo off
setlocal EnableDelayedExpansion
set /p Url="Enter Url to Convert: "
set HttpsUrl=%Url:http=https%
echo %HttpsUrl%
start firefox %HttpsUrl%
exit /b
```
