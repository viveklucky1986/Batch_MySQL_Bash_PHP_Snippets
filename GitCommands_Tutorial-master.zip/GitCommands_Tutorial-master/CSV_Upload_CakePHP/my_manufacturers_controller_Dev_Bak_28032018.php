<?php
# C:\Users\WMIND2004\Projects\simple\backend\admin\controllers\my_manufacturers_controller_Dev_Bak_28032018.php
# C:\Users\WMIND2004\Projects\simple\backend\admin\controllers\my_manufacturers_controller.php

class MyManufacturersController extends AppController {

    var $name = 'MyManufacturers';
    var $paginate = array('limit'=>50, 'page'=>1);
    var $nav = 'my_products';
    var $helpers = array('Html', 'Form', 'Csv');
    
    function index() {
    
        $conditions = array('MyManufacturer.deleted IS NULL');
    
        $data = $this->params['named'];
        if (!empty($data)) {
            if (isset($data['Type'])) {
                $conditions[] = array('MyManufacturer.product_type_id'=>$data['Type']);  
                $this->data['MyManufacturer']['product_type_id'] = $data['Type'];
            }
            if (isset($data['Manufacturer'])) {
                $data['Manufacturer'] = str_replace('||','/',str_replace('^','+',$data['Manufacturer']));
                $conditions[] = "(LOWER(MyManufacturer.name) LIKE '%{$data['Manufacturer']}%')";  
                $this->data['MyManufacturer']['name'] = urldecode($data['Manufacturer']);
            }
        }

        $this->MyManufacturer->recursive = -1;
        $this->set('manufacturers', $manufacturers = $this->paginate('MyManufacturer', $conditions));
        
        $this->MyManufacturer->unBindAll();
        $this->set('manufacturer_count', $this->MyManufacturer->find('count', array('conditions'=>array('MyManufacturer.id'))));
        $this->set('types', $this->MyManufacturer->MyProductType->find('list'));
    }   
    
    function delete($id=null,$force=false) {
        if ($id){
            $products = $this->MyManufacturer->MyProduct->find('count',array('conditions'=>array('MyProduct.manufacturer_id'=>$id)));
            if ($products > 0) {
                if($force){
                    $this->MyManufacturer->query("UPDATE my_products SET deleted=NOW(), deleted_by='".user('id')."' WHERE my_products.manufacturer_id='$id'");                  
                    $this->MyManufacturer->query("UPDATE my_manufacturers_products_lines SET deleted=NOW(), deleted_by='".user('id')."' WHERE my_manufacturers_products_lines.manufacturer_id='$id'");
                    $this->MyManufacturer->del($id);        

                    $this->Session->setFlash('Manufacturer, ManufacturersProductsLine, and Product has been deleted');
                    $this->redirect('/MyManufacturers/index/');                 
                }           
            
                $this->Session->setFlash('Unable to delete manufacturer, there are still products associated');
                $this->redirect('/MyManufacturers/index/');
            } else {
                $this->MyManufacturer->del($id);
                $this->Session->setFlash('MyManufacturer has been deleted');
                $this->redirect('/MyManufacturers/index/');
            }
        }
    }
    
    function edit($product_type_id=null, $id=null) {

        $create_type = "";
        if(!empty($_POST['create_type']) && $_POST['create_type']=="ajax"){
            Configure::write('debug', 0);
            $this->autoRender = false;
            $create_type = $_POST['create_type'];
            $data = array();
            parse_str($_POST['data'],$data);
            $this->data = $data['data'];
        }

        $this->MyManufacturer->unBindAll(array('hasMany'=>array('MyImage'), 'belongsTo'=>array('CreatedBy', 'ModifiedBy')));
        
        $MyProductType = getModel('MyProductType');
                $this->set('productTypeList',$MyProductType->find('list',array('fields'=>array('id','name'),'recursive'=>0)));

        if (!empty($this->data)) {
            if (!$id) {
                $manufacturer = $this->MyManufacturer->find('count', array('conditions'=>array('MyManufacturer.name'=>$this->data['MyManufacturer']['name'], 'MyManufacturer.deleted IS NULL')));
            }else{
                $manufacturer = $this->MyManufacturer->find('count', array('conditions'=>array('MyManufacturer.name'=>$this->data['MyManufacturer']['name'], 'MyManufacturer.deleted IS NULL', 'MyManufacturer.id !='.$id)));
            }
            
            if($manufacturer > 0 ) {
                if($create_type=="ajax"){
                    echo "exists";
                } else {
                    $this->Session->setFlash('A manufacturer with this name already exists');
                    $this->redirect('/MyManufacturers/edit/' . $product_type_id . '/' . $id);
                }
            }else{
                if ($id) {
                    $this->MyManufacturer->id = $id;
                    $this->MyManufacturer->save($this->data);
                }else{
                    
                    $this->MyManufacturer->create($this->data);
                    $this->MyManufacturer->save($this->data);
                    $id = $this->MyManufacturer->getID();
                }
                if ($id) {
                    if($create_type=="ajax"){
                        echo "success";
                    } else {
                        $this->Session->setFlash('Manufacturer saved successfully');
                        $this->redirect('/MyManufacturers/index/');
                    }
                }
            }   
        }
        
        if ($id) {
            $this->MyManufacturer->recursive = 2;
            $this->MyManufacturer->id = $id;
            $this->data = $this->MyManufacturer->read();
            $this->set('manufacturer_name', $this->data['MyManufacturer']['name']);
            $this->set('editing', true);
                        // for image uploader:
                        $this->set('images',$this->data['MyImage']);
                        $this->set('axUploaderOptions',"
                          'success': function(msg) { afterImageSave(msg);},
                          'maxFiles':1
                        ");
        }else{
            $this->set('editing', false);
        }
        $this->set('product_type_id', $product_type_id);
        $this->data['MyManufacturer']['name'] = @$_GET['m'];
    }
    
    function get_manufacturers() {
        Configure::write('debug', 0);
        $this->autoRender = false;
        $this->viewPath = 'elements'.DS.'manufacturer';
        $this->render('manufacturers', 'ajax');
    }
    
    function save_manufacturer($id=null) {
        Configure::write('debug', 0);
        $this->autoRender = false;

        if (!empty($this->data)) {
            if ($id) {
                $this->MyManufacturer->id = $id;
            }else{
                $this->MyManufacturer->create();
            }
            $this->MyManufacturer->save(array('name'=>$this->data['MyManufacturer']['name'], 'website'=>$this->data['MyManufacturer']['website']));
            $id = $this->MyManufacturer->getLastInsertId();
            echo $id;
        }
    }
    
    function manufacturers_list() {
        Configure::write('debug', 0);
        $this->autoRender = false;
        
        $types = $this->MyManufacturer->find('list', array('order' => 'MyManufacturer.name', 'conditions'=>array('MyManufacturer.deleted IS NULL')));
        $ret = array();
        $ret[] = array('optionValue'=>'0', 'optionDisplay'=>'');
        foreach ($types AS $k => $v) {
            $ret[] = array('optionValue'=>$k, 'optionDisplay'=>$v);
        }
        echo json_encode($ret);
    }
    
    function product_lines_list($manufacturer_id=null) {
        Configure::write('debug', 0);
        $this->autoRender = false;
        
        $types = $this->MyManufacturersProductsLine->find('list', array('order' => 'MyManufacturersProductsLine.name', 'conditions'=>array('MyManufacturersProductsLine.manufacturer_id'=>$manufacturer_id)));
        $ret = array();
        $ret[] = array('optionValue'=>'0', 'optionDisplay'=>'');
        foreach ($types AS $k => $v) {
            $ret[] = array('optionValue'=>$k, 'optionDisplay'=>$v);
        }
        echo json_encode($ret);
    }

    /**
     * CSV Download Action
     */
    public function download() {
        Configure::write('debug', 0);
        $this->autoRender = true;
        $this->MyManufacturer->unBindAll();
        $manufacturers = $this->MyManufacturer->find('all',
                            array(
                                'fields' => array('MyManufacturer.id', 'MyManufacturer.name', 'MyManufacturer.brand_tier_rating'),
                                'order' => 'MyManufacturer.id ASC'
                            )
                        );
        $this->set('manufacturerBrandRatings', $manufacturers);
    }

    /**
     * CSV Upload Action
     */
    public function brand_rating_upload() {
        ini_set('auto_detect_line_endings', true);
        Configure::write('debug', 2);
        $this->autoRender = false;
        $this->MyManufacturer->unBindAll();
        $this->data = array($_POST, $_FILES);
        $csvNewData = array();

        if (isset($_POST['Upload'])) {
            if (!empty($_FILES['csvUpload'])) {
                $filenameSanitized = preg_replace('/\s+/', '_', $_FILES['csvUpload']['name']);
                $filename = explode('.', $filenameSanitized);
                if (end($filename) == 'csv') {
                    $fileHandle = fopen($_FILES['csvUpload']['tmp_name'], "r");

                    $csvRowsKeys = fgetcsv($fileHandle);
                    while (($line = fgetcsv($fileHandle, 0, ',')) !== false) {
                        if (array(null) !== $line) {
                            $line = self::sanitizeCsvRow($line);
                            $csvNewData[] = array_combine($csvRowsKeys, $line);
                        }
                    }
                    fclose($fileHandle);

                    try {
                        foreach ($csvNewData as $csvNewRow) {
                            $brandTierRating = $csvNewRow['brand_tier_rating'];
                            $manufacturerId = $csvNewRow['id'];
                            $manufacturerName = $csvNewRow['name'];
                            // Only numbers 1 to 4 are allowed as Tier Ratings
                            if (!in_array($csvNewRow['brand_tier_rating'], array(1, 2, 3, 4))) {
                                $brandTierRating = 4;
                            }
                            $this->MyManufacturer->updateAll(
                                array('MyManufacturer.brand_tier_rating' => $brandTierRating),
                                array('MyManufacturer.id' => $manufacturerId, 'MyManufacturer.deleted' => null, 'MyManufacturer.name' => $manufacturerName)
                            );
                        }
                        $this->Session->setFlash('Brand Tier Ratings imported successfully');
                        $this->redirect('/MyManufacturers/index');
                    } catch(Exception $e) {
                        $this->Session->setFlash('There was an error importing the Tier Ratings.');
                        $this->redirect('/MyManufacturers/index');
                    }
                }
            }
        }
        ini_set('auto_detect_line_endings', false);
    }

    /**
     * Clean up the CSV Row by purging any undesired characters
     *
     * @param array $row CSV Row Array
     *
     * @return array
     */
    private static function sanitizeCsvRow($row) {
        $dbConn = self::getDbConnectionLink();
        $row = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $row);
        $row = preg_replace('#[^\w()/.%\-&]#'," ", $row);
        $row = array_map(array($dbConn, 'real_escape_string'), $row);
        self::closeDbConnectionLink($dbConn);
        return $row;
    }

    /**
     * Connect to Mysql server only for using it's function
     *
     * @return mysqli
     */
    private static function getDbConnectionLink() {
        if((strstr($_SERVER['HTTP_HOST'], '.local') && empty($_SERVER['USE_PRODUCTION_DB']))
        || (php_sapi_name() == 'cli' && (gethostname() == 'simplevagrant' && empty($_SERVER['USE_PRODUCTION_DB'])))) {
            $dbLink = mysqli_connect('localhost', 'dbuser', 'tires123', 'rpm_simpletire') or die("Error connecting to MySQL: " . mysqli_connect_error());
        } else if(strstr($_SERVER['HTTP_HOST'], 'jenkins.simpletire.com')) {
            $dbLink = mysqli_connect('staging.cluster-c0zzuvbvffka.us-west-2.rds.amazonaws.com', 'root', 't1r3s123', 'rpm_simpletire') or die("Error connecting to MySQL: " . mysqli_connect_error());
        } else {
            $dbLink = mysqli_connect('simpletire-cluster.cluster-c0zzuvbvffka.us-west-2.rds.amazonaws.com', 'root', 't1r3s123', 'rpm_simpletire') or die("Error connecting to MySQL: " . mysqli_connect_error());
        }
        return $dbLink;
    }

    /**
     * Close the open MySQLi Connection to free up memory used
     *
     * @param mysqli $connObj Open MySQLi Link Object
     *
     * @return bool
     */
    private static function closeDbConnectionLink($connObj) {
        if (isset($connObj) && is_object($connObj) && ($connObj instanceOf mysqli)) {
            mysqli_close($connObj);
            unset($connObj);
            return true;
        }
        return false;
    }
}