<?php
# backend\admin\vendors\shells\order_automation.php
Configure::write('debug', 0);
set_time_limit(0);

class OrderAutomationShell extends Shell {

	var $uses = array('MyOrder','MyProduct','MyDistributorsWarehousesProduct','Zip','MyDistributorsWarehousesOrder', 'MyOrderHistoryLog', 'MyDistributor','MyDistributorsWarehouse','PotentialFraudData');

	var $debug = false;
	var $force_run = false;
	var $limit_warehouses = false;

	function test(){
		if(empty($this->params['oid'])) die('Param for oid required.');
		$this->debug = !empty($this->params['debug_off']) ? false : true;
		$this->force_run = true;
		$this->force_order_conditions = "`MyOrder`.`id` IN (".$this->params['oid'].")";
		$this->limit_warehouses = !empty($this->params['limit_off']) ? 9999 : 3;
		$this->process();
	}

	function testEmailWarehouseOrder() {
		if(empty($this->params['oid'])) die('Param for oid required.');

		// get various libraries, hacks galore
		App::import('Core', 'Controller');
		App::import('Component', 'Email');
		App::import('Component', 'MyDistributor');
		App::import('Component', 'Fedex');
		App::import('Component', 'Ups');
		App::import('Component', 'Email');
		App::import('Component', 'LogTypeEnum');
		App::import('Core', 'HttpSocket');
		$Zip = getModel('Zip');
		$MyDistributorsWarehousesInstaller = getModel('MyDistributorsWarehousesInstaller');
		$MyDistributorsWarehousesOrdersShippingLabel = getModel('MyDistributorsWarehousesOrdersShippingLabel');
		$this->Controller = new Controller();
		$this->MyDistributor = new MyDistributorComponent();
		$this->MyDistributor->setFedex(new FedexComponent());
		$this->MyDistributor->setUps(new UpsComponent());
		$this->Email = new EmailComponent();
		$this->Email->startup($this->Controller);
		$this->MyDistributor->setEmail($this->Email);
		Configure::write('Session.cookie', 'simpletire-cli');

		if(empty($this->params['debug_off'])) {
			echo "DEBUG MODE";
			$this->MyDistributor->_setEmailDebug();
		}
		echo "\nSending email for ".$this->params['oid'];
		$this->MyDistributor->_sendWarehouseEmail($this->params['oid']);
	}




	// resend all unprocessed orders with no labels generated for automation.
	function sendNoLabelsToReprocess() {
		$sql = "SELECT
				  MO.id as order_id
				FROM my_distributors_warehouses_orders MDWO
				  INNER JOIN my_orders MO ON (MO.id = MDWO.my_order_id)
				  LEFT JOIN my_distributors_warehouses_orders_shipping_labels L ON (L.my_distributors_warehouses_order_id = MDWO.id)
				WHERE MDWO.automated_status = 3 AND MO.status = 'New'
				GROUP BY MDWO.id
				HAVING count(L.id) = 0";
		$orders = $this->MyOrder->query($sql, false);
		foreach($orders as $key => $order) {
			$order_id = $order['MO']['order_id'];
			$this->MyOrder->query("UPDATE my_orders SET automated_at = NULL, automated_started = NULL WHERE id = $order_id");
		}
	}

	function fixStalled() {
		echo "Starting fixStalled @ ".date("Y-m-d H:i:s").str_repeat("-", 60);

		$sql = "SELECT
				    id AS my_order_id
				FROM
				    my_orders
				WHERE
				    automated_at IS NULL
				        AND (automated_started < DATE_SUB(NOW(), INTERVAL 15 MINUTE)
				        OR status = 'Void')
				UNION ALL
				SELECT
				    my_distributors_warehouses_orders.my_order_id AS my_order_id
				FROM
				    my_distributors_warehouses_orders
				WHERE
				    my_order_id IN (SELECT
				            id
				        FROM
				            my_orders
				        WHERE
				            automated_at IS NOT NULL)
				        AND automated_at IS NULL
				        AND warehouse_id > 0";
		$orders = $this->MyOrder->query($sql, false);
		echo "\nFound ".count($orders)." orders to process!\n";
		foreach($orders as $o){
			echo "\n + Processing ".$o[0]['my_order_id'];

			$sql = "UPDATE my_distributors_warehouses_orders SET automated_at=NOW(),automated_status='99' WHERE my_order_id = '".$o[0]['my_order_id']."'";
			if($this->debug) {
				echo "\nSQL=$sql";
			}else{
				$this->MyOrder->query($sql);
			}

			$sql = "UPDATE my_orders SET automated_at=NOW() WHERE id = '".$o[0]['my_order_id']."'";
			if($this->debug) {
				echo "\nSQL=$sql";
			}else{
				$this->MyOrder->query($sql);
			}
		}
	}

	function process(){
		$bgmc = new GearmanClient();
		$bgmc->addServer('127.0.0.1', '4730');

		echo "Starting process @ ".date("Y-m-d H:i:s").str_repeat("-", 60);

		$order_conditions = isset($this->force_order_conditions) ? $this->force_order_conditions : "`MyOrder`.`status` IN ('New','ReProcess') AND `MyOrder`.`automated_at` IS NULL AND `MyOrder`.`automated_started` IS NULL";

		$sql = 'SELECT
					`MyOrder`.`id`,
					`MyOrder`.`wholesale_id`,
					`MyOrder`.`source`,
					`MyOrder`.`status`,
					`MyOrder`.`sub_total`,
					`MyOrder`.`tax_total`,
					`MyOrder`.`fet_total`,
					`MyOrder`.`shipping_total`,
					`MyOrder`.`total`,
					`MyOrder`.`my_installer_id`,
					`MyOrder`.`walmart_order_id`,
					`MyOrder`.`card_type`,
					`MyOrder`.`card_fname`,
					`MyOrder`.`card_lname`,
					`MyOrder`.`card_number`,
					`MyOrder`.`card_exp_month`,
					`MyOrder`.`card_exp_year`,
					`MyOrder`.`billing_address1`,
					`MyOrder`.`billing_address2`,
					`MyOrder`.`billing_city`,
					`MyOrder`.`billing_state`,
					`MyOrder`.`billing_zip`,
					`MyOrder`.`billing_phone`,
					`MyOrder`.`shipping_method`,
					`MyOrder`.`shipping_fname`,
					`MyOrder`.`shipping_lname`,
					`MyOrder`.`shipping_company`,
					`MyOrder`.`shipping_address1`,
					`MyOrder`.`shipping_address2`,
					`MyOrder`.`shipping_city`,
					`MyOrder`.`shipping_state`,
					`MyOrder`.`shipping_zip`,
					`MyOrder`.`shipping_phone`,
					`MyOrder`.`my_customer_id`,
					`MyOrder`.`shipping_residential`,
					`MyCustomer`.`fname`,
					`MyCustomer`.`lname`,
					`MyCustomer`.`company`,
					`MyCustomer`.`email`,
					`MyCustomer`.`phone`,
					`MyOrder`.`status`,
					`MyOrder`.`created`,
					`MyOrder`.`processed`,
					`MyOrder`.`coupon_total`,
					`MyOrder`.`fet_total`,
					`MyOrder`.`shipping_option`,
					`MyOrder`.`freight_order`,
					`MyOrder`.`mp_order_id`,
					`MyOrder`.`mp_history_id`,
					`MyOrder`.`mp_auth_code`,
					`MyOrder`.`mp_approval_number`,
					`MyOrder`.`payment_type`,
					`MyOrder`.`paypal_trans_id`,
					`MyOrder`.`affirm_user_id`,
					`MyOrder`.`affirm_transaction_id`
				FROM
					`my_orders` AS `MyOrder`
						LEFT JOIN
					`my_customers` AS `MyCustomer` ON `MyCustomer`.`id` = `MyOrder`.`my_customer_id`
				WHERE
					'.$order_conditions.'
				ORDER BY `MyOrder`.`id` ASC';

		$orders = $this->MyOrder->query($sql, false);
		echo "\nFound ".count($orders)." orders to process!\n";
		foreach($orders as $o){ $x++;
			$cust_name = trim($o['MyOrder']['shipping_fname'] ." ". $o['MyOrder']['shipping_lname']);
			if(empty($cust_name)) $cust_name = $o['MyOrder']['shipping_company'];
			echo "\n + ".$o['MyOrder']['id']." | ". $cust_name ." (".$o['MyOrder']['status']."/".$o['MyOrder']['source'].") for $". $o['MyOrder']['total'] ." @ ".$o['MyOrder']['created'];

			// track initial status
			$sql = "UPDATE my_orders SET automated_started=NOW() WHERE id = '".$o['MyOrder']['id']."'";
			if($this->debug) {
				echo "\nSQL=$sql";
			}else{
				$this->MyOrder->query($sql);
			}

			$job = $o;
			$job['debug'] = $this->debug;
			$job['force_run'] = $this->force_run;
			$job['limit_warehouses'] = $this->limit_warehouses;
			$job_handle = $bgmc->doBackground("automation", json_encode($job));

			if($bgmc->returnCode() != GEARMAN_SUCCESS) {
				echo "\nError adding job! ". $bgmc->returnCode();

				$sql = "UPDATE my_distributors_warehouses_orders SET automated_at=NOW() WHERE my_order_id = '".$o['MyOrder']['id']."'";
				if($this->debug) {
					echo "\nSQL=$sql";
				}else{
					$this->MyOrder->query($sql);
				}

				$sql = "UPDATE my_orders SET automated_at=NOW() WHERE id = '".$o['MyOrder']['id']."'";
				if($this->debug) {
					echo "\nSQL=$sql";
				}else{
					$this->MyOrder->query($sql);
				}
			}
		}
	}

	function _isNoShipping($wholesale_id)
	{
		if(!empty($wholesale_id)) {
			$calculate_shipping = $this->MyOrder->query("SELECT calculate_shipping FROM wholesales WHERE id = $wholesale_id");

			if(isset($calculate_shipping[0]['wholesales']['calculate_shipping'])) {
				return empty($calculate_shipping[0]['wholesales']['calculate_shipping']);
			}
		}
		return false;
	}

	function worker() {
		// primary worker, define method for a given job name
		$gmworker = new GearmanWorker();
		$gmworker->addOptions(GEARMAN_WORKER_GRAB_UNIQ);
		$gmworker->addServer('127.0.0.1', '4730');
		$gmworker->addFunction("automation", array(
			$this,
			'automation'
		));
		$gmworker->setTimeout(3000);

		echo "Waiting for jobs...\n\033[0m";

		while (@$gmworker->work() || $gmworker->returnCode() == GEARMAN_TIMEOUT) {
			if ($gmworker->returnCode() == GEARMAN_TIMEOUT) {
				# Normally one would want to do something useful here ...
				echo "\nTimeout. Waiting for next job...\n";
				continue;
			}

			if ($gmworker->returnCode() != GEARMAN_SUCCESS) {
				echo "\nError. Return code: " . $gmworker->returnCode() . "\n";
				break;
			}
		}
	}

	/**
	 * @param $workload - workload from order automation
	 * @return bool
	 */
	function isFraudOrder($workload) {
		$data = json_decode(json_encode($workload), true);
		$response = $this->PotentialFraudData->check_fraud_data($data);
		return !empty($response);
	}

	function automation($job) {
		$gmc = new GearmanClient();
		$gmc->addServer('127.0.0.1', '4730');

		$workload = json_decode($job->workload());
		echo "\nSTART " . $job->unique() . " | ORDER ID " . $workload->MyOrder->id . " @ " . date("Y-m-d H:i:s");

		// track when automation started
		$automation_started = date("Y-m-d H:i:s");

		//get order automation level & set sources accordingly
		$order_automation_level = $this->_getOrderAutomationLevel();

		// make sure we stay connected
		$this->_checkDBConn('MyOrder');

		// get various libraries, hacks galore
		App::import('Core', 'Controller');
		App::import('Component', 'Email');
		App::import('Component', 'MyDistributor');
		App::import('Component', 'Fedex');
		App::import('Component', 'FreightQuote');
		App::import('Component', 'Ups');
		App::import('Component', 'Email');
		App::import('Component', 'LogTypeEnum');
		App::import('Core', 'HttpSocket');
		$Zip = getModel('Zip');
		$MyDistributorsWarehousesInstaller = getModel('MyDistributorsWarehousesInstaller');
		$MyDistributorsWarehousesOrdersShippingLabel = getModel('MyDistributorsWarehousesOrdersShippingLabel');
		$this->Controller = new Controller();
		$this->MyDistributor = new MyDistributorComponent();
		$this->Email = new EmailComponent();
		$this->Email->startup($this->Controller);
		$this->MyDistributor->setEmail($this->Email);
		$this->MyDistributor->setShellRunningWithOutput();
		Configure::write('Session.cookie', 'simpletire-cli');

		// for job debugs
		if(!empty($workload->debug)) $this->debug = $workload->debug;
		if(!empty($workload->limit_warehouses)) $this->limit_warehouses = $workload->limit_warehouses;

		$changedWarehouses = array();

		//Fetch orders with loss upto amount
		$sql = "SELECT value from __module_settings WHERE _module_name = 'OrderFilter' AND name='order_loss_upto_amount'";
		$loss = $this->MyOrder->query($sql);
		$order_filters = (!empty($loss[0]['__module_settings']['value']) ? json_decode($loss[0]['__module_settings']['value'], true) : NULL);
		$loss_amount = 0;
		if(!empty($order_filters) && !empty($order_filters[strtolower($workload->MyOrder->source)])){
			$loss_amount = $order_filters[strtolower($workload->MyOrder->source)];
		}

		echo "\n\nMin Loss Amount for " . $workload->MyOrder->source . " : " . $loss_amount;

		// get the warehouse order data
		$sql = 'SELECT
					`my_distributors_warehouses_orders`.`id`,
					`my_distributors_warehouses_orders`.`automated_at`,
					`my_distributors_warehouses_orders`.`automated_status`,
					`my_distributors_warehouses_orders`.`warehouse_id`,
					`my_distributors_warehouses_orders`.`return_status`,
					`my_distributors_warehouses_orders_products`.`id`,
					`my_distributors_warehouses_orders_products`.`my_distributors_warehouses_order_id`,
					`my_distributors_warehouses_orders_products`.`quantity`,
					`my_distributors_warehouses_orders_products`.`cost`,
					`my_distributors_warehouses_orders_products`.`warehouse_part_num`,
					`my_distributors_warehouses`.`name`,
					`my_distributors_warehouses`.`label_format`,
					`my_order_products`.`my_product_id`,
					`my_order_products`.`my_product_name`,
					`my_order_products`.`price`,
					`my_order_products`.`add_road_hazard`,
					`my_order_products`.`road_hazard_amount`,
					`my_products`.`quick_search`,
					`my_products`.`part_number`,
					`my_products`.`weight`,
					`my_products`.`dim_height`,
					`my_products`.`dim_width`,
					`my_products`.`width_int`,
					`my_products`.`special_tax_fet`,
					`my_product_sub_types`.`name`
				FROM
					`my_distributors_warehouses_orders_products`
						INNER JOIN
					`my_order_products` ON `my_order_products`.`id` = `my_distributors_warehouses_orders_products`.`my_order_product_id`
						INNER JOIN
					`my_products` ON `my_products`.`id` = `my_order_products`.`my_product_id`
						LEFT JOIN
					`my_product_sub_types` ON `my_product_sub_types`.`id` = `my_products`.`product_sub_type_id`
						INNER JOIN
					`my_distributors_warehouses_orders` ON `my_distributors_warehouses_orders_products`.`my_distributors_warehouses_order_id` = `my_distributors_warehouses_orders`.`id`
						INNER JOIN
					`my_distributors_warehouses` ON `my_distributors_warehouses`.`id` = `my_distributors_warehouses_orders`.`warehouse_id`
				WHERE
					`my_distributors_warehouses_order_id` IN (SELECT
							my_distributors_warehouses_orders.id
						FROM
							my_distributors_warehouses_orders
							INNER JOIN my_orders ON (my_orders.id = my_distributors_warehouses_orders.my_order_id)
						WHERE
							my_order_id = '.$workload->MyOrder->id.' AND
							(CASE WHEN (my_orders.status="REPROCESS")
								THEN my_distributors_warehouses_orders.status="PENDING"
								ELSE TRUE
							END)
							)';
		$warehouse_orders = $this->MyOrder->query($sql, false);
		$num_warehouse_orders = count($warehouse_orders);
		foreach($warehouse_orders as $op) {
			$item_profits = $profits = $costs = $warehouse_data = array();

			echo "\nOrder ID #".$workload->MyOrder->id.", Warehouse Order ID #".$op['my_distributors_warehouses_orders']['id'].", Warehouse [".$op['my_distributors_warehouses']['name']."], Source=".$workload->MyOrder->source.", Status=".$workload->MyOrder->status.", ShipTotal=".$workload->MyOrder->shipping_total.", Total=".$workload->MyOrder->total;

			//skip order and put it in Review if Fraud
			if ($this->isFraudOrder($workload)) {
				echo "\nORDER might be Fraud, Skipping and changing the status to Review";
				if (empty($this->debug)) {
					$sql = "UPDATE my_orders SET status='Review' WHERE id = '".$workload->MyOrder->id."'";
					$this->MyOrder->query($sql);
				}
				continue;
			}

			// setup the shipping components at each loop, see SIM-1596
			$this->MyDistributor->setFedex(new FedexComponent());
			$this->MyDistributor->setFreightQuote(new FreightQuoteComponent());
			$this->MyDistributor->setUps(new UpsComponent());

			// check if some other process already did automation
			if(!empty($op['my_distributors_warehouses_orders']['automated_status'])) {
				echo "\n!!! Automation already done, skipping.";
				if(empty($workload->force_run)) continue;
			}

			// If Order in ReProcess and Cancellation Accepted -> Update Order to Cancelled and continue to next order
			if($workload->MyOrder->status == 'ReProcess' && $op['my_distributors_warehouses_orders']['return_status']==4) {
				echo "\n!!! Order Cancelled. Updating Order to Cancelled and skipping further process";
				if(empty($this->debug)) {
					$logData = array(
						'id' => $workload->MyOrder->id,
						'order_id' => $workload->MyOrder->id,
						'current_value' => 'Void'
					);
					addOrderLog($logData,LogTypeEnumComponent::$OrderStatusChanged,"MyOrder","status");
				}else{
					echo "\nSET LOG OrderStatusChanged";
				}

				// make the status change
				if(empty($this->debug)) {
					$sql = "UPDATE my_orders SET status='Void', automated_at=NOW() WHERE id = '".$workload->MyOrder->id."'";
					$this->MyOrder->query($sql);
				} else {
					echo "\nSET ORDER TO VOID!";
				}
				continue;
			}

			// track status that we have found warehouse orders
			$sql = "UPDATE my_distributors_warehouses_orders SET automated_status=1 WHERE id = '".$op['my_distributors_warehouses_orders']['id']."'";
			if($this->debug) {
				echo "\nSQL=$sql";
			} else {
				$this->MyOrder->query($sql);
			}

			// get the long/lat of the shipping zip, default to center of usa
			$latitude = 39.50;
			$longitude = -98.35;
			$zip = $this->Zip->query("SELECT longitude, latitude FROM zips WHERE zip = '".$workload->MyOrder->shipping_zip."'", false);
			if(!empty($zip)) {
				$latitude = $zip[0]['zips']['latitude'];
				$longitude = $zip[0]['zips']['longitude'];
			}

			// limit results to only those we expect to be profitable on
			$max_allowed_cost = $op['my_order_products']['price'] * 1.30;

			// get all warehouses that have this product
			$extraJoin = "";
			$warehouse_conditions = "my_distributors_warehouses_products.product_id='".$op['my_order_products']['my_product_id']."'
									 AND my_distributors_warehouses_products.quantity >= '".$op['my_distributors_warehouses_orders_products']['quantity']."'
									 AND my_distributors_warehouses_products.price BETWEEN .01 AND '".$max_allowed_cost."'";
			if($workload->MyOrder->source == 'WalMart') {
				$extraJoin = "INNER JOIN wholesale_warehouses WW ON WW.warehouse_id = my_distributors_warehouses.id AND WW.wholesale_id = 45";
			}
			$warehouse_conditions .= ' AND my_distributors_warehouses.inventory_set_id = 1'; // force to only use primary inventory source
			//checkfor max cap value
			$warehouse_conditions .= ' AND IF(my_distributors_warehouses.max_orders_cap_limit!=0,my_distributors_warehouses.max_orders_cap_count < my_distributors_warehouses.max_orders_cap_limit,my_distributors_warehouses.max_orders_cap_limit=0)';
			//Check if any warehouses selected previously
			if($workload->MyOrder->status == 'ReProcess') {
				$hasPreviousAssignment = false;
				$whSql = "SELECT DISTINCT warehouse_id FROM my_order_history_logs WHERE order_id = ".$workload->MyOrder->id." AND log_type_id IN (".LogTypeEnumComponent::$WarehouseChanged.",".LogTypeEnumComponent::$SendWarehouseEmail.") AND warehouse_id IS NOT NULL AND warehouse_id != 685";
				if($this->debug) {
					echo "\n$whSql";
				}
				$previousWarehouses = $this->MyDistributorsWarehousesProduct->query($whSql, false);
				if(!empty($previousWarehouses)){
					$hasPreviousAssignment = true;
					$prevWhs = array();
					foreach ($previousWarehouses as $wh){
						$prevWhs[] = $wh['my_order_history_logs']['warehouse_id'];
					}
					if(!empty($prevWhs)){
						$warehouse_conditions .= ' AND my_distributors_warehouses.id NOT IN ('.implode(",",$prevWhs).')';
					}
				}
				if(empty($hasPreviousAssignment)) {
					if($this->debug) {
						echo "\nREPROCESS WITHOUT PREVIOUS WAREHOUSE_ID LOG!";
					}
					echo "\n!!! ReProcess without prior warehouses defined, skipping.";
					continue;
				}
			}

			if($this->debug) {
				echo "\nWAREHOUSE CONDITIONS=$warehouse_conditions";
			}


			$fedex_only_warehouse_column = "";
			$fedex_only_warehouse_having = "";
			if(!empty($workload->MyOrder->my_installer_id)){
				$my_installer_id = $workload->MyOrder->my_installer_id;

				$sql = "SELECT my_installers.`pickup_only` FROM my_installers WHERE id='{$my_installer_id}'";
				$pickup_check = $this->MyDistributorsWarehousesProduct->query($sql);
				// For inserting installer order data in my_installer_orders table
				if ($pickup_check[0]['my_installers']['pickup_only'] == 0){
					$insert_installer_order_sql = "INSERT INTO my_installer_orders (my_installer_id, my_order_id, my_distributors_warehouses_order_id, created, modified) VALUES ('" . $my_installer_id . "','" . $workload->MyOrder->id . "','" . $op['my_distributors_warehouses_orders']['id'] . "',NOW(),NOW()) ON DUPLICATE KEY UPDATE modified = NOW()";
					if($this->debug){
						echo "\nInsert Installer Order\n".$insert_installer_order_sql;
					}else {
						$this->MyDistributorsWarehousesProduct->query($insert_installer_order_sql);
					}
				}

				// For making sure that we don't select a UPS only warehouse for Fedex Pickup Location Orders
				$fedex_only_warehouse_column = ",(SELECT IF(my_installers.`pickup_only`=1, my_installers.`pickup_type`, NULL) FROM my_installers WHERE id='{$my_installer_id}') AS pickup_type";
				$fedex_only_warehouse_having = "HAVING IF(pickup_type!=NULL,my_distributors_warehouses.`ship_carrier`=pickup_type,my_distributors_warehouses.`ship_carrier` IS NOT NULL)";
			}

			$sql = "SELECT
						my_distributors_warehouses_products.warehouse_id,
						my_distributors_warehouses_products.product_id,
						my_distributors_warehouses_products.price,
						my_distributors_warehouses_products.warehouse_part_num,
						my_distributors_warehouses_products.source_item_desc,
						my_distributors_warehouses.name,
						my_distributors_warehouses.zip,
						my_distributors_warehouses.local_delivery,
						my_distributors_warehouses.install_price_per_tire,
						my_distributors_warehouses.daily_pickup,
						my_distributors_warehouses.ship_carrier,
						my_distributors_warehouses.pickup_time,
						my_distributors_warehouses.disable_order_automation,
						my_distributors_warehouses.tire_binding,
						CEILING((sqrt(power(69.1*(my_distributors_warehouses.latitude - $latitude ),2)+ power(69.1*(my_distributors_warehouses.longitude- $longitude )*cos(my_distributors_warehouses.latitude/57.3),2))/100))*100 AS distance
						".$fedex_only_warehouse_column."
					FROM
						my_distributors_warehouses_products
						INNER JOIN
							my_distributors_warehouses ON my_distributors_warehouses.id = my_distributors_warehouses_products.warehouse_id
						" . $extraJoin . "
					WHERE
						".$warehouse_conditions."
						".$fedex_only_warehouse_having."
					ORDER BY
						my_distributors_warehouses_products.price ASC, distance ASC, RAND()";
			if(!empty($workload->limit_warehouses)) $sql .= " LIMIT ". $this->limit_warehouses;

			$products = $this->MyDistributorsWarehousesProduct->query($sql, false);

			// loop through to locate the best price
			$num_total = count($products);
			echo "\n* Found ".$num_total." warehouses to review.";
			$num_iter = 0;
			foreach($products as $prod) { $num_iter++;
				$distance = $prod['0']['distance'];
				$anti_distance = 100000 - $distance; // to make a closer distance a bigger number

				echo "\n  + [".$num_iter."/".$num_total."] Processing ".$prod['my_distributors_warehouses']['name'].", id=". $prod['my_distributors_warehouses_products']['warehouse_id'] ." from ".$workload->MyOrder->shipping_zip." to ". $prod['my_distributors_warehouses']['zip'] ." (". $distance ." miles)";

				//check Program Incentive and update cost
				$incentive_cost = 0;
				$appliedPrograms = NULL;
				$incentiveCost = $this->MyDistributor->getIncentivePrice($prod['my_distributors_warehouses_products']['warehouse_id'], $prod['my_distributors_warehouses_products']['product_id'],$prod['my_distributors_warehouses_products']['price']);
				if(!empty($incentiveCost) && !empty($incentiveCost['incentiveDetail'])){
					echo "\n	 |- Cost before Programs Incentive: ".$prod['my_distributors_warehouses_products']['price'];
					//$prod['my_distributors_warehouses_products']['price'] = $incentiveCost['cost'];
					$incentive_cost = $incentiveCost['cost'];
					$appliedPrograms = implode(",", $incentiveCost['applicablePrograms']);
					echo "\n	 |- Cost after Programs Incentive: ".$incentiveCost['cost'];
					echo "\n	 |- Programs Applied: ".implode(" | ",$incentiveCost['incentiveDetail']);
				}

				// store the base item profit
				$anticipated_cost = !empty($incentive_cost) && $incentive_cost < $prod['my_distributors_warehouses_products']['price'] ? $incentive_cost : $prod['my_distributors_warehouses_products']['price'];
				$item_profit = number_format((($op['my_order_products']['price'] - $anticipated_cost) * $op['my_distributors_warehouses_orders_products']['quantity']),2,".","");
				$item_profits[$prod['my_distributors_warehouses_products']['warehouse_id']] = number_format($item_profit, 2, ".", "");

				// store the buy price
				$costs[$prod['my_distributors_warehouses_products']['warehouse_id']] = $prod['my_distributors_warehouses_products']['price'];

				// store the details about the warehouse related to shipping
				$warehouse_data[$prod['my_distributors_warehouses_products']['warehouse_id']] = am($prod['my_distributors_warehouses'],$prod['my_distributors_warehouses_products']);
				$warehouse_data[$prod['my_distributors_warehouses_products']['warehouse_id']]['warehouse_delivers'] = 0;
				$warehouse_data[$prod['my_distributors_warehouses_products']['warehouse_id']]['incentive_cost'] = $incentive_cost;
				$warehouse_data[$prod['my_distributors_warehouses_products']['warehouse_id']]['appliedPrograms'] = $appliedPrograms;

				//TODO deal with other no charge shipping situations like wholesale
				if($workload->MyOrder->source == 'WalMart' || $this->_isNoShipping($workload->MyOrder->wholesale_id)) {
					$profits[$prod['my_distributors_warehouses_products']['warehouse_id']] = number_format($item_profit, 2, ".", "").$anti_distance;
					echo "\n	 |- Shipping 3rd Party, Item Profit = $item_profit";

					// with incentives we need to run through all options
					//if($num_iter == 1) {
					//	// since we aren't dealing with shipping then stop at the first item
					//	break;
					//}
				} else {
					$get_real_shipping_rates = true;
					if(!empty($workload->MyOrder->my_installer_id)) {
						echo "\n	 |- Potential Local Delivery To Installer ID ".$workload->MyOrder->my_installer_id;

						$wi = $MyDistributorsWarehousesInstaller->find('first', array(
							'fields' => array('MyDistributorsWarehousesInstaller.id','MyInstaller.pickup_only','MyInstaller.pickup_type'),
							'conditions' => array(
								'MyDistributorsWarehousesInstaller.my_installer_id' => $workload->MyOrder->my_installer_id,
								'MyDistributorsWarehousesInstaller.my_distributors_warehouse_id' => $prod['my_distributors_warehouses_products']['warehouse_id'],
								'MyDistributorsWarehousesInstaller.is_shippable' => '1'
							)
						));
						if(!empty($wi)) {
							if(strtolower($wi['MyInstaller']['pickup_type']) != "fedex" || (strtolower($wi['MyInstaller']['pickup_type']) == "fedex" && empty($wi['MyInstaller']['pickup_only']))) {
								$warehouse_data[$prod['my_distributors_warehouses_products']['warehouse_id']]['warehouse_delivers'] = 1;

								$ship_cost = !empty($prod['my_distributors_warehouses']['install_price_per_tire']) ? round($prod['my_distributors_warehouses']['install_price_per_tire'] * $op['my_distributors_warehouses_orders_products']['quantity'], 2) : 0;
								$ship_profit = number_format($workload->MyOrder->shipping_total - $ship_cost, 2, ".", "");
								$total_profit = number_format($item_profit + $ship_profit, 2, ".", "");

								echo "\n	 |- Local Delivery Ship Cost = $ship_cost, Item Profit = $item_profit, Ship Profit = $ship_profit, Total Profit = $total_profit";

								$profits[$prod['my_distributors_warehouses_products']['warehouse_id']] = number_format($total_profit, 2, ".", "") . $anti_distance;
								$get_real_shipping_rates = false;
							}else{
								echo "\n No Local Delivery, Ship to Fedex Office Location";
							}
						}
					}

					if($get_real_shipping_rates) {
						// TODO finish the logic with warehouse delivers and ship profit, wholesale or other non shipping situations
						$url = API_URL().'/shipping/warehouse/' . $op['my_order_products']['my_product_id'] . '/' . $op['my_distributors_warehouses_orders_products']['quantity'] . '/' . $workload->MyOrder->shipping_zip . '/' . $workload->MyOrder->shipping_residential . '/' . $prod['my_distributors_warehouses_products']['warehouse_id'] . '/0cfc3f81e47a6b6e06099cf890417d57';
						$HttpSocket = new HttpSocket();
						$rates = $HttpSocket->get($url);
						$rates = json_decode($rates, true);

						if (is_array($rates) && !empty($rates['success']) && $rates['success'] == 1 && ((isset($rates['rates']) && !empty($rates['rates'])) || (isset($rates['FreightQuote']) && !empty($rates['FreightQuote'])))) {
							$rate = $fq_rate = 0;
							if(!empty($rates['rates'])) {
								$rate = empty($workload->MyOrder->shipping_residential) ? $rates['rates']['Standard_Shipping']['rate'] : $rates['rates']['Standard_Shipping']['rate_residential'];
							}
							if(!empty($rates['FreightQuote'])){
								$fq_rate = empty($workload->MyOrder->shipping_residential) ? $rates['FreightQuote']['Standard_Shipping']['rate'] : $rates['FreightQuote']['Standard_Shipping']['rate_residential'];
								if($fq_rate < $rate){
									$rate = $fq_rate;
									$warehouse_data[$prod['my_distributors_warehouses_products']['warehouse_id']]['ship_carrier'] = "FreightQuote";
								}
							}
							$ship_profit = number_format($workload->MyOrder->shipping_total - $rate, 2, ".", "");
							$total_profit = number_format($item_profit + $ship_profit, 2, ".", "");
							echo "\n	 |- Rate = $rate, Item Profit = $item_profit, Ship Profit = $ship_profit, Total Profit = $total_profit";

							$profits[$prod['my_distributors_warehouses_products']['warehouse_id']] = number_format($total_profit, 2, ".", "").$anti_distance;
						}
					}
				}
			}

			// if we have profit data set the warehouse with the best profit
			if(count($profits)) {
				arsort($profits, SORT_NUMERIC);
				$profits = array_slice($profits, 0, 1, true);

				// profits will only have one record at this point
				foreach($profits as $best_warehouse_id=>$profit) {
					// force manual review, primarily applicable when reprocessing
					if((empty($loss_amount) && $profit < 0) || (!empty($loss_amount) && $item_profits[$best_warehouse_id] < $loss_amount)) continue;

					//TODO additional logic of minimum markup?
					$cost = @$costs[$best_warehouse_id];
					$this_best_warehouse = @$warehouse_data[$best_warehouse_id];
					if(!empty($cost) && !empty($this_best_warehouse)) {
						echo "\n  ! Set warehouse to id=".$best_warehouse_id .", cost=".$cost;

						// start by assuming we will not be fully automating, only possibly generating labels
						$complete_automation = false;
						$getCapData = $this->MyDistributor->getWarehouseDataByID($best_warehouse_id);
						// update the warehouse
						$sql = "UPDATE my_distributors_warehouses_orders SET warehouse_id='".$best_warehouse_id."', warehouse_delivers='".$this_best_warehouse['warehouse_delivers']."', automated_status=2 WHERE id = '".$op['my_distributors_warehouses_orders']['id']."'";
						$changedWarehouses[] = $op['my_distributors_warehouses_orders']['id'];
						if($this->debug) {
 							echo "\nSQL=$sql";
 						}else{
							$this->MyDistributor->updateWarehouseCapDataByWarehouseID($best_warehouse_id,$getCapData,1);
 							$this->MyOrder->query($sql);
 						}

						//Update the warehouse in labels if Order is in ReProcess
						if($workload->MyOrder->status == 'ReProcess') {
							// Update the warehouse in labels if not freight order
							if(empty($workload->MyOrder->freight_order)) {
								// set the existing labels to this warehouse
								$sql = "UPDATE my_distributors_warehouses_orders_shipping_labels SET my_distributors_warehouse_id = '" . $best_warehouse_id . "' WHERE my_distributors_warehouses_order_id = '" . $op['my_distributors_warehouses_orders']['id'] . "'";
								if (empty($this->debug)) {
									// update warehouse_id of existing labels
									$this->MyOrder->query($sql);

									// regenerate labels and delete old ones if Shipping Carrier or binding condition is not same
									$this->MyOrder->regenerateLabelsIfRequired($op['my_distributors_warehouses_orders']['id'], $this->MyDistributor);
								} else {
									echo "\nDEBUG, DO NOT SET WAREHOUSE LABEL\n";
									echo $sql;
								}
							}else{
								//Cancel Labels if freight order
								$MyDistributorsWarehousesOrdersShippingLabel = getModel('MyDistributorsWarehousesOrdersShippingLabel');
								$labels = $MyDistributorsWarehousesOrdersShippingLabel->find('all', array('conditions' => array('MyDistributorsWarehousesOrdersShippingLabel.my_distributors_warehouses_order_id' => $op['my_distributors_warehouses_orders']['id'], 'MyDistributorsWarehousesOrdersShippingLabel.status' => 'Active')));
								if (!empty($labels)) {
									foreach($labels AS $label) {
										if ($this->debug) {
											echo "\nCancel Label with LabelId: ".$label['MyDistributorsWarehousesOrdersShippingLabel']['id'].", Tracking #: ".$label['MyDistributorsWarehousesOrdersShippingLabel']['tracking_number'].", Shipping Method: ".$label['MyDistributorsWarehousesOrdersShippingLabel']['shipping_method'];
										}else{
											$MyDistributorsWarehousesOrdersShippingLabel->id = $label['MyDistributorsWarehousesOrdersShippingLabel']['id'];
											$MyDistributorsWarehousesOrdersShippingLabel->saveField('status', 'Cancelled');
											$this->MyDistributor->cancelShipment($label['MyDistributorsWarehousesOrdersShippingLabel']['tracking_number'], $label['MyDistributorsWarehousesOrdersShippingLabel']['shipping_method']);
											// Create history log -start
											$logData = array(
												'order_id' => $workload->MyOrder->id,
												'original_value' => $label['MyDistributorsWarehousesOrdersShippingLabel']['id'],
												'my_distributors_warehouses_order_id' => $label['MyDistributorsWarehousesOrdersShippingLabel']['my_distributors_warehouses_order_id']
											);
											addOrderLog($logData, LogTypeEnumComponent::$ShipLabelCancelled);
											// Create history log -end
										}
									}
								}
							}
						}

						// update the expected cost
						$sql = "UPDATE my_distributors_warehouses_orders_products SET cost='".$cost."', warehouse_part_num='".mysql_escape_string($this_best_warehouse['warehouse_part_num'])."', source_item_desc='".mysql_escape_string($this_best_warehouse['source_item_desc'])."', cost_incentive='".$this_best_warehouse['incentive_cost']."', program_ids='".$this_best_warehouse['appliedPrograms']."' WHERE id = '".$op['my_distributors_warehouses_orders_products']['id']."'";
						if($this->debug) {
							echo "\nSQL=$sql";
						}else{
							$this->MyOrder->query($sql);
						}

						// log the activity
						if(empty($this->debug)) {
							$logData = array(
								'order_id' => $workload->MyOrder->id,
								'my_distributors_warehouses_order_id' => $op['my_distributors_warehouses_orders']['id'],
								'current_value' => $this_best_warehouse["name"],
								'original_value' => $op['my_distributors_warehouses']['name'],
								'warehouse_id' => $best_warehouse_id
							);
							addOrderLog($logData,LogTypeEnumComponent::$WarehouseChanged);
						}else{
							echo "\nSET LOG WarehouseChanged";
						}

						// keep our virtual inventory current
						$this->_update_supplier_qty($workload->MyOrder->id, $automation_started);

						// conditions for generating labels
						$generate_labels = false;
						$attemptSchedulePickup = empty($this_best_warehouse['daily_pickup']);

						// default options for the labels
						$generate_label_options = array();
						$generate_label_options['ship_carrier'] = 'Fedex';
						$generate_label_options['shipping_option'] = 'Standard_Shipping';
						$generate_label_options['options'] = 'each';
						$generate_label_options['pickup_time'] = '10:00';
						$generate_label_options['pickup_date'] = $this->MyDistributor->next_business_day(date("Y-m-d"));
						$generate_label_options['special_instructions'] = '';
						$generate_label_options['scheduled_pickup'] = '0';
						$generate_label_options['combine_bol'] = '';
						if($workload->MyOrder->source == 'WalMart') {
							$this_order_response = NULL;

							// contains the request xml object from walmart
							$mp_data = $this->MyOrder->query("SELECT mp_response FROM my_orders WHERE id = '".$workload->MyOrder->id."'", false);
							if(!empty($mp_data)) {
								$mp_response = json_decode($mp_data[0]['my_orders']['mp_response']);
								$xml_orders = is_array($mp_response->WMIORDERREQUEST->OR_ORDER) ? $mp_response->WMIORDERREQUEST->OR_ORDER : array($mp_response->WMIORDERREQUEST->OR_ORDER);
								foreach ($xml_orders as $xo) {
									if ($xo->{"@attributes"}->{"ORDERNUMBER"} == $workload->MyOrder->walmart_order_id) {
										$this_order_response = $xo;
										break;
									}
								}
							}

							// verify it is an accurate carrier code, forced all to Fedex
							if(!empty($this_order_response)) {
								$carrier_code = @$this_order_response->OR_SHIPPING->{"@attributes"}->{"CARRIERMETHODCODE"};
								if(in_array($carrier_code, array(20, 79))) { //fedex, ground
									$generate_label_options['ship_carrier'] = 'Fedex';
									$generate_label_options['shipping_option'] = 'Standard_Shipping';
									$generate_labels = true;
									$complete_automation = true;
									if($this->debug) {
										echo "\n WALMART - CC:" . $carrier_code . " - Standard_Shipping";
									}
								}else if(in_array($carrier_code, array(67))) { //fedex, home delivery
									$generate_label_options['ship_carrier'] = 'Fedex';
									$generate_label_options['shipping_option'] = 'Ground_Home_Delivery';
									if($op['my_products']['weight'] > 70) $generate_label_options['shipping_option'] = 'Standard_Shipping';
									$generate_labels = true;
									$complete_automation = true;
									if($this->debug) {
										echo "\n WALMART - CC:" . $carrier_code . " - Ground_Home_Delivery";
									}
								} else {
									if($this->debug) {
										echo "\n WALMART - ELSE - Standard_Shipping";
									}
								}
							}
						}else if(empty($this_best_warehouse['warehouse_delivers'])){
							//TODO add more logic to generate labels for other types of orders
							$generate_label_options['ship_carrier'] = $this_best_warehouse['ship_carrier'];
							$generate_label_options['pickup_time'] = $this_best_warehouse['pickup_time'];

							// create fedex ground only labels
							//TODO deal with UPS and express shipping?
							if(empty($workload->MyOrder->freight_order) &&
								in_array($workload->MyOrder->shipping_option, array('Ground_Home_Delivery','Standard_Shipping')) &&
								$this_best_warehouse['ship_carrier'] == 'Fedex') {
									$generate_label_options['shipping_option'] = !empty($workload->MyOrder->shipping_residential) && $op['my_products']['weight'] <= 70 ? 'Ground_Home_Delivery' : 'Standard_Shipping';
									$generate_labels = true;
							}else if(empty($workload->MyOrder->freight_order) &&
										$generate_label_options['shipping_option'] == 'Standard_Shipping' &&
										$this_best_warehouse['ship_carrier'] == 'UPS'){
									$generate_labels = true;
							}else if(!empty($workload->MyOrder->freight_order) && $this_best_warehouse['ship_carrier'] == 'FreightQuote') {
								$generate_labels = true;
							}

							// set complete_automation flag for the orders we are allowing
							if(!empty($generate_labels) &&
								($this->_isPayPalOrderCompleted($workload->MyOrder) || $workload->MyOrder->status == 'ReProcess')) {
									$complete_automation = true;
							}
						}

						//decide weather to bind labels

						$binding_info = $this->MyOrder->checkForBinding(
							$workload->MyOrder->source,
							$this_best_warehouse,
							$op['my_distributors_warehouses_orders_products']['quantity'],
							$op['my_products']['weight'],
							$op['my_products']['dim_width'],
							$op['my_products']['dim_height'],
							$generate_label_options['shipping_option']
						);

						if($binding_info['is_binding']) {
							$generate_label_options['options'] = 'bounded';
						}

						if($this->debug) {
							echo $binding_info['debug'];
						}

						// we are going to generate some shipping labels for this best warehouse
						if(!empty($generate_labels)){
							echo "\n  !! Generate ". $generate_label_options['options'] ." Labels For ".$generate_label_options['ship_carrier'];

							// update our automated status
							$sql = "UPDATE my_distributors_warehouses_orders SET automated_status=3 WHERE id = '".$op['my_distributors_warehouses_orders']['id']."'";
							if($this->debug) {
								echo "\nSQL=$sql";
							}else{
								$this->MyOrder->query($sql);
							}

							// set the new shipping option
							$sql = "UPDATE my_orders SET shipping_option = '".$generate_label_options['shipping_option']."' WHERE id = '".$workload->MyOrder->id."'";
							if($this->debug) {
								echo "\nSQL=$sql";
							}else{
								$this->MyOrder->query($sql);
							}

							// check for a run away process that has generated a ton of labels
							$num_labels_generated = 0;
							$test_labels = $MyDistributorsWarehousesOrdersShippingLabel->find('all', array(
												'conditions' => array(
														'MyDistributorsWarehousesOrdersShippingLabel.my_distributors_warehouses_order_id' => $op['my_distributors_warehouses_orders']['id'],
														'NOT' => array('MyDistributorsWarehousesOrdersShippingLabel.status' => 'Cancelled',
																		'MyDistributorsWarehousesOrdersShippingLabel.shipping_method' => 'Walmart')
													),
												'fields' => array('id')
												));
							if(count($test_labels) < $op['my_distributors_warehouses_orders_products']['quantity']) {
								// get the label
								if(empty($this->debug)) {
									$attemptSchedulePickup = false; //TODO verify logic works for this
									$this->MyDistributor->setAttemptSchedulePickup($attemptSchedulePickup);
									$this->MyDistributor->resetMasterTrackingNumbers(); // see SIM-1596
									$labels = $this->MyDistributor->generateLabel($op['my_distributors_warehouses_orders']['id'], $workload->MyOrder->id, $best_warehouse_id, $generate_label_options['options'], $generate_label_options['ship_carrier'], $generate_label_options, NULL, NULL, $op['my_distributors_warehouses']['label_format']);
								} else {
									echo "\nDEBUG, NOT GENERATING LABELS\n";
									print_r($generate_label_options);
									$labels = array(0);
								}
							} else if (count($test_labels) == $op['my_distributors_warehouses_orders_products']['quantity']) {
								// assume the labels aready in place are all still ready to go
								$num_labels_generated = $op['my_distributors_warehouses_orders_products']['quantity'];
							}else{
								if(empty($this->debug)) {
									echo "\nRUN AWAY LABEL PROCESS!";
									continue;
								}else{
									echo "\nDEBUG, NOT GENERATING LABELS\n";
									print_r($generate_label_options);
									$labels = array();
									for($z=0;$z<$op['my_distributors_warehouses_orders_products']['quantity'];$z++) {
										$labels[$z] = 0;
									}
								}
							}

							if(!empty($labels)) {
								$num_labels_generated = count($labels);

								// log the label
								if(empty($this->debug)) {
									$logData = array(
										'order_id' => $workload->MyOrder->id,
										'current_value' => implode(",",$labels),
										'my_distributors_warehouses_order_id' => $op['my_distributors_warehouses_orders']['id'],
									);
									addOrderLog($logData,LogTypeEnumComponent::$ShipLabelGenerated);
								}else{
									echo "\nSET LOG ShipLabelGenerated";
								}
							}

							$daily_pickup_satisfied = (empty($this_best_warehouse['daily_pickup']) ? $this->_isPickupGenerated($op['my_distributors_warehouses_orders']['id']) : true);

							echo "\n\n + Warehouse & Label Conditions";
							echo "\n\t|- Number of generated labels: $num_labels_generated";
							echo "\n\t|- Total QTY: {$op['my_distributors_warehouses_orders_products']['quantity']}";
							echo "\n\t|- Disable Order Automation: ". ($this_best_warehouse['disable_order_automation'] ? 'TRUE' : 'FALSE');
							echo "\n\t|- Daily Pick satisfied: ".($daily_pickup_satisfied ? 'TRUE' : 'FALSE');

							// change status and email as long as the selected warehouse allows automation, has a daily pickup, and we are allowing the automation
							if ($num_labels_generated > 0) {
								if ($num_labels_generated == $op['my_distributors_warehouses_orders_products']['quantity'] &&
									empty($this_best_warehouse['disable_order_automation']) &&
									$daily_pickup_satisfied) {
									// update our automated status
									$sql = "UPDATE my_distributors_warehouses_orders SET automated_status=4 WHERE id = '" . $op['my_distributors_warehouses_orders']['id'] . "'";
									if ($this->debug) {
										echo "\nSQL=$sql";
									} else {
										$this->MyOrder->query($sql);
									}
								} else {
									if ($this->debug) {
										echo "\nCANNOT FINISH AUTOMATION, complete_automation = $complete_automation, $num_labels_generated vs " . $op['my_distributors_warehouses_orders_products']['quantity'];
										print_r($this_best_warehouse);
									}
								}
							}
						} else if (!empty($this->debug)) {
							echo "\nNO GENERATE LABELS";
							echo "\n + Source = " . $workload->MyOrder->source;
							echo "\n + Freight = " . $workload->MyOrder->freight_order;
							echo "\n + Shipping Option = " . $workload->MyOrder->shipping_option;
							echo "\n + Carrier Code = " . @$carrier_code;
							print_r($this_best_warehouse);
						}
					}
				}
			}

			$sql = "UPDATE my_distributors_warehouses_orders SET automated_at=NOW() WHERE id = '".$op['my_distributors_warehouses_orders']['id']."'";
			if($this->debug) {
				echo "\nSQL=$sql";
			}else{
				$this->MyOrder->query($sql);
			}
		}

		/*
		 * -----------------------------
		 * DECIDE to process the order
		 * -----------------------------
		 */

		echo "\n\n + Processing Conditions";

		//get the allowed/eligible sources
		$source_condition = $workload->MyOrder->source == 'WalMart';
		if ($order_automation_level == 1) {
			$source_condition = $workload->MyOrder->source != 'Simple';
		}
		echo "\n\t|- Source Condition: " . ($source_condition ? 'TRUE' : 'FALSE');

		//get warehouse order whose automation is completed to status 4
		$check_warehouse_automation_a = $this->MyOrder->query("SELECT COUNT(id) AS n FROM my_distributors_warehouses_orders WHERE my_order_id = '" . $workload->MyOrder->id . "' AND automated_status = 4", false);
		echo "\n\t|- Automated warehouse: " . $check_warehouse_automation_a[0][0]['n'];

		// get valid conditions to proceed
		$validConditionsToProceed = (count($changedWarehouses) > 0 && $num_warehouse_orders > 0 && $check_warehouse_automation_a[0][0]['n'] == $num_warehouse_orders);
		echo "\n\t|- Valid to Proceed: " . ($validConditionsToProceed ? 'TRUE' : 'FALSE');

		//if valid then proceed with processing the order
		if ($validConditionsToProceed) {

			// charge card if applicable
			$cardChargedObject = $this->chargeCard($workload);

			if(empty($cardChargedObject['card_error'])) {

				$cardCharged = $cardChargedObject['card_charged'];

				if ($source_condition || $this->_isPayPalOrderCompleted($workload->MyOrder) || $workload->MyOrder->status == 'ReProcess' || $cardCharged) {

					// run supplier automation if exist. $automation_result will result true if it doesn't exist
					$this->MyOrder->called_from_automation = true;
					$automation_result = $this->MyOrder->do_supplier_automation($workload->MyOrder->id, null, $this->debug);

					//Save Supplier Automation Message to Order Log
					if (!empty($this->MyOrder->supplier_automation_msg)) {
						if (empty($this->debug)) {
							$logData = array(
								'order_id'      => $workload->MyOrder->id,
								'current_value' => $this->MyOrder->supplier_automation_msg
							);
							addOrderLog($logData, LogTypeEnumComponent::$SupplierAutomationMessage);
						} else {
							echo "\nSET LOG SupplierAutomationMessage\n" . $this->MyOrder->supplier_automation_msg;
						}
					}

					echo "\n\n  !! Processing Order !!";

					// finally process order if everything looks good
					if (!empty($automation_result['success']) || $cardCharged) {
						// log the status change
						if (empty($this->debug)) {
							$logData = array(
								'id'            => $workload->MyOrder->id,
								'order_id'      => $workload->MyOrder->id,
								'current_value' => 'Processed'
							);
							addOrderLog($logData, LogTypeEnumComponent::$OrderStatusChanged, "MyOrder", "status");
						} else {
							echo "\nSET LOG OrderStatusChanged";
						}

						// make the status change
						if (empty($this->debug)) {
							$this->MyOrder->id = $workload->MyOrder->id;
							$this->MyOrder->save(array(
								'status'    => 'Processed',
								'processed' => date('Y-m-d H:i:s')
							));
						} else {
							echo "\nSET ORDER TO PROCESSED!";
						}

						// set warehouse orders to Ready
						if (empty($this->debug)) {
							// $this->MyDistributorsWarehousesOrder->updateAll(
							// 	array('MyDistributorsWarehousesOrder.status' => 'Ready'),
							// 	array('MyDistributorsWarehousesOrder.my_order_id' => $workload->MyOrder->id)
							// );
							$this->MyDistributorsWarehousesOrder->query("UPDATE my_distributors_warehouses_orders SET status='Ready', fulfill_assigned_at=NOW(),fulfill_rejected_at=NULL,fulfill_picked_at=NULL,required_ship_date=NULL,fulfill_downloaded_at=NULL WHERE status = 'PENDING' AND my_order_id = '" . $workload->MyOrder->id . "'");
							updateRequiredShipDates($workload->MyOrder->id);
						} else {
							echo "\nSET WAREHOUSE ORDERS TO READY!";
						}

						// TODO migrate the _sendInstallerEmail to MyDistributor
						echo "\n  !! Send Email";
						if (empty($this->debug)) {
							// FOR SUPPLIER AUTOMATION
							//if(!empty($warehouses_orders_to_be_emailed)) {
							//	foreach($warehouses_orders_to_be_emailed as $a => $warehouse_order_id) {
							$this->MyDistributor->_sendWarehouseEmail($workload->MyOrder->id, $changedWarehouses);
							//	}
							//}
						} else {
							echo "\nDEBUG, NOT SENDING EMAIL";
						}
					}

					if(empty($automation_result['success'])) {

						$warehouse_order_ids = implode(',', $automation_result['succeeded_warehouses']);

						if (empty($this->debug)) {
							//set warehouse order status in case some of the warehouse orders are succeeded
							if (!empty($warehouse_order_ids)) {
								$this->MyDistributorsWarehousesOrder->query("UPDATE my_distributors_warehouses_orders SET status='Ready', fulfill_assigned_at=NOW(),fulfill_rejected_at=NULL,fulfill_picked_at=NULL,required_ship_date=NULL,fulfill_downloaded_at=NULL WHERE id IN (" . $warehouse_order_ids . ")");
								//get order id for all the warehouse order ids and update Required Ship Dates for each
								$orders = $this->MyDistributorsWarehousesOrder->query("SELECT DISTINCT my_order_id FROM my_distributors_warehouses_orders WHERE id IN (" . $warehouse_order_ids . ")");
								foreach ($orders as $w) {
									echo "\nWorking for " . $w['my_distributors_warehouses_orders']['my_order_id'];
									updateRequiredShipDates($w['my_distributors_warehouses_orders']['my_order_id']);
								}
							}
						} else {
							echo "\nORDER AUTOMATION FAILED - SET ORDER TO REVIEW!";
							echo "\nSET SELECTED WAREHOUSE ORDERS TO READY! - " . $warehouse_order_ids;
						}
					}
				}

			} else {
				echo "\nCard Error!";
			}

		}

		$sql = "UPDATE my_distributors_warehouses_orders SET automated_at=NOW(),automated_status='99' WHERE my_order_id = '".$workload->MyOrder->id."' AND automated_at IS NULL";
		if($this->debug) {
			echo "\nSQL=$sql";
		}else{
			$this->MyOrder->query($sql);
		}

		// make sure it is synced
		if(empty($this->debug)) {
			$this->MyOrder->recalcTotals($workload->MyOrder->id);
		}

		$sql = "UPDATE my_orders SET automated_at=NOW() WHERE id = '".$workload->MyOrder->id."'";
		if($this->debug) {
			echo "\nSQL=$sql";
		}else{
			$this->MyOrder->query($sql);
		}
	}

	function chargeCard($workload) {
		App::import('Component', 'LogTypeEnum');
		App::import('Component', 'MerchantPartners');

		$billing_address = array($workload->MyOrder->billing_address1, $workload->MyOrder->billing_address2, $workload->MyOrder->billing_city, $workload->MyOrder->billing_state, $workload->MyOrder->billing_zip);
		$shipping_address = array($workload->MyOrder->shipping_address1, $workload->MyOrder->shipping_address2, $workload->MyOrder->shipping_city, $workload->MyOrder->shipping_state, $workload->MyOrder->shipping_zip);

		if($billing_address != $shipping_address && strtolower($workload->MyOrder->source) == 'simple') {
			return array('card_charged' => false, 'card_error' => 'Billing Shipping does not match!');
		}

		if (strtolower($workload->MyOrder->payment_type) == "credit card" && !empty($workload->MyOrder->mp_auth_code) && strpos($workload->MyOrder->mp_approval_number, 'AVSAUTH') === 0 && $workload->MyOrder->total <= $GLOBALS['_Settings']['automate_simple_cc_order_min_amount']) {
			$auth_arr = explode(":", $workload->MyOrder->mp_auth_code);
			$keys = array_keys($auth_arr);
			if (trim($auth_arr[count($keys) - 3]) == "Y") {
				if (empty($this->debug)) {
					$this->MerchantPartners = new MerchantPartnersComponent();
					$this->MerchantPartners->startup($this->Controller);
					$resp = $this->MerchantPartners->postCard($workload->MyOrder->mp_history_id, $workload->MyOrder->total, $workload->MyOrder->mp_order_id, $workload->MyOrder->id);
					if (@$resp['status'] == 'Approved') {
						//Automation Charge card log -start
						$logData = array(
							'order_id' => $workload->MyOrder->id,
							'current_value' => "Card Charged from Order Automation"
						);
						addOrderLog($logData,LogTypeEnumComponent::$OrderAutomationChargeCard);
						//Automation Charge card log -end
						//Save card details
						$save = array();
						$save['mp_approval_number'] = @$resp['authcode'];
						$save['mp_order_id'] = @$resp['orderid'];
						$save['mp_history_id'] = @$resp['historyid'];
						$save['mp_response'] = serialize(array('AUTH_ONLY' => @$resp));
						$save['status'] = 'Processed';
						$save['processed'] = date('Y-m-d H:i:s');

						$this->MyOrder->id = $workload->MyOrder->id;
						$this->MyOrder->save($save, false);
						return array('card_charged' => true);
					} else {
						return array('card_charged' => false, 'card_error' => 'Card Not Approved');
					}
				} else {
					echo "\n Charge Card and Set as Processed";
					return array('card_charged' => true);
				}
			} else {
				echo "\n Do not Charge Card";
				return array('card_charged' => false, 'card_error' => 'Card Error');
			}
		}
		echo "\n Order not eligible for charge card";
		return array('card_charged' => false);
	}

	function _getOrderAutomationLevel()
	{
		$res = $this->MyOrder->query("SELECT value from __settings WHERE name = 'order_automation_level'");
		return (!empty($res[0]['__settings']['value']) ? $res[0]['__settings']['value'] : 0);
	}

	function _isPickupGenerated($woi)
	{
		$res = $this->MyOrder->query("SELECT count(MDWO.id) AS n
		FROM my_distributors_warehouses_orders MDWO LEFT JOIN my_distributors_warehouses MDW ON (MDWO.warehouse_id = MDW.id AND MDW.last_pickup_date >= curdate())
		WHERE (length(confirmation_number) > 5 OR length(last_confirmation_number) > 5) AND MDWO.id = $woi");
		return !empty($res[0][0]['n']);
	}

	//pass order_id
	function isPayPalOrderCompleted_test() {
		$this->MyOrder->unbindAll();
		$order = $this->MyOrder->find('first',array('conditions' => array('MyOrder.id' => $this->args[0])));
		$order = json_encode($order);
		$order = json_decode($order);
		var_dump($this->_isPayPalOrderCompleted($order->MyOrder));
	}


	function _isPayPalOrderCompleted($order) {
		//order should be PAYPAL & must be a Fedex Ground Order
		if(strtolower($order->payment_type) == 'paypal' &&
			in_array(strtolower($order->shipping_option),array('fedex_ground','standard_shipping','ground_home_delivery'))) {

			//check for Fedex Daily warehouse
			/* replaced because automated_status = 4
			$wo = $this->MyOrder->query("SELECT IF(SUM(W.daily_pickup) = count(MDW.id),true,false) as daily_pickup FROM my_distributors_warehouses_orders MDW INNER JOIN my_distributors_warehouses W
    							ON (MDW.warehouse_id = W.id) WHERE MDW.my_order_id = $order->id GROUP BY MDW.my_order_id");
			$is_fedex_daily = (isset($wo[0][0]['daily_pickup']) && $wo[0][0]['daily_pickup'] == 1);
			*/

			//check for status
			$paypal = getModel('Paypal');
			$detailsArr = $paypal->getTransactionDetails($order->paypal_trans_id);
			$payment_completed = (!empty($detailsArr['PAYMENTSTATUS']) && strtolower($detailsArr['PAYMENTSTATUS']) == 'completed');

			// return true if it's a fedex daily & completed
			//return ($is_fedex_daily && $payment_completed);
			return $payment_completed;
		}
		return false;
	}


	function _checkDBConn($model) {
		if (!mysql_ping($this->$model->getDatasource()->connection)) {
			$this->$model->getDatasource()->disconnect();
			$this->$model->getDatasource()->connect();
			$this->$model = getModel($model);
		}
	}

	// SIM-3286 Starts
	function startOrderReprocessing(){
		echo "Starting Order ReProcess for the orders whose labels have not been downloaded within 48 business hours  @ ".$this->curDateTime()."\n";
		//declaring $business_hours_details here as using it multiple times
		//As per the new SRS, Business hours are 8AM to 5PM EST ! that is 1PM to 10PM UTC,
		$business_hours_details = array(
            							"start"=>array("hour_offset"=>13,"min_offset"=>00),
            							"end"=>array("hour_offset"=>22,"min_offset"=>00)
            						);
		$remainder_email_gap = 12 ;
        $action_required_orders = $this->findOrdersForReorocess($business_hours_details);

        if($action_required_orders){
            foreach ($action_required_orders  as $order_data) {
            	echo "\nChecking for Order ID ".$order_data["order_id"];

                if($this->isSupplierAvaiableForThisOrder($order_data["order_id"])){
                    $this->cancelCurrentSupplier($order_data["id"], $order_data["order_id"]);
                }
                else{
                	$lastRemainderEmailSendCheck = $this->lastReminderEmailSendOn($order_data["id"]);
                	if(!$lastRemainderEmailSendCheck){
                		$this->sendRemainderWarehouseEmailAutomation($order_data["id"]);
                	}else{
                		// Reminder email must be sent once in $remainder_email_gap. that is 12 business hour currently .
                		$delta_hr_ex_weekends = $this->deltaHoursExcludingWeekends($lastRemainderEmailSendCheck,$this->curDateTime(),$business_hours_details) ;
                		if($delta_hr_ex_weekends && ($delta_hr_ex_weekends > $remainder_email_gap) ){
                			$this->sendRemainderWarehouseEmailAutomation($order_data["id"]);
                		}
                	}

                }
            }
        }
    }

 	/**
	 * Function name :  lastReminderEmailSendOn
	 *
	 * Find the last reminder email sent to particular warehouse for particular Order ID
	 *
	 *
	 * @param int $order_id
	 * @return string date of last reminder email sent. false if not sent
	 */
    function lastReminderEmailSendOn($order_id){
    	App::import('Component', 'LogTypeEnum');
    	$proper_log_type_id = LogTypeEnumComponent::$ResendWarehouseEmail ;
		$sql = "SELECT  created FROM my_order_history_logs where order_id = $order_id and log_type_id = $proper_log_type_id order by id desc limit 1 ";
        $lastEmailSendOn = $this->MyOrder->query($sql, false);
        if(count($lastEmailSendOn)>0){
        	return $lastEmailSendOn[0]["my_order_history_logs"]["created"];
        }else{
        	return false ;
        }
    }

	function isSupplierAvaiableForThisOrder($my_order_id){
		$this->_checkDBConn('MyOrder');
		App::import('Core', 'Controller');
		App::import('Component', 'MyDistributor');
		App::import('Component', 'Email');
		App::import('Component', 'LogTypeEnum');
		App::import('Core', 'HttpSocket');
		$Zip = getModel('Zip');
		$sql = 'SELECT
					`my_distributors_warehouses_orders`.`id`,
					`my_distributors_warehouses_orders`.`automated_at`,
					`my_distributors_warehouses_orders`.`automated_status`,
					`my_distributors_warehouses_orders`.`warehouse_id`,
					`my_distributors_warehouses_orders`.`return_status`,
					`my_distributors_warehouses_orders_products`.`id`,
					`my_distributors_warehouses_orders_products`.`my_distributors_warehouses_order_id`,
					`my_distributors_warehouses_orders_products`.`quantity`,
					`my_distributors_warehouses_orders_products`.`cost`,
					`my_distributors_warehouses_orders_products`.`warehouse_part_num`,
					`my_distributors_warehouses`.`name`,
					`my_distributors_warehouses`.`label_format`,
					`my_order_products`.`my_product_id`,
					`my_order_products`.`my_product_name`,
					`my_order_products`.`price`,
					`my_order_products`.`add_road_hazard`,
					`my_order_products`.`road_hazard_amount`,
					`my_products`.`quick_search`,
					`my_products`.`part_number`,
					`my_products`.`weight`,
					`my_products`.`dim_height`,
					`my_products`.`dim_width`,
					`my_products`.`width_int`,
					`my_products`.`special_tax_fet`,
					`my_product_sub_types`.`name`
				FROM
					`my_distributors_warehouses_orders_products`
						INNER JOIN
					`my_order_products` ON `my_order_products`.`id` = `my_distributors_warehouses_orders_products`.`my_order_product_id`
						INNER JOIN
					`my_products` ON `my_products`.`id` = `my_order_products`.`my_product_id`
						LEFT JOIN
					`my_product_sub_types` ON `my_product_sub_types`.`id` = `my_products`.`product_sub_type_id`
						INNER JOIN
					`my_distributors_warehouses_orders` ON `my_distributors_warehouses_orders_products`.`my_distributors_warehouses_order_id` = `my_distributors_warehouses_orders`.`id`
						INNER JOIN
					`my_distributors_warehouses` ON `my_distributors_warehouses`.`id` = `my_distributors_warehouses_orders`.`warehouse_id`
				WHERE
					`my_distributors_warehouses_order_id` IN (SELECT
							my_distributors_warehouses_orders.id
						FROM
							my_distributors_warehouses_orders
							INNER JOIN my_orders ON (my_orders.id = my_distributors_warehouses_orders.my_order_id)
						WHERE
							my_order_id = '.$my_order_id.'   AND
							(CASE WHEN (my_orders.status="REPROCESS")
								THEN my_distributors_warehouses_orders.status="PENDING"
								ELSE TRUE
							END)
							)';

 		if($this->debug) {
				echo "\nSQL=$sql";
		}
		$warehouse_orders = $this->MyOrder->query($sql, false);
		$supplier_found = true;
		foreach($warehouse_orders as $op) {
			$latitude = 39.50;
			$longitude = -98.35;
			$zip = $this->Zip->query("SELECT longitude, latitude FROM zips WHERE zip = '".$this->shippingzipByOrderid($my_order_id)."'", false);
			if(!empty($zip)) {
				$latitude = $zip[0]['zips']['latitude'];
				$longitude = $zip[0]['zips']['longitude'];
			}
			$max_allowed_cost = $op['my_order_products']['price'] * 1.30;
			$extraJoin = "";
			$warehouse_conditions = "my_distributors_warehouses_products.product_id='".$op['my_order_products']['my_product_id']."'
									 AND my_distributors_warehouses_products.quantity >= '".$op['my_distributors_warehouses_orders_products']['quantity']."'
									 AND my_distributors_warehouses_products.price BETWEEN .01 AND '".$max_allowed_cost."'";
			if($workload->MyOrder->source == 'WalMart') {
				$extraJoin = "INNER JOIN wholesale_warehouses WW ON WW.warehouse_id = my_distributors_warehouses.id AND WW.wholesale_id = 45";
			}
			$warehouse_conditions .= ' AND my_distributors_warehouses.inventory_set_id = 1';

			//Check if any warehouses selected previously and skips those
			$hasPreviousAssignment = false;
			$whSql = "SELECT DISTINCT warehouse_id FROM my_order_history_logs WHERE order_id = ".$my_order_id." AND log_type_id IN (".LogTypeEnumComponent::$WarehouseChanged.",".LogTypeEnumComponent::$SendWarehouseEmail.") AND warehouse_id IS NOT NULL AND warehouse_id != 685";
			if($this->debug) {
				echo "\n$whSql";
			}
			$previousWarehouses = $this->MyDistributorsWarehousesProduct->query($whSql, false);
			if(!empty($previousWarehouses)){
				$hasPreviousAssignment = true;
				$prevWhs = array();
				foreach ($previousWarehouses as $wh){
					$prevWhs[] = $wh['my_order_history_logs']['warehouse_id'];
				}
				if(!empty($prevWhs)){
					$warehouse_conditions .= ' AND my_distributors_warehouses.id NOT IN ('.implode(",",$prevWhs).')';
				}
			}

			$sql = "SELECT
				my_distributors_warehouses_products.warehouse_id,
				my_distributors_warehouses_products.product_id,
				my_distributors_warehouses_products.price,
				my_distributors_warehouses_products.warehouse_part_num,
				my_distributors_warehouses_products.source_item_desc,
				my_distributors_warehouses.name,
				my_distributors_warehouses.zip,
				my_distributors_warehouses.local_delivery,
				my_distributors_warehouses.install_price_per_tire,
				my_distributors_warehouses.daily_pickup,
				my_distributors_warehouses.ship_carrier,
				my_distributors_warehouses.pickup_time,
				my_distributors_warehouses.disable_order_automation,
				my_distributors_warehouses.tire_binding,
				CEILING((sqrt(power(69.1*(my_distributors_warehouses.latitude - $latitude ),2)+ power(69.1*(my_distributors_warehouses.longitude- $longitude )*cos(my_distributors_warehouses.latitude/57.3),2))/100))*100 AS distance
			FROM
				my_distributors_warehouses_products
				INNER JOIN
					my_distributors_warehouses ON my_distributors_warehouses.id = my_distributors_warehouses_products.warehouse_id
				" . $extraJoin . "
			WHERE
				".$warehouse_conditions."
			ORDER BY
				my_distributors_warehouses_products.price ASC, distance ASC, RAND()";

			if($this->debug) {
				echo "\nSQL=$sql";
			}

			$products = $this->MyDistributorsWarehousesProduct->query($sql, false);

			$num_total = count($products);
			echo "\n	 |- Found ".$num_total." warehouses for ReProcess.";
			if($num_total != 0 ){ // Checking for all products in a order. All product must be available
				$supplier_found = $supplier_found * true;
			}else{
				$supplier_found = $supplier_found * false;
			}
		}
		return $supplier_found ;
	}

    function shippingzipByOrderid($id){
        $sql = "SELECT shipping_zip FROM my_orders WHERE  id = $id";
        $orders = $this->MyOrder->query($sql, false);
        return  $orders[0]["my_orders"]["shipping_zip"];
    }

    function cancelCurrentSupplier($warehouse_order_id, $o_id, $reason_id = 8) {
    	// Cancel Email Template can be sent here
		$email_status = $this->sendCancelWarehouseEmailAutomation($warehouse_order_id);

        // Add to Order History Log before updating so that we can get the last Warehouse Name
      	$log_result = $this->setReProcessedStatusLogSystem($o_id,$warehouse_order_id,$reason_id);

      	if($log_result){
      		echo "\n	 |- Logged Warehouse change details.";
      	}

        $this->MyDistributorsWarehousesOrder->id = $warehouse_order_id;
        $mdwo_dump_result = array(
            'warehouse_id' => 685,
            'shipped' => 0,
            'fulfill_picked_at' => null,
            'fulfill_rejected_at' => $this->curDateTime(),
            'fulfill_downloaded_at' => null,
            'warehouse_delivers' => null,
            'warehouse_delivers_confirmed' => null,
            'status' => 'Pending',
            'ship_date' => null,
			'automated_at' => null,
			'automated_status' => null
        );

        if($this->debug) {
			echo "\nUpdate= $mdwo_dump_result";
		}else{
			$this->MyDistributorsWarehousesOrder->save($mdwo_dump_result);
       		$this->MyOrderHistoryLog->deleteAll(array("MyOrderHistoryLog.my_distributors_warehouses_order_id = $warehouse_order_id AND MyOrderHistoryLog.log_type_id=38"),false);
		}

  		$mdwo_dump_result = "UPDATE my_orders SET automated_at=NULL, automated_started=NULL, status = 'ReProcess' WHERE id = '".$o_id."'";

        if($this->debug) {
			echo "\nUpdate= $mdwo_dump_result";
		}else{
			$this->MyOrder->query($mdwo_dump_result);
        	echo "\n	 |- Set Order for Reprocessing.";
		}

		return true;
    }

    function setReProcessedStatusLogSystem($order_id,$warehouse_order_id,$reason_id) {
     	//Fetch previous Warehouse Name
        $this->MyDistributorsWarehousesOrder->recursive = -1;
        $order = $this->MyDistributorsWarehousesOrder->find('first',
            array(
                'joins' => array(
                    array(
                        'table' => 'my_distributors_warehouses',
                        'alias' => 'MyDistributorsWarehouse',
                        'type' => 'INNER',
                        'conditions' => array(
                            'MyDistributorsWarehousesOrder.warehouse_id = MyDistributorsWarehouse.id'
                        )
                    )
                ),
                'conditions' => array(
                    'MyDistributorsWarehousesOrder.id' => $warehouse_order_id
                ),
                'fields' => array("MyDistributorsWarehouse.id","MyDistributorsWarehouse.name")
            )
        );

        $log_array = array(
            'order_id' => $order_id,
            'my_distributors_warehouses_order_id' => $warehouse_order_id,
            'log_type_id' => 39 ,
            'warehouse_id' => $order['MyDistributorsWarehouse']['id'],
            'original_value' => $order['MyDistributorsWarehouse']['name'],
            'current_value' => "SimpleTire",
            'created' => $this->curDateTime(),
            'created_by' => 0,
            'created_by_user' => "system",
            'ref_table' => "my_order_cannot_ship_reasons",
            'ref_id' => $reason_id
        );

        if($this->debug) {
			echo "\nUpdate= $log_array ";
		}else{
			$this->MyOrderHistoryLog->create();
        	$this->MyOrderHistoryLog->save($log_array);
		}

        return true;
    }

    /*
    	We are excluding order reprocessing for Horizon Tire (as per SIM-3286)
 		Horizon tires distributor id : 114
 		if in future,
 			1)this exlusion needs to removed, just make , $excluding_distrubutores_ids = false ;
 			2)this exlusion needs to expanded for more distributorers , just add it's id  like, $excluding_distrubutores_ids = "114,115" ;
    */
	function findOrdersForReorocess($business_hours_details) {
			$excluding_distrubutores_ids = "114" ;
            $excluding_wh_ids = $this->warehouseIdsByDistributorIds($excluding_distrubutores_ids) ;
            if($excluding_wh_ids){
            	$imploded_ids = implode(', ', $excluding_wh_ids);
          		$excluding_wh_ids_cond = " mdwo.warehouse_id not in ( $imploded_ids  )";
            }else{
            	$excluding_wh_ids_cond = " 1 " ;
            }
            $label_not_downloaded_since_hr = 48 ;

            $current_time = $this->curDateTime();

            $excluding_source = "'WalMartACC'";

            $final_data = array();
         	$sql = "SELECT
                        mdwo.id,
                        mdwo.warehouse_id,
                        mdwo.my_order_id,
                        IF(mdwo.fulfill_assigned_at IS NOT NULL AND mdwo.fulfill_assigned_at > mdwo.automated_at, mdwo.fulfill_assigned_at, mdwo.automated_at) AS automated_at
                    FROM
                        my_distributors_warehouses_orders mdwo
                        INNER JOIN my_orders MO ON (MO.id = mdwo.my_order_id)
                    WHERE
                        	$excluding_wh_ids_cond
                        	AND MO.status IN  ('Processed','ReProcess')
                            AND mdwo.automated_at IS NOT NULL
                            AND mdwo.delivered != 1
                            AND mdwo.warehouse_id != 685
                            AND mdwo.shipped != 1
                            AND mdwo.fulfill_downloaded_at IS NULL
                            AND mdwo.automated_at < NOW()
                            AND MO.source not in ( $excluding_source )
                            AND IF(mdwo.fulfill_assigned_at IS NOT NULL AND mdwo.fulfill_assigned_at > mdwo.automated_at, HOUR(TIMEDIFF(NOW(), mdwo.fulfill_assigned_at)) > $label_not_downloaded_since_hr, HOUR(TIMEDIFF(NOW(), mdwo.automated_at)) > $label_not_downloaded_since_hr)
                    ORDER BY automated_at ASC";

            if($this->debug) {
                echo "\nSQL=$sql" . "\n";
            }

	        $orders = $this->MyOrder->query($sql, false);

	       	echo "\nFound ".count($orders)." orders to reprocess excluding weekend and business hours !\n";

            foreach($orders as $key => $c_order) {
                $c_my_dist_wh_id = $c_order["mdwo"]["id"];
                $c_wh_id = $c_order["mdwo"]["warehouse_id"];
                $c_order_id = $c_order["mdwo"]["my_order_id"];
                $c_automated_at = $c_order[0]["automated_at"];

                // Can do this using DB query as well, but sometimes it is not working properly when starting day is weekend day.
                $delta_hr_ex_weekends = $this->deltaHoursExcludingWeekends($c_automated_at,$current_time,$business_hours_details) ;
                if(isset($delta_hr_ex_weekends) && ($delta_hr_ex_weekends >= $label_not_downloaded_since_hr)){
                    $reproces_this_order = array("id"=> $c_my_dist_wh_id , "wh_id" =>$c_wh_id  ,"order_id" => $c_order_id , "delta_hr" =>  $delta_hr_ex_weekends);
                    array_push($final_data, $reproces_this_order);
                }
            }

        if(count($final_data) > 0){
        	echo "\nFound ".count($final_data)." orders to reprocess!\n";
            return $final_data;
        }else{
         	echo "\nNo orders to reprocess!\n";
            return false ;
        }
    }


    /**
	 * Function name :  warehouseIdsByDistributorIds
	 *
	 * Find the all warehouse id by distributor id
	 *
	 *
	 * @param int $distributor_ids
	 * @return array  list of warehouse ids
	 */
    function warehouseIdsByDistributorIds($distributor_ids)
    {
    	if(!$distributor_ids){
    		return false;
    	}
    	$sql = "SELECT id FROM my_distributors_warehouses WHERE  distributor_id  in ( $distributor_ids ) ";
        $warehouse_ids = $this->MyOrder->query($sql, false);
        $all_warehouse_ids_final = array();
      	if(count($warehouse_ids)>0){
      		foreach ($warehouse_ids as $c_wh_data) {
      			array_push($all_warehouse_ids_final, $c_wh_data["my_distributors_warehouses"]["id"]+0 ); //Type Juggling
      		}
      		return  $all_warehouse_ids_final ;
      	}else{
      		return false;
      	}
    }

    function curDateTime(){
        return date('Y-m-d H:i:s');
    }


	function deltaHoursExcludingWeekends($start, $end, $business_hours_details){

		if(strtotime($start) >= strtotime($end)) {
			return false ;
		}

	    $startDate = new DateTime($start);
	    $endDate = new DateTime($end);
	    $periodInterval = new DateInterval( "PT1H" );

	    $period = new DatePeriod( $startDate, $periodInterval, $endDate );
	    $count = 0;

	    foreach($period as $date){

		    $startofday = clone $date;
		    $startofday->setTime($business_hours_details["start"]["hour_offset"],$business_hours_details["start"]["min_offset"]);

		    $endofday = clone $date;
		    $endofday->setTime($business_hours_details["end"]["hour_offset"],$business_hours_details["end"]["min_offset"]);

		        if($date > $startofday && $date <= $endofday && !in_array($date->format('l'), array('Sunday','Saturday'))){
		            $count++;
		        }

	    }

	    return $count;
	}




	function sendRemainderWarehouseEmailAutomation($warehouse_order_id) {
		echo "\n	 |- Sending Remainder Email to warehouse for not processing order since 48 business hours.";

		App::import('Core', 'Controller');
		App::import('Component', 'Email');
		App::import('Component', 'MyDistributor');
		App::import('Component', 'LogTypeEnum');
		App::import('Core', 'HttpSocket');

		$this->Controller = new Controller();
		$this->MyDistributor = new MyDistributorComponent();
		$this->Email = new EmailComponent();
		$this->Email->startup($this->Controller);
		$EmailObj = $this->Email ;

        $this->autoRender = false;
        $res = $this->MyDistributor->sendReminderWarehouseEmailAutomation($warehouse_order_id,$EmailObj);

        if($res['success']) {
            if(!empty($res['log_data'])) {
                addOrderLog($res['log_data'],LogTypeEnumComponent::$ResendWarehouseEmail);
                $to_return = "\n	 |- Remainder email sent to Warehouse.";
            }
        } else {
            $to_return =  "\n	 |- Cant send email. Something went wrong.";
        }
        echo $to_return."\n";
    }

	function sendCancelWarehouseEmailAutomation($warehouse_order_id) {
		echo "\n	 |- Sending Cancel Email to warehouse for not processing order since 48 business hours.";

		App::import('Core', 'Controller');
		App::import('Component', 'Email');
		App::import('Component', 'MyDistributor');
		App::import('Component', 'LogTypeEnum');
		App::import('Core', 'HttpSocket');

		$this->Controller = new Controller();
		$this->MyDistributor = new MyDistributorComponent();
		$this->Email = new EmailComponent();
		$this->Email->startup($this->Controller);
		$EmailObj = $this->Email;

        $this->autoRender = false;
        $res = $this->MyDistributor->sendCanceledWarehouseEmailAutomation($warehouse_order_id,$EmailObj);

        if($res['success']) {
            if(!empty($res['log_data'])) {
                addOrderLog($res['log_data'],LogTypeEnumComponent::$LabelsNotDownloadedReprocess);
                $to_return =  "\n	 |- Cancel email sent to Warehouse.";
            }
        } else {
            $to_return =  "\n	 |- Cant send cancel email. Something went wrong.";
        }
        echo $to_return."\n";
    }
    // SIM-3286 Ends



    function test_update_supplier_qty() {
        if(empty($this->params['oid'])) die('Requires oid parameter.');
        $this->_update_supplier_qty($this->params['oid']);
    }

    function _update_supplier_qty($order_id = null, $as_of_date = null) {
        if(empty($order_id) || empty($as_of_date)) return false;
        $gmc = new GearmanClient();
        $gmc->addServer();

        echo "\n + _update_supplier_qty @ ".date("Y-m-d H:i:s");

        $sql = "SELECT
                    my_order_products.my_order_id,
                    my_order_products.my_product_id,
                    my_distributors_warehouses_orders.warehouse_id,
                    my_distributors_warehouses_orders_products.quantity,
                    my_distributors_warehouses_products.quantity AS supplier_qty
                FROM
                    my_order_products
                        INNER JOIN
                    my_orders ON my_order_products.my_order_id = my_orders.id
                        INNER JOIN
                    my_distributors_warehouses_orders_products ON my_order_products.id = my_distributors_warehouses_orders_products.my_order_product_id
                        INNER JOIN
                    my_distributors_warehouses_orders ON my_distributors_warehouses_orders_products.my_distributors_warehouses_order_id = my_distributors_warehouses_orders.id
                        INNER JOIN
                    my_distributors_warehouses_products ON my_distributors_warehouses_products.product_id = my_order_products.my_product_id
                        AND my_distributors_warehouses_orders.warehouse_id = my_distributors_warehouses_products.warehouse_id
                WHERE
                    my_orders.id = ". $order_id;
        $items = $this->MyProduct->query($sql, false);
        echo "\n    | Found ".count($items)." products to update.";
        foreach($items as $i) {
            echo "\n    | Order ID ".$i['my_order_products']['my_order_id']." @ ".$as_of_date." PID=".$i['my_order_products']['my_product_id']." (".$i['my_distributors_warehouses_orders_products']['quantity']." of ".$i['my_distributors_warehouses_products']['supplier_qty'].")";
            $new_quantity = $i['my_distributors_warehouses_products']['supplier_qty'] - $i['my_distributors_warehouses_orders_products']['quantity'];
            if($new_quantity < 0) $new_quantity = 0;
            $sql = "UPDATE
                        my_distributors_warehouses_products
                     SET quantity='$new_quantity',
                         modified=NOW()
                    WHERE
                        product_id = '".$i['my_order_products']['my_product_id']."' AND
                        warehouse_id = '".$i['my_distributors_warehouses_orders']['warehouse_id']."' AND
                        '".$as_of_date."' > modified";
            if(empty($this->debug)) {
            	$this->MyProduct->query($sql);
            	$aff = $this->MyProduct->query('SELECT ROW_COUNT()', false);
            	echo "\n    \  Updated qty of " . $aff[0][0]['ROW_COUNT()'] . " records\n";

	            if($new_quantity <= $this->minPricingQty) {
	                $gmc->doBackground("set_pricing", json_encode(array('p'=>$i['my_order_products']['my_product_id'])));
	            }
            } else {
            	echo "\n    \  DEBUG: Set qty = $new_quantity";
            }
        }
    }

}
