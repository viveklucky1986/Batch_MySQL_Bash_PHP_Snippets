### CakePHP 3.x Install Command ###
```cmd
composer self-update && composer create-project --prefer-dist cakephp/app [CakePHP_App_Dir]
composer self-update & composer create-project --prefer-dist cakephp/app [CakePHP_App_Dir]
composer self-update & composer create-project --prefer-dist cakephp/app cakephp35_prac
```

### CakePHP 3.x Server Start ###
```cmd
bin\cake server
bin\cake server -H [HostIP] -p [Port]
bin\cake server -H 192.168.13.37 -p 5673
```
```bash
bin/cake server
bin/cake server -H [HostIP] -p [Port]
bin/cake server -H 192.168.13.37 -p 5673
```

### CakePHP 3.x Server Start Batch Script ([CakephpRoot]\startServer.cmd) ###
```cmd
@echo off
set ScriptPath=%0
set ScriptDir=%~dp0
set ScriptName=%~nx0
set ScriptShortPath=%~s0
set ScriptDirShortPath=%ScriptShortPath:~0,-13%
set ScriptPathFull=%~0\..
echo %ScriptPathFull%
echo %ScriptShortPath%
echo %ScriptDirShortPath%
cd %ScriptPathFull%
bin\cake server
rem %ScriptDir%\bin\cake server
pause > nul
```
```bat
@echo off
set ScriptPath=%0
set ScriptDir=%~dp0
set ScriptName=%~nx0
set ScriptShortPath=%~s0
set ScriptDirShortPath=%ScriptShortPath:~0,-13%
set ScriptPathFull=%~0\..
echo %ScriptPathFull%
echo %ScriptShortPath%
echo %ScriptDirShortPath%
cd %ScriptPathFull%
bin\cake server
rem %ScriptDir%\bin\cake server
pause > nul
```
