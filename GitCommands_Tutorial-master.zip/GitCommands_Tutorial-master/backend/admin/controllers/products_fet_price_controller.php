<?php
class ProductsFetPriceController extends AppController {
    var $name = 'ProductsFetPrice';
    var $components = array();
    var $uses = array('MyProduct');
    var $helpers = array('Html', 'Form', 'Javascript', 'Csv');
    var $nav = 'my_products';

    public function update() {
        $this->data = $_FILES;
        if (is_uploaded_file($this->data['csvUpload']['tmp_name']) && 
            ($productsFetPriceFile = fopen($this->data['csvUpload']['tmp_name'], 'r')) !== false) {

            Configure::write('debug', 0);
            $this->autoRender = false;

            $myProduct = getModel('MyProduct');
            $sizeLoadRangeCombos = $myProduct->query("SELECT CONCAT(products_load_range_id,',',quick_search) AS size_load_range_pair FROM my_products WHERE COALESCE(products_load_range_id, 0) > 0 AND COALESCE(quick_search, 0) > 0 AND COALESCE(special_tax_fet, 0) > 0 GROUP BY products_load_range_id, quick_search;");

            $wrongFetPricesDest = $wrongFetPrices = array();
            foreach ($sizeLoadRangeCombos as $sizeLoadRangeCombo) {
                $comboPair = $sizeLoadRangeCombo[0]['size_load_range_pair'];
                $comboProductsQry = "SELECT
                                            id,
                                            part_number,
                                            modified,
                                            modified_by,
                                            qty_available,
                                            web_price,
                                            special_tax_fet,
                                            quick_search,
                                            products_load_range_id
                                        FROM
                                            my_products
                                        WHERE
                                            qty_available > 0
                                            AND web_price > 0
                                            AND special_tax_fet > 0
                                            AND products_load_range_id IN ($comboPair)
                                            AND quick_search IN ($comboPair)
                                            AND deleted IS NULL
                                            ;";
                $wrongFetPrices = $myProduct->query($comboProductsQry);
                if (!empty($wrongFetPrices)) {
                    foreach ($wrongFetPrices as $wrongFetPrice) {
                        $sizeLoadRangePair = $comboPair;
                        $specialTaxFet = $wrongFetPrice['my_products']['special_tax_fet'];
                        $wrongFetPricesDest[] = array(
                                                    'id' => $wrongFetPrice['my_products']['id'],
                                                    'part_number' => $wrongFetPrice['my_products']['part_number'],
                                                    'sizeLoadRangePair' => $sizeLoadRangePair,
                                                    'specialTaxFet' => $specialTaxFet
                                                );
                    }
                }
            }
            foreach ($sizeLoadRangeCombos as $sizeLoadRangeCombo) {
                $comboPair = $sizeLoadRangeCombo[0]['size_load_range_pair'];
                $countOfComboPair = countValueFrequencyInArray($wrongFetPricesDest, $comboPair);
                if ($countOfComboPair > 1) {
                    $specialTaxFet = searchInCsv($productsFetPriceFile, $comboPair);
                    // Run the update query now...
                    $comboPair = trim($comboPair, '"');
                    $myProduct->query("UPDATE `my_products` SET `special_tax_fet` = $specialTaxFet WHERE `products_load_range_id` IN ($comboPair) AND `quick_search` IN ($comboPair);");
                }
            }
            $this->Session->setFlash('Fet prices updated for the specified Size and Load Range pairs');
            $this->redirect($this->here);
        }
    }

    /**
     * Csv download action
     */
    public function export_invalid_fetprice_sets() {
        Configure::write('debug', 0);
        $this->autoRender = true;
        $myProduct = getModel('MyProduct');
        $fetPriceSets = $myProduct->query("SELECT CONCAT(products_load_range_id,',',quick_search) AS size_load_range_combo, special_tax_fet FROM my_products WHERE (special_tax_fet IS NULL OR special_tax_fet = 0 OR special_tax_fet = '') AND (products_load_range_id IS NOT NULL AND quick_search IS NOT NULL) GROUP BY products_load_range_id, quick_search;");
        $iterator = 0;
        $csvDataSet = array();
        foreach ($fetPriceSets as $fetPriceSet) {
            $csvDataSet[$iterator]['size_load_range_combo'] = $fetPriceSet[0]['size_load_range_combo'];
            $csvDataSet[$iterator]['special_tax_fet'] = $fetPriceSet['my_products']['special_tax_fet'];
            $iterator++;
        }
        $this->set('csvDataSet', $csvDataSet);
    }
}
