#!/bin/bash
SourceFile="$1"
FinalFile="$2"

StartLineNo=891
GapBetSrcTrg=4
FinishLineNo=3367
Interval=20

let LineNo=TargetLineNo=DataType=0
while IFS='' read -r line || [[ -n "$line" ]]; do
    LineNo=$(($LineNo + 1))
    if [[ $LineNo -ge $StartLineNo ]]; then
        if [[ "$line" =~ "@param" ]]; then
            DataType=$(echo "$line" | sed 's/[@$][^ ]*//g' | sed "s/ //g" | sed 's/[*]\+//g')
            TargetLineNo=$(($LineNo + $GapBetSrcTrg))
        fi
        if [[ ! "$line" =~ "($DataType)" ]] && [[ $LineNo -eq $TargetLineNo ]] && [[ ! "$line" =~ "if" ]]
        then
            line=$(echo "$line" | sed "s/=/= ($DataType)/g")
            echo "$line"
        fi
    fi
    echo "$line" >> "$FinalFile"
done < "$SourceFile"