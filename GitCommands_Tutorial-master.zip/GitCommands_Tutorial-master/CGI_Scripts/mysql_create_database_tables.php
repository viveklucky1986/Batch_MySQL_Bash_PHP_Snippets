<?php
# Execute this script only once
try {
    if ( $db->connect_errno ) throw new Exception("Connection Failed: ".$db->connect_error);
    $db = new mysqli('localhost','root','[PasswordText]','mysql');
    # $resource = $db->query("CREATE DATABASE `playground` CHARACTER SET utf8 COLLATE utf8_general_ci;");
    $resource = $db->query("CREATE DATABASE `Playground` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
    $resource = $db->select_db("Playground");
    $createTableSql = "CREATE TABLE Users (
                        user_id INT(7) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                        firstname VARCHAR(128) NOT NULL,
                        lastname VARCHAR(128) NOT NULL,
                        username VARCHAR(128) NOT NULL,
                        password VARCHAR(256) NOT NULL,
                        email VARCHAR(192) NOT NULL,
                        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                    )";
    $resource = $db->query($createTableSql);
    if ( !$resource ) throw new Exception($db->error);
    $resource->free();
    $db->close();
} catch (Exception $e) {
    echo "DB Exception: ",$e->getMessage(),"\n";
}

https://uploadbuzz.net/rxnvi2455oei
https://douploads.com/rplvivdqg99k
