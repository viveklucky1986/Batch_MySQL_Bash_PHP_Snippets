<?php
echo @mysql_ping() ? 'true' : 'false';
exit();
?>