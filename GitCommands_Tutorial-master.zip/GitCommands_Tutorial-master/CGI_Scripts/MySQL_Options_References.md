https://dev.mysql.com/doc/refman/5.7/en/repair-table-optimization.html  
https://dev.mysql.com/doc/mysql-installation-excerpt/5.5/en/mysql-config-wizard.html  
https://dev.mysql.com/doc/refman/5.7/en/option-files.html

### Commands & Queries that might be needed to run when installing and starting MySQL Services ###
```cmd
cd "C:\Program Files (x86)\MySQL\MySQL Server 5.6\bin"
cd "C:\Progra~2\MySQL\MySQLS~1\bin"
mysqld --install "SkylarkMySQL" --defaults-file="C:\\Webroot\\Server_Configs\\my.cnf" --init-file="C:\\Webroot\\Server_Configs\\my-init.sql"
mysqld --install "SkylarkMySQL" --defaults-file="C:\\Webroot\\Server_Configs\\my.cnf"
"C:\Program Files (x86)\MySQL\MySQL Server 5.6\bin\mysqld.exe" --install "SkylarkMySQL" --defaults-file="C:\\Webroot\\Server_Configs\\my.cnf" --init-file="C:\\Webroot\\Server_Configs\\my-init.sql"
"C:\Program Files (x86)\MySQL\MySQL Server 5.6\bin\mysqld.exe" --start "SkylarkMySQL"
net start SkylarkMySQL
net stop SkylarkMySQL
sc start SkylarkMySQL
sc stop SkylarkMySQL
sc delete SkylarkMySQL
mysqld --init-file="C:\\Webroot\\Server_Configs\\my-init.sql"

"C:\Program Files (x86)\MySQL\MySQL Server 5.6\bin\mysql.exe" "--defaults-file=C:\\Webroot\\Server_Configs\\my.cnf" "-uroot" "-p"
```

```sql
SHOW DATABASES;
SELECT User, Host, Password FROM mysql.user;
DELETE FROM mysql.user WHERE Password=''; FLUSH PRIVILEGES;
```

```bat
Win + R
cmd /c for %A in ("C:\Documents and Settings\User\NTUSER.DAT") do @echo %~sA | clip
cmd /c for %A in ("C:\Program Files (x86)\MySQL\MySQL Server 5.6\data") do @echo %~sA | clip
cmd /c for %A in ("C:\Program Files (x86)\MySQL\MySQL Server 5.6\bin") do @echo %~sA | clip
cmd /k for %A in ("C:\Program Files (x86)\MySQL\MySQL Server 5.6\data") do @echo %~sA
cmd /k for %A in ("C:\Program Files (x86)\MySQL\MySQL Server 5.6\bin") do @echo %~sA
```
