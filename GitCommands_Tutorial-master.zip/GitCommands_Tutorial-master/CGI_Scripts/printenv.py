#!C:\Python27\python.exe
#!/Python27/python

import os
print "Content-Type: text/plain\n\n"
for key in os.environ.keys():
	print "%30s %s \n" % (key,os.environ[key])

# Access the above script as - http://localhost:8080/cgi-bin/printenv.py