### Generate Entity for existing database table: ###
```bash
php bin/console generate:doctrine:form [FormName]
php bin/console generate:doctrine:form AcmeBlogBundle:Post
php bin/console doctrine:generate:entity
bin/console doctrine:generate:entity
```

### Get the table information and it's column count ###
```sql
USE [DatabaseName];
DESC [TableName];
SELECT count(*) FROM information_schema.columns WHERE table_name = '[TableName]';

USE rpm_simpletire;
DESC my_product_sub_types;
SELECT count(*) FROM information_schema.columns WHERE table_name = 'my_product_sub_types';

DESC `[DatabaseName]`.`[TableName]`;
DESC `rpm_simpletire`.`my_product_sub_types`;
SELECT count(*) FROM information_schema.columns WHERE table_name = '[TableName]' AND table_schema = '[DatabaseName]';
SELECT count(*) FROM information_schema.columns WHERE table_name = 'my_product_sub_types' AND table_schema = 'rpm_simpletire';
```
