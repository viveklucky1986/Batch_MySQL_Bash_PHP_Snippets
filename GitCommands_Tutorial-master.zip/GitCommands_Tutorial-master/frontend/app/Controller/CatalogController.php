<?php

    App::uses('AppController', 'Controller');
    App::import('Controller', 'MyCart');

    class CatalogController extends AppController {

        public $components = array(
            'Email',
            'Paginator'
        );
        public $uses = array(
            'MyProduct',
            'MyManufacturersProductsLine',
            'Tcspart',
            'MyManufacturersProductsLineCategory',
            'MyCategory',
            'Review',
            'ProductQuotes'
        );
        public $totalSearch = 0;
        public $paginate = array(
            'Review' => array(
                'limit' => 25,
                'order' => array('Review.created' => 'DESC')
            )
        );

        public $extra_filters = array('price');

        public $filters_available = array('brand',
            'line',
            'category',
            'promotion',
            'subtype',
            'warranty',
            'speedrating',
            'loadindex',
            'loadrange',
            'sidewall'
        );
        public $size_filters = array(
            'width',
            'ratio',
            'rim',
            'year',
            'make',
            'model',
            'option',
            'rwidth',
            'rratio',
            'rrim'
        );
        public $special_filters = array('quicksize','mph','search');
        private $debug = false;

        function index() {
            if(!empty($_GET['debug'])) {
                $this->debug = true;
                Configure::write('debug', 2);
            }
            if(!empty($_GET['debug_url'])) {
                $this->CustomHttpSocket = new HttpSocket();
                $this->API_URL = $_GET['debug_url'];
            }
            $this->helpers[] = 'ProductPage';
            $this->set("no_hr",1);
            $this->checkRedirection();
            $appender = NULL;
            if ($this->request->query('source') == 'localDeal') {
                $appender = array("sort" => 'shipping');
                $this->Session->write('CloseBanner', 1);
            }
            $this->__index($appender);
        }

        function checkRedirection() {
            if (!isset($GLOBALS['catalog_data'])) {
                $total_parameters = count($this->request->query);
                if ((isset($_GET['select']) && isset($_GET['page']) && $total_parameters == 2) || (isset($_GET['select']) && $total_parameters == 1) || (isset($_GET['page']) && $total_parameters == 1) || $total_parameters == 0) {
                    header('Location: /');
                    die;
                }
            }
        }

        function getOESizes() {
            $sizes = '';
            $catalog_data = $_GET;
            $catalog_data['id'] = 1; //this to fetch only size and avoid fetching all the records.
            $results = $this->CustomHttpSocket->get('http://' . $this->API_URL . '/catalog_data/0cfc3f81e47a6b6e06099cf890417d57', $catalog_data);
            $data = json_decode($results['body'], true);
            if(!empty($data['size'])) {
                $sizes = $data['size'];
            }
            return $sizes;
        }

        function oe_selection() {
            $sizes = $this->getOESizes();
            $year = str_replace(',', '', $_GET['year']);
            $this->set('vehicle_name', "{$year} {$_GET['make']} {$_GET['model']} {$_GET['option']}");
            $this->set('sizes', $sizes);
            if(isset($_GET['result_id']) && $_GET['result_id']!=0){
                $SeoRoute = getModel('SeoRoute');
                $url_slug = $SeoRoute->find('first', array('conditions' => array('route_url' => "/CatalogBrowse/results/".$_GET['result_id'])));
                $slug_url = $url_slug['SeoRoute']['url_slug']."?result_id=".$_GET['result_id'];
                if(isset($_GET['pagetype']) && $_GET['pagetype']!=""){ $slug_url .= "&pagetype=".$_GET['pagetype']; }
                $this->set('url_slug',$slug_url);
            }
        }

        function testemail() {
            $this->autoRender = false;
            Configure::write('debug', 3);
            $this->Email->subject = 'SimpleTire.com Email from your friend ';
            $this->Email->to = 'shah.abhishek.r@gmail.com';
            $this->Email->from = 'shah.abhishek.r@gmail.com';
            $this->Email->send('dfnowno');
        }


        function sendAQuoteEmail() {
            $this->autoRender = false;
            if(isset($_POST['email'])){

                $product = array(
                    'product_id' => $_POST['product_id'],
                    'product_img' => $_POST['product_img'],
                    'brand_logo' => $_POST['brand_logo'],
                    'product_name' => $_POST['product_name'],
                    'prodcut_url' => $_POST['prodcut_url'],
                    'prodcut_price' => $_POST['prodcut_price']
                );

                $save = array(
                    'product_id' => $_POST['product_id'],
                    'sent_at' => date("Y-m-d H:i:s"),
                    'sent_by' => $_SESSION['Auth']['User']['id'],
                    'customer_name' => @$_POST['name'],
                    'customer_email' => $_POST['email'],
                    'customer_phone' => @$_POST['phone']
                );

                $this->ProductQuotes->save($save);

                $this->EmailConfig = new EmailConfig();
                $this->Email->smtpOptions = $this->EmailConfig->send_grid;
                $this->Email->subject = 'Your SimpleTire Quote';
                $this->Email->to = $_POST['email'];
                $this->Email->from = 'SimpleTire Sales <quote@simpletire.com>';
                $this->Email->sendAs = 'html';
                $this->Email->template = 'customer_quote';
                $this->Email->delivery = 'smtp';
                $this->Email->headers['SMTPAPI'] = json_encode(array('category'=>array('customer_quote')));
                $this->set('product', $product);
                $this->set('admin_name', $_SESSION['Auth']['User']['fname']." ".$_SESSION['Auth']['User']['lname']);
                if($this->Email->send()){
                    return true;
                }
            }
        }

        function SEO($query) {
            $newUrl = "/" . $query;
            $SeoRoute = getModel('SeoRoute');
            $find = $SeoRoute->findByUrlSlugKey(md5($newUrl));
            if (isset($find['SeoRoute'])) {
                $GLOBALS['catalog_data'] = $find['SeoRoute']['catalog_data'];
            }
        }

        function setTierParameters($data_seo) {
            if (isset($data_seo['brand']) && isset($data_seo['line']) && isset($data_seo['partnumber'])) {
                $this->set('tier', 'dimension7');
            } elseif ((isset($data_seo['brand']) && isset($data_seo['line'])) || (isset($data_seo['brand']) && isset($data_seo['category'])) || (isset($data_seo['brand']) && isset($data_seo['subtype']))) {
                $this->set('tier', 'dimension5');
            } elseif (isset($data_seo['brand']) || isset($data_seo['subtype']) || isset($data_seo['category'])) {
                $this->set('tier', 'dimension4');
            }
        }

        function smartAjaxQuery($catalog_data) {
            $final_query = '';
            if (isset($GLOBALS['catalog_data'])) {
                $final_query = '&seo=1';
            }
            foreach ($catalog_data as $key => $value) {
                if ($key != 'page' && !empty(filter_var($key, FILTER_SANITIZE_STRING)) && !empty(filter_var($value, FILTER_SANITIZE_STRING))) {
                    $final_query .= '&' . filter_var($key, FILTER_SANITIZE_STRING) . '=' . filter_var($value, FILTER_SANITIZE_STRING);
                }
            }
            $this->set('final_query', $final_query);
            return $final_query;
        }

        function setInstaller() {
            $this->autoRender = false;
            $data = @$_POST['data'];
            if(isset($data)){
                $id = $data['id'];
                $name = $data['name'];
                $address = $data['address'];
                $image = $data['image'];
                $zip = $data['zip'];
                $this->Session->write('SelectedInstaller', array('id' => $id,'name' => $name, 'address' => $address, 'image' => $image));
                $this->Session->write('ZipGeo.MyCart.zip', $zip);
            }
        }

        function getHeaderData() {
            if (isset($GLOBALS['catalog_data'])) {
                $catalog_data = json_decode($GLOBALS['catalog_data'],true);
                $this->set('slug_parameters', $catalog_data);
                $this->setTierParameters($catalog_data);
            } else {
                $catalog_data = $this->request->query;
            }

            if(isset($catalog_data['result_id']) && $catalog_data['pagetype']=="hero") {
                $header = array();
                $page_creator = getModel('PageCreator');
                $p_response = $page_creator->getData($catalog_data['result_id']);
                $header['data'] = $p_response['PageCreator'];
                $content_pages = getModel('ContentPage');
                $header['sub_pages'] = $content_pages->getData($catalog_data['result_id']);

                // expires in 30 days
                $this->SessionX->write("PageCreatorId", $catalog_data['result_id'], 2592000);

                $this->set('header_gallery',$header);
            } else {
                // will only set for seo url_slug, not route_url
                $this->Content = getModel('Content');
                $this->set('bodytext', $this->Content->bodytext());
                $header = $this->Content->header();
                $this->set('ManufacturerName', @$header['seo']['ManufacturerName']);
                $this->set('ProductLineName', @$header['seo']['ProductLineName']);
                $this->set('breadcrumb', $header['breadcrumb']);
                $this->set('h1', $header['h1']);
                $this->set('brandimage', $header['brandimage']);
                $video = $this->Content->getVideoInfo();
                $this->set('video', $video);
            }

            return $catalog_data;
        }

        function addClubID($catalog_data) {
            if(!isset($catalog_data['brand']) && !isset($catalog_data['line'])){
                $catalog_data['club'] = 1;
            }
            return $catalog_data;
        }

        function addSizeFilter($filter,$catalog_data) {
            if(!empty($catalog_data['size'])) {
                $search = explode('-', $catalog_data['size']);
                if(isset($search[0]) && isset($search[1]) && isset($search[2])) {
                    $filter['quicksize'] = $search[0];
                    $catalog_data['loadindex'] = $search[1];
                    $filter['mph'] = $search[2];
                }
            }
            if (isset($catalog_data['quicksize'])) {
                $filter['quicksize'] = $catalog_data['quicksize'];
            }
            if (isset($catalog_data['mph'])) {
                $filter['mph'] = $catalog_data['mph'];
            }
            return array('filter' => $filter,'catalog_data' => $catalog_data);
        }

        function updateKeywordPopularity($search){
            $str = explode(" : ",$search);
            $str = trim($str[0]);
            $sql = "UPDATE search_indices SET popularity = popularity + 1 WHERE lower(search_key) = '".$str."'";
            $this->MyProduct->query($sql);
            return $this->MyProduct->getAffectedRows();
            // return will be used when we work on fetch other details of the matching record
        }
        function view() {
            $this->autoRender = false;
            print_r($this->Session->read('MyCart'));
            echo '<br><br>';
            print_r(serialize($this->Session->read('MyCart')));
        }

        function __index($appender = NULL,$oe = 0,$isAjax=false) {
            $zipCode = $this->getUpdatedZip();

            $this->Session->write('MyCart.CheckoutExperience.LastCatalogUrl',$_SERVER['REQUEST_URI']);

            if (isset($this->request->query['query'])) {
                $this->SEO($this->request->query['query']);
            }

            $catalog_data = $this->getHeaderData();

            $catalog_data = array_merge($catalog_data, $this->request->query);
            if (isset($appender)) {
                foreach ($appender as $key => $value) {
                    $catalog_data[$key] = $value;
                }
            }
            $final_query = $this->smartAjaxQuery($catalog_data);

            if ($this->Session->check('ZipGeo.MyCart.zip')) {
                $catalog_data['zip'] = $zipCode;
            }

            $this->verifyCatalogData($catalog_data);

            if (isset($catalog_data['width']) && isset($catalog_data['ratio']) && isset($catalog_data['rim']) && isset($catalog_data['rwidth']) && isset($catalog_data['rratio']) && isset($catalog_data['rrim'])) {
                $staggered = true;
            } else {
                $staggered = false;
            }
            $this->set('staggered', $staggered);

            $filter = array();
            $url = array();

            //Check if searched keyword exists in search_indices table and update its popularity -start
            if(!empty($catalog_data['search'])){
                $this->updateKeywordPopularity($catalog_data['search']);
            }
            //Check if searched keyword exists in search_indices table and update its popularity -end

            if(isset($catalog_data['search']) && is_numeric($catalog_data['search'])) {
                $this->set('hide_suggestion',1);
            }

            if (isset($catalog_data['width']) && isset($catalog_data['ratio']) && isset($catalog_data['rim']) && isset($catalog_data['rratio']) && isset($catalog_data['rwidth']) && isset($catalog_data['rrim'])) {
                $filter['resultsforfrontsizetext'] = $catalog_data['width'] . '/' . $catalog_data['ratio'] . 'R' . $catalog_data['rim'];
                $filter['resultsforrearsizetext'] = $catalog_data['rwidth'] . '/' . $catalog_data['rratio'] . 'R' . $catalog_data['rrim'];
                $filter['final'] = $filter['resultsforfrontsizetext'] . ' - ' . $filter['resultsforrearsizetext'];
                $url = "width=" . $catalog_data['width'] . "&ratio=" . $catalog_data['ratio'] . "&rim=" . $catalog_data['rim'] . "&rwidth=" . $catalog_data['rwidth'] . "&rratio=" . $catalog_data['rratio'] . "&rrim=" . $catalog_data['rrim'];
            } elseif ((isset($catalog_data['width']) && isset($catalog_data['ratio']) && isset($catalog_data['rim'])) || (isset($catalog_data['rratio']) && isset($catalog_data['rwidth']) && isset($catalog_data['rrim']))) {
                if (isset($catalog_data['width']) && isset($catalog_data['ratio']) && isset($catalog_data['rim'])) {
                    $filter['resultsfortiresizetext'] = $catalog_data['width'] . '/' . $catalog_data['ratio'] . 'R' . $catalog_data['rim'];
                    $url = "width=" . $catalog_data['width'] . "&ratio=" . $catalog_data['ratio'] . "&rim=" . $catalog_data['rim'];
                    $filter['final'] = $filter['resultsfortiresizetext'];
                    $filter['localDeal'] = true;
                }
                if (isset($catalog_data['rratio']) && isset($catalog_data['rwidth']) && isset($catalog_data['rrim'])) {
                    $filter['resultsfortiresizetext'] = $catalog_data['rwidth'] . '/' . $catalog_data['rratio'] . 'R' . $catalog_data['rrim'];
                    $url = "width=" . $catalog_data['width'] . "&ratio=" . $catalog_data['ratio'] . "&rim=" . $catalog_data['rim'];
                    $filter['final'] = $filter['resultsfortiresizetext'];
                }
            } elseif (isset($catalog_data['year']) && isset($catalog_data['make']) && isset($catalog_data['model']) && isset($catalog_data['option'])) {
                $year = str_replace(',', '', $catalog_data['year']);

                $filter['resultsforvehicletext'] = "{$year} {$catalog_data['make']}  {$catalog_data['model']} {$catalog_data['option']}";
                if (isset($catalog_data['safe'])) {
                    $filter['safe'] = $catalog_data['safe'];
                }
                $url = "year=" . $catalog_data['year'] . "&make=" . $catalog_data['make'] . "&model=" . $catalog_data['model'] . "&option=" . $catalog_data['option'];
                $filter['final'] = $filter['resultsforvehicletext'];
                $filter['localDeal'] = true;
            } else {
                $filter['find'] = 0;
            }

            $this->set("widgetUrl", $url);
            $this->set("query_data", $catalog_data);

            if (isset($catalog_data['runflat']) && $catalog_data['runflat'] == 'true') {
                $filter['runflat'] = 1;
            } elseif (isset($catalog_data['runflat']) && $catalog_data['runflat'] == 'false') {
                $filter['runflat'] = 2;
            } else {
                $filter['runflat'] = 3;
            }
            $catalog_data = $this->addClubID($catalog_data);

            if($this->debug) {
                echo "Parameters to catalog URL<br/>";
                debug($catalog_data);
                echo '<hr/>';
                echo "URL: http://" . $this->API_URL . '/catalog_data/0cfc3f81e47a6b6e06099cf890417d57';
                echo '<hr/>';
            }

            $this->retainFilters($this->request->query);

            # Fetching the data from Memcached for a specific URL Query if it exists start
            $urlQueryStr = $_SERVER['QUERY_STRING'];
            $cacheHashKey = md5(http_build_query($catalog_data, '', '&'));

            if (strpos($urlQueryStr, 'year') !== false) {
                if (!$data = unserialize(Cache::read($cacheHashKey))) {
                    $results = $this->CustomHttpSocket->get('http://' . $this->API_URL . '/catalog_data/0cfc3f81e47a6b6e06099cf890417d57', $catalog_data);
                    $data = serialize(json_decode($results['body'], true));
                    Cache::write($cacheHashKey, $data);
                    header('X-Catalog-Cache: MISS');
                } else {
                    $data = unserialize(Cache::read($cacheHashKey));
                    header('X-Catalog-Cache: HIT');
                }
            }
            # Fetching the data from Memcached for a specific URL Query if it exists finish

            # For fetching data from Cache if it exists or fetching data from db start
            $canUseCache = canApplyCache($catalog_data, array('select', 'subtype', 'content', 'club'));

            if ($canUseCache) {
                $cacheKey = 'category_products_cache_' . $catalog_data['subtype'];
                $data = unserialize(Cache::read($cacheKey, 'shortStore'));
                if (empty($data)) {
                    $results = $this->CustomHttpSocket->get('http://' . $this->API_URL . '/catalog_data/0cfc3f81e47a6b6e06099cf890417d57', $catalog_data);
                    $data = json_decode($results['body'], true);
                    Cache::write($cacheKey, serialize($data), 'shortStore');
                }
            } else {
                $results = $this->CustomHttpSocket->get('http://' . $this->API_URL . '/catalog_data/0cfc3f81e47a6b6e06099cf890417d57', $catalog_data);
                $data = json_decode($results['body'], true);
            }
            # For fetching data from Cache if it exists or fetching data from db finish

            if($this->debug) {
                echo "Return Data<br/>";
                debug($results);
                echo '<hr/>';
            }

            $available_filters = $this->checkFilterAvailable($catalog_data);
            if(empty($data['result']['items']) && !empty($this->retainOnlySize($catalog_data)) &&
                (isset($available_filters['filters']) || isset($available_filters['special']) || isset($available_filters['extra']))) {
                $this->Session->setFlash("Previous filters might have been removed since we don't have tires for that combination");
                $this->redirect('/catalog'.$this->retainOnlySize($catalog_data));
            }

            if($this->debug) {
                echo "json decoded Data<br/>";
                debug($data);
                echo '<hr/>';
            }

            if(isset($data['seo_url']) && $data['seo_url']!="" && $data['seo_url']!=null){
                $this->redirect($data['seo_url']);
            }
            $this->setNextPrev($data, $final_query);

            //add tab info
            $this->set('catalog_tab', $data['tab']);

            //add special size filters
            $res = $this->addSizeFilter($filter,$catalog_data);
            $filter = $res['filter'];
            $catalog_data = $res['catalog_data'];
            $filterType = $this->filters_available;
            foreach ($filterType as $key => $value) {
                if (isset($catalog_data[$value])) {
                    $filter[$value] = explode(',', $catalog_data[$value]);
                } else {
                    $filter[$value] = array();
                }
            }
            if (isset($catalog_data['page'])) {
                $filter['page'] = $catalog_data['page'];
            } else {
                $filter['page'] = 1;
            }
            if (isset($catalog_data['result'])) {
                $filter['result'] = (int)$catalog_data['result'];
            } else {
                $filter['result'] = 24;
            }
            if (isset($catalog_data['sort'])) {
                $filter['sort'] = $catalog_data['sort'];
            } else {
                $filter['sort'] = 'relevance';
            }
            if (isset($catalog_data['order'])) {
                $filter['order'] = $catalog_data['order'];
            } elseif (isset($catalog_data['sort']) && ($catalog_data['sort'] == 'shipping' || $catalog_data['sort'] == 'warranty')) {
                $filter['order'] = 'desc';
            } else {
                $filter['order'] = 'asc';
            }
            if (isset($catalog_data['price'])) {
                $prices = explode(",", $catalog_data['price']);
                if (count($prices) == 2) {
                    $filter['price']['min'] = $prices[0];
                    $filter['price']['max'] = $prices[1];
                }
            }
            $this->set('filter', $filter);
            $data = $this->removeNull($data);
            if(!$staggered) {
                $data = $this->setClubData($data);
            }
            $this->set('data', $data);
            $this->setAnalyticData($catalog_data, $data['tabs_count']['all']);

            $oeCount = 0;
            if (isset($data['size']) && !isset($_GET['oe_selected'])) {
                foreach ($data['size'] AS $s) {
                    if ($s['plus'] == 0) {
                        $oeCount++;
                    }
                }
                if (isset($catalog_data['option'])) {
                    $url = "year=" . $catalog_data['year'] . "&make=" . $catalog_data['make'] . "&model=" . $catalog_data['model'] . "&option=" . $catalog_data['option'];
                    if(isset($catalog_data['result_id']) && $catalog_data['result_id']!=0){ $url .= "&result_id=" . $catalog_data['result_id']; }
                    if(isset($catalog_data['pagetype']) && $catalog_data['pagetype']!=""){ $url .= "&pagetype=" . $catalog_data['pagetype']; }
                    if(isset($catalog_data['tab'])){ $url .= "&tab=" . $catalog_data['tab']; }
                    if(isset($catalog_data['result_id']) && $catalog_data['result_id']!=0 && $oe == 1){
                        return "refresh_oe";
                    }
                    if ($oeCount > 1 && !$this->debug) $this->redirect('/catalog/oe_selection?' . $url);
                }
            }

            if (isset($header['seo'])) {
                foreach ($header['seo'] as $key => $value) {
                    $this->set($key, $value);
                }
                if (isset($header['seo']['ManufacturerName']) && isset($header['seo']['ProductLineName']) && isset($header['seo']['ProductSize'])) {
                    if (isset($data['result']['items'][0]['price'])) {
                        if (isset($data['result']['items'][0]['mapprice']) && $data['result']['items'][0]['mapprice'] != 0.00) {
                            $this->set('ProductPrice', '$' . $data['result']['items'][0]['mapprice']);
                        } else {
                            $this->set('ProductPrice', '$' . $data['result']['items'][0]['price']);
                        }
                    } else {
                        $this->set('ProductPrice', '');
                    }
                }
            }

            $sidebar = $this->buildFilter($data, $filter);
            $this->set('sidebar_catalog', $sidebar);

            if (!empty($this->request->query)) {
                $filter_data = $this->getFilteredData($this->request->query);
                if (!empty($filter_data)) {
                    $key = implode('|', array_values($filter_data));
                    $filter_data = $this->getMoreFilteredData($filter_data, $filter);
                    if ($this->Cookie->check('user_query')) {
                        $this->Cookie->write('user_query', array_merge($this->Cookie->read('user_query'), array($key => $filter_data)), false);
                    } else {
                        $this->Cookie->write('user_query', array($key => $filter_data), false);
                    }
                }
            }
            $this->set("instant5", $this->instantDiscountArray());
            $this->set('filterType',$this->filters_available);
            //$this->getBannerInstaller();
            $this->setPromotionArray($data);
            $this->setWidgetExclusion($catalog_data);

            if($this->debug) {
                echo "Final data<br/>";
                debug($data);
                echo '<hr/>';
                die;
            }
        }

        function setWidgetExclusion($catalog_data) {
            $sub_type = @$catalog_data['subtype'];
            $sub_type_id = @explode(",", $sub_type);

            if(!empty($sub_type_id[0])) {
                $sub_type_id = $sub_type_id[0];
                $category = $this->MyProduct->query("SELECT category from my_product_sub_types WHERE id = $sub_type_id LIMIT 1");
            }
            if(!empty($category[0]['my_product_sub_types']['category'])) {
                $silo = trim($category[0]['my_product_sub_types']['category']);

                if($this->Session->read('UserExperience.Silo') != $silo) {
                    $this->Session->write('UserExperience.Silo', $silo);
                    $this->Session->delete('UserExperience.Widget');
                }
            }
        }

        function setPromotionArray($data) {
            $promotion_array = array();
            if(!empty($data['promotion']['items'])) {
                foreach($data['promotion']['items'] as $promotion_key => $promotion_value) {
                    $promotion_array[] = $promotion_value['id'];
                }
            }
            $this->set('promotion_array',$promotion_array);
        }

        function retainOnlySize($catalog_data) {
            $url = array();
            $filter_to_consider = $this->size_filters;
            foreach($catalog_data as $key => $value) {
                if(in_array($key, $filter_to_consider)) {
                    $url[] = $key.'='.$value;
                }
            }
            if(!empty($url)) {
                return "?".implode("&",$url);
            } else {
                return '';
            }
        }

        function checkFilterAvailable($catalog_data) {
            $applied = array();
            foreach($catalog_data as $key => $value) {
                if(in_array($key, $this->filters_available)) {
                    $applied['filters'] = true;
                }
                if(in_array($key, $this->special_filters)) {
                    $applied['special'] = true;
                }
                if(in_array($key, $this->size_filters)) {
                    $applied['size'] = true;
                }
                if(in_array($key, $this->extra_filters)) {
                    $applied['extra'] = true;
                }
            }
            return $applied;
        }

        function retainFilters($catalog_data) {
            $url = '';
            $filter_to_consider = array_merge($this->filters_available, $this->special_filters, $this->extra_filters);
            foreach($catalog_data as $key => $value) {
                if(in_array($key, $filter_to_consider)) {
                    $url .= '&'.$key.'='.$value;
                }
            }
            if(!empty($url)) {
                $this->Session->write('UserExperience.Filters', $url);
                $this->set('user_filters', $url);
            } else {
                $this->Session->delete('UserExperience.Filters');
                $this->set('user_filters', '');
            }
        }

        function setClubData($data) {
            $prefix = array(17 => 'CO-', 29 => 'EL-', 30 => 'EL-', 102 => 'VA-', 85 => 'SI-', 93 => 'TE-', 50 => 'JE-', 64 => 'MM-');
            $club_array = array();
            foreach ($data['result']['items'] as $key => $item) {
                if(isset($item['club_count']) && $item['club_count'] > 1) {
                    $brand_array = $this->getBrandGroupArray($item['brand_group']);
                    $data['result']['items'][$key]['brand_array'] = $brand_array;
                    $club_array[$item['id']] = array(
                        'name' => $item['group_name'],
                        'logo' => "http://s3.amazonaws.com/" . $item['s3_logo_path'],
                        'brand_names' => array_values($brand_array)
                    );
                } else {
                    $data['result']['items'][$key]['partnumber'] = @$prefix[$item['brandid']] . $item['partnumber'];
                }
            }
            $this->Session->write('club_array',$club_array);
            return $data;
        }

        function getBrandGroupArray($brand_group) {
            $brand_array = explode(",",$brand_group);
            $brand_array = array_unique($brand_array);
            $new_array = array();
            foreach($brand_array as $k => $v) {
                $id_and_name = explode("|",$v);
                $new_array[$id_and_name[0]] = $id_and_name[1];
            }
            asort($new_array);
            return $new_array;
        }

        function setAnalyticData($catalog_data, $all_items_total){
            if(!empty($catalog_data)){
                if(!empty($catalog_data['brand']) && !empty($catalog_data['line'])){
                    $this->set('contentPageType', 'catalog.line');
                }elseif (!empty($catalog_data['brand'])){
                    $this->set('contentPageType', 'catalog.brand');
                }
            }
            $this->set('contentGroup5', $all_items_total);
        }


        function _setAnalyticData($query_data,$sidebar,$filter) {
            $contentPageType = '';
            $brand = strtolower($this->getTypeString($sidebar,$filter,'brand'));
            $category = strtolower($this->getTypeString($sidebar,$filter,'category'));
            $line = strtolower($this->getTypeString($sidebar,$filter,'line'));
            $subtype = strtolower($this->getTypeString($sidebar,$filter,'subtype'));
            if(!empty($query_data['brand']) && !empty($query_data['category'])) {
                $contentPageType = 'catalog-categorybrand.'. $brand  .'~'.@$query_data['brand'].'.'.$category.'~'.@$query_data['category'];
            }else if(!empty($query_data['category'])) {
                $contentPageType = 'catalog-category.'.$category.'~'.@$query_data['category'];
            }else if(!empty($query_data['brand'])  && !empty($query_data['subtype'])) {
                $contentPageType = 'catalog-subtypebrand.'.$brand.'~'.@$query_data['brand'].'.'.$subtype.'~'.@$query_data['subtype'];
            }else if(!empty($query_data['subtype'])) {
                $contentPageType = 'catalog-subtype.'.$subtype.'~'.@$query_data['subtype'];
            }else if(!empty($query_data['brand'])  && !empty($query_data['line'])) {
                $contentPageType = 'catalog-brandline.'.$brand.'~'.@$query_data['brand'].'.'.$line.'~'.@$query_data['line'];
            } else if(!empty($query_data['brand'])) {
                $contentPageType = 'catalog-brand.'.$brand.'~'.@$query_data['brand'];
            }
            return $contentPageType;
        }

        function getTypeString($sidebar,$filter,$name) {
            $str = array();
            foreach($filter[$name] as $k => $v) {
                $str[] = $sidebar[$name][$v];
            }
            return implode(",",$str);
        }


        function removeNull($data) {
            $filter = $this->filters_available;
            foreach ($filter as $key => $value) {
                if(!empty($data[$value]['items'])) {
                    $filtered_array = array();
                    foreach($data[$value]['items'] as $a => $b) {
                        if(isset($b['name']) && $b['name'] != '') {
                            $filtered_array[$a] = $b;
                        }
                    }
                    $data[$value]['items'] = $filtered_array;
                }
            }
            return $data;
        }

        function setImageURLCatalog($data) {
            if (isset($data['result']['items'])) {
                foreach ($data['result']['items'] as $key => $item) {
                    if ($item['s3_enabled'] == 1) {
                        $data['result']['items'][$key]['tire_big_url'] = $this->generateImageURLCatalog($item['s3_folder_name'], 3);
                        $data['result']['items'][$key]['tire_thumb_one'] = $this->generateImageURLCatalog($item['s3_folder_name'], 1);
                        $data['result']['items'][$key]['tire_thumb_two'] = $this->generateImageURLCatalog($item['s3_folder_name'], 5);
                    }
                }

            }
            return $data;
        }

        function generateImageURLForAll($s3_folder_name, $i, $size_field) {
            $size = $size_field . '/filters:watermark(simpletire/logo.png,0,0,1)';
            $secret = '&3d7iy$7$tX$$bc_&YdaDT1Vunh^gN48';
            $msg = $size . '/simpletire/lines/' . $s3_folder_name . '/' . $i . '.jpg';
            $signature = hash_hmac("sha1", $msg, $secret, true);
            return '//gallery.simpletire.com/' . strtr(base64_encode($signature), '/+', '_-') . '/' . $msg;
        }

        function generateImageURLCatalog($s3_folder_name, $i) {
            return $this->generateImageURLForAll($s3_folder_name, $i, "150x150");
        }

        function generateImageURLProductPage($s3_folder_name, $i) {
            return $this->generateImageURLForAll($s3_folder_name, $i, "600x620");
        }

        function generateImageURLProductPageThumbnail($s3_folder_name, $i) {
            return $this->generateImageURLForAll($s3_folder_name, $i, "110x105");
        }

        function setNextPrev($data, $final_query) {
            $page = $this->request->query('page');
            if (!isset($page)) {
                $page = 1;
            }
            if ($page > 1) {
                $query_send = $this->manipulateQuery($final_query, 'page', $page - 1);
                $this->set('ajax_previous', $query_send);
            }
            if (!empty($data['result']['items'])) {
                $query_send = $this->manipulateQuery($final_query, 'page', $page + 1);
                $this->set('ajax_next', $query_send);
            }
        }

        function manipulateQuery($final_query, $key, $value) {
            parse_str($final_query, $query_string);
            $query_string[$key] = $value;
            $rdr_str = http_build_query($query_string);
            return $rdr_str;
        }

        function buildFilter($data, $filter) {
            $sidebar = array();
            $filterType = $this->filters_available;
            foreach ($filterType as $ftkey => $ftvalue) {
                if (sizeof($filter[$ftvalue]) > 0) {
                    if (isset($data[$ftvalue]['items'])) {
                        foreach ($data[$ftvalue]['items'] as $key => $value) {
                            $sidebar[$ftvalue][$value['id']] = $value['name'];
                        }
                    }
                }
            }
            return $sidebar;
        }


        function sortShippingOffer($data) {
            if (isset($data['ld_array'])) {
                $api_response = $data['ld_array'];
                $count_items = 0;
                $free_array = array();
                $discount_array = array();
                foreach ($data['result']['items'] as $key => $item) {
                    if (array_key_exists($item['id'], $api_response)) {
                        $count_items++;
                        $rate = explode(',', $api_response[$item['id']]);
                        $rate = explode('|', $rate[0]);
                        $rate = $rate[2];
                        if ($rate == 0) {
                            $discount_array[$key] = $item;
                        } else {
                            $free_array[$key] = $item;
                        }
                    }
                }
                $data['result']['items'] = array_merge($discount_array, $free_array);
                $this->set("free_shipping_count", $count_items);
            }
            return $data;
        }

        function getFilteredData($catalog_data) {
            $user_query = array();
            $params = array(
                'width',
                'ratio',
                'rim',
                'rwidth',
                'rratio',
                'rrim',
                'year',
                'make',
                'model',
                'option'
            );
            foreach ($params as $value) {
                $user_query = $this->appendIfSet($user_query, $value, $catalog_data);
            }
            return $user_query;
        }

        function getMoreFilteredData($user_query, $filter) {
            $user_query['query_string'] = $this->buildQuery($user_query);
            $user_query = $this->appendIfSet($user_query, 'resultsforvehicletext', $filter);
            return $user_query;
        }

        function buildQuery($array) {
            $query = '?select=1&';
            foreach ($array as $key => $value) {
                $query .= $key . '=' . $value . '&';
            }
            $query = rtrim($query, '&');
            return $query;
        }

        function appendIfSet($array, $value, $key) {
            if (isset($key[$value]) && $key[$value] != '') {
                $array = array_merge($array, array($value => $key[$value]));
            }
            return $array;
        }

        function read() {
            $this->autoRender = false;
            print_r($this->Cookie->read());
        }

        function refreshCatalog() {
            $this->autoRender = false;
            $this->__index(null,1,true);
            $this->set('show_popup', false);
            if ($this->request->query('c') == 't') {
                $this->set('ajaxCallURL', true);
            }
            $this->viewPath = 'Catalog';
            $this->render('index', 'ajax');
        }

        function verifyCatalogData($catalog_data) {
            $filters = array_merge($this->filters_available,$this->size_filters,$this->special_filters);
            foreach($catalog_data as $key => $value) {
                if(in_array($key,$filters)) {
                    return true;
                }
            }
            $this->redirect('/');
        }

        function ajaxLoadMore() {
            $this->autoRender = false;
            if ($this->request->query('seo') == '1') {
                $this->set('slug_parameters', 1);
            }
            $catalog_data = $this->request->query;
            $this->verifyCatalogData($catalog_data);
            if ($this->Session->check('ZipGeo.MyCart.zip')) {
                $catalog_data['zip'] = $this->Session->read('ZipGeo.MyCart.zip');
            }
            if (isset($catalog_data['width']) && isset($catalog_data['ratio']) && isset($catalog_data['rim']) && isset($catalog_data['rwidth']) && isset($catalog_data['rratio']) && isset($catalog_data['rrim'])) {
                $staggered = true;
            } else {
                $staggered = false;
            }
            $catalog_data = $this->addClubID($catalog_data);
            $catalog_data['promo'] = 0;
            $results = $this->CustomHttpSocket->get('http://' . $this->API_URL . '/catalog_data/0cfc3f81e47a6b6e06099cf890417d57', $catalog_data);
            $data = json_decode($results['body'], true);
            $filter = array();
            if (isset($catalog_data['sort'])) {
                $filter['sort'] = $catalog_data['sort'];
            } else {
                $filter['sort'] = 'relevance';
            }
            $this->set('filter', $filter);
//          $data = $this->setImageURLCatalog($data);
            $data = $this->removeNull($data);
            if(!$staggered) {
                $data = $this->setClubData($data);
            }  
            $this->setPromotionArray($data);
            $this->set('data', $data);
            $this->set('method', 'ajax');
            $this->viewPath = 'Elements' . DS . 'Catalog';

            if ($this->RequestHandler->isMobile()) {
                ($staggered ? $this->render('staggered', 'ajax') : $this->render('result', 'ajax'));
            } else {
                ($staggered ? $this->render('staggered', 'ajax') : $this->render('result', 'ajax'));
            }
            $this->set("instant5", $this->instantDiscountArray());
        }

        function freeShippingArray() {
            $carrol = array(
                12,
                32,
                33,
                34,
                103,
                105,
                239,
                254,
                255,
                256,
                257,
                268,
                371,
                372,
                373,
                374,
                375,
                376,
                378,
                379,
                380,
                381,
                382,
                383,
                384,
                385,
                386,
                387,
                388,
                389,
                390,
                391,
                392,
                393,
                394,
                395,
                396,
                397,
                398,
                399,
                400,
                401,
                402,
                403,
                404,
                405,
                455,
                456,
                457,
                504,
                505
            );
            $km = array(
                38,
                39,
                40,
                41,
                42,
                43,
                44,
                45,
                46,
                47,
                48,
                289,
                290,
                291,
                292,
                511,
                513,
                514
            );
//        return array_merge($carrol,$km);
            return array();
        }

        function email_friend($product_id = NULL) {
            $this->autoRender = false;
            //Configure::write('debug', 0);
            $this->MyProduct->id = $product_id;
            $p = $this->MyProduct->read();
            $this->set('product_id', $product_id);
            if (!empty($p)) {
                $data = $_POST;
                if (!empty($data)) {
                    $this->Email->subject = 'SimpleTire.com Email from your friend ' . $data['yourname'];
                    $this->Email->to = $data['friendmail'];
                    $this->Email->from = $data['yourmail'];
                    $this->Email->sendAs = 'html';
                    $this->Email->template = 'email_friend';
                    $this->Email->delivery = 'smtp';
                    $this->set('p', $p);
                    $this->set('data', $data);
                    $this->Email->send();
                    echo 1;
                }
            }
        }

        function newtestemail($config) {
            $this->autoRender = false;
            $Email = new CakeEmail();
            $Email->config($config);
            $Email->from(array('abhishek@simpletire.com' => 'SimpleTire'));
            $Email->to('abhishek@simpletire.com');
            $Email->subject('NEW I M . ' . $config);
            $Email->send('My messagec ds ' . $config);
        }

        function email_friend_view() {
            $this->autoRender = false;
            echo 'view will be here soon';
        }

        function freeShippingDeal($data) {
            foreach ($data['ld_array'] as $key => $value) {
                $A = explode(',', $value);
                $ld_warehouse = "";
                foreach ($A as $key2 => $value2) {
                    $B = explode('|', $value2);
                    if (in_array($B[1], $this->freeShippingArray())) {
                        $ld_warehouse .= $B[0] . "|" . $B[1] . "|" . $B[2] . ",";
                    }
                }
                $ld_warehouse = rtrim($ld_warehouse, ",");
                if (isset($data['result']['items'][$key]) && $ld_warehouse != "") {
                    $data['result']['items'][$key]['ld_warehouse'] = $ld_warehouse;
                }
            }
            return $data;
        }


        function line($id = 9411) {
            $this->autoRender = false;
            Configure::write('debug', 2);
            $this->MyManufacturersProductsLine->id = $id;
            $line = $this->MyManufacturersProductsLine->read();
            var_dump($line);
        }

        function checkForFreeShipping($id) {
            $catalog_data = array('id' => $id);
            $results = $this->CustomHttpSocket->get('http://' . $this->API_URL . '/catalog_data/0cfc3f81e47a6b6e06099cf890417d57', $catalog_data);
            $data = json_decode($results['body'], true);
            if(isset($data['tabs_count']['free'])) {
                return 1;
            }
            return 0;
        }

        function getProductData($id){
            $this->MyProduct->recursive = -1;
            $product = $this->MyProduct->find('first',
            array(
                'fields' => array(
                    'weight', 'inflation_pressure', 'approved_rim_width',
                    'uninflated_overall_width', 'tread_width', 'uninflated_overall_diameter'
                ),
                'conditions' => array('id' => $id),
                )
            );
            return $product;
        }

        function product($id) {
            if(is_numeric($id)) {
                $this->set("no_hr", 1);
                $this->MyProduct->id = $id;
                $this->set('isFreeShipping',$this->checkForFreeShipping($id));

                if ($this->Session->check('ZipGeo.MyCart.zip') && $GLOBALS['_Settings']['shipping_offer'] != 'none') {
                    $params = array(
                        'zip' => $this->Session->read('ZipGeo.MyCart.zip'),
                        'radius' => $this->radius,
                        'prod_id' => $id
                    );
                    $results = $this->CustomHttpSocket->get("http://" . $this->API_URL . "/checkLocalDeal/0cfc3f81e47a6b6e06099cf890417d57", $params);
                    $data = json_decode($results['body'], true);
                    if (!empty($data)) {
                        $this->set("ld_array", $data);
                    }
                }
                $this->MyProduct->unbindModel(array('hasMany' => array('MyDistributorsWarehousesProduct')));
                $promotions =  $this->MyProduct->getPromotions($id);
                $this->set('promotions',$promotions);
                $product_sku = $this->getProductData($id);

                $catalog_data['id'] = $id;
                if(!empty($this->SessionX->read('PageCreatorId'))) {
                    $catalog_data['pagetype'] = 'hero';
                    $catalog_data['result_id'] = $this->SessionX->read('PageCreatorId');
                }
                $results = $this->CustomHttpSocket->get('http://' . $this->API_URL . '/catalog_data/0cfc3f81e47a6b6e06099cf890417d57', $catalog_data);
                $data = json_decode($results['body'], true);
                $product = $data['result']['items'][$id];
                if(!empty($product)) {
                    $catalog_data['subtype'] = $product['subtypeid'];
                    $product['TypeCategory'] = $this->MyProduct->getTypeCategory($id);

                    $item_actual = '/Catalog/product/' . $product['id'];
                    $SeoRoute = getModel('SeoRoute');
                    $find = $SeoRoute->findByRouteUrlKey(md5($item_actual));
                    if (isset($find['SeoRoute'])) {
                        $label = $find['SeoRoute']['url_slug'];
                        $label = 'item_' . str_replace('/', '', $label);
                        $this->set('label', $label);
                    }

                    $this->Content = getModel('Content');
                    $video = $this->Content->_VideoInfo($product['lineid']);
                    $this->set('video', $video);

                    if (!empty($product)) {
                        $product['image_url'] = '//dki3ho7vp1wav.cloudfront.net/' . $product['brand_image_id'] . '.png';
                    }

                    $this->set('product', $product);
                    $this->set('product_sku', $product_sku);

                    $MMPL = getModel('MyManufacturersProductsLine');
                    if (isset($product['lineid'])) {
                        $linedesc = $MMPL->linedesc($product['lineid']);
                        $linefeature = $MMPL->linefeature($product['lineid']);
                        $this->set('linedesc', $linedesc);
                        $this->set('linefeature', $linefeature);
                    }

                    // for the items category used for remarketing
                    $item_category = array();
                    $cat = $this->MyManufacturersProductsLineCategory->find('first', array('conditions' => array('manufacturers_products_line_id' => $product['tcsparts_lineid'])));
                    if (!empty($cat)) {
                        $this->MyCategory->recursive = -1;
                        $item_category = $this->MyCategory->findById($cat['MyManufacturersProductsLineCategory']['category_id']);
                    }
                    $this->set('item_category', $item_category);


                    if (!empty($this->params['named']['Page'])) {
                        $this->params['page'] = $this->params['named']['Page'];
                    }

                    $this->Paginator->settings = array(
                        'order' => array('Review.st_recommendation' => 'DESC')
                    );

                    $line_id = $product['lineid'];
                    
                    $conditions = array(
                        'Review.manufacturers_products_line_id' => $line_id,
                        'Review.approved' => 1
                    );

                    $this->set('reviews', $this->Paginator->paginate('Review', $conditions));
                    $this->set('average_review', $this->Review->query("SELECT average_rating, total_reviews FROM my_manufacturers_products_lines WHERE id = $line_id"));
                    $this->set('line_id', $product['lineid']);
                    $this->set('line', $product);
                    $this->set('manufacturer', $product);

                    $prefix = array(
                        17 => 'CO-',
                        29 => 'EL-',
                        30 => 'EL-',
                        102 => 'VA-',
                        85 => 'SI-',
                        93 => 'TE-',
                        50 => 'JE-',
                        64 => 'MM-'
                    );
                    $this->set("prefix", $prefix);

                    // for seo vars used in meta
                    $this->set('ManufacturerName', @$product['brand']);
                    $this->set('ProductLineName', @$product['line']);
                    $this->set('ProductPrice', @$product['price']);


                    $this->set('ProductSize', tireSize($product));

                    if (isset($product['in_stock'])) {
                        $in_stock = $product['in_stock'];
                    } else {
                        $in_stock = 1;
                    }

                    $this->set('in_stock', $in_stock);
                    $this->set("instant5", $this->instantDiscountArray());
                    $this->set('similar_sizes', $this->fetchAllSimilarSizes($id));
                    $this->setWidgetExclusion($catalog_data);
                }else{
                    $this->redirect('/errors/error400');
                }
                $this->setPromotionArray($data);
            }else{
                $this->redirect('/'.$id);
            }
            $this->getBannerInstaller();
            $this->set('catalog_url',$this->Session->read('MyCart.CheckoutExperience.LastCatalogUrl'));
        }

        function fetchAllSimilarSizes($id) {
            $results = $this->CustomHttpSocket->get('http://' . $this->API_URL . '/availableTires/' . $id . '/0cfc3f81e47a6b6e06099cf890417d57');
            $data = json_decode($results['body'], true);
            foreach ($data['matching'] as $key => $value) {
                $imgval = $this->CustomHttpSocket->get("http://" . $this->API_URL . "/tire_images/".$value['line_id']."/sku/0cfc3f81e47a6b6e06099cf890417d57");
                $product_images = json_decode($imgval['body'], true);
                if(!empty($product_images)){
                    $image_path = $product_images;
                } else {
                    $image_path = "//simpletire.com/MyImages/view/" . $value['default_id'];
                }
                $data['matching'][$key]['image_url'] = $image_path;
            }
            return $data;
        }

        function ajax_promo($id = NULL) {
            $this->autoRender = false;
            $this->layout = 'ajax';
            $Promotion = getModel('Promotion');
            $Promotion->id = $id;
            $this->set('promotion', $Promotion->read());
            $this->viewPath = 'Elements' . DS . 'Promotions';
            $this->render('rebate_item');
        }

        function Dialog360($id) {
            $this->autoRender = false;
            $BIG_URLS = $THUMB_URLS = $FILENAME = array();
            $prod_images = unserialize($_REQUEST['product_images']);
            foreach($prod_images as $pi){
                $BIG_URLS[] = $pi['image'];
                $THUMB_URLS[] = $pi['image_thumb'];
                $path = pathinfo($pi['image']);
                $FILENAME[] = $path['filename'];
            }
            $this->set('BIG_URLS', $BIG_URLS);
            $this->set('THUMB_URLS', $THUMB_URLS);
            $this->set('FILENAME', $FILENAME);
            if (isset($_GET['size'])) {
                $this->set('SIZE', $_GET['size']);
            }
            if (isset($_GET['name'])) {
                $this->set('NAME',str_replace("asterisk","*",rawurldecode($_GET['name'])));
            }
            $this->set('URL', $url = $this->seo_url($id));
            $item = array();
            $item['id'] = $id;
            $item['listType'] = @$_GET['list'];
            $this->set('item', $item);
            $this->viewPath = 'Elements' . DS . 'Catalog';
            $this->render('image360', 'ajax');
        }

        function seo_url($product_id) {
            $this->autoRender = false;
            $this->MyProduct->recursive = -1;
            $data = $this->MyProduct->find('first', array('fields' => array('seo_url'), 'conditions'=>array('id'=>$product_id)));
            if (isset($data['MyProduct']['seo_url']) && $data['MyProduct']['seo_url'] == '') {
                $data['MyProduct']['seo_url'] = '/Catalog/product/' . $product_id;
            }
            return $data['MyProduct']['seo_url'];
        }

        function clear_affiliate()
        {
            if(isAdmin()){
                $this->Session->delete("AffiliateId");
                $this->Session->delete("PageCreatorId");
                unset($_SESSION['Expiry']['AffiliateId']);
                unset($_SESSION['Expiry']['PageCreatorId']);
            }else{
                $this->redirect('/errors/error400');
            }
        }
    }
