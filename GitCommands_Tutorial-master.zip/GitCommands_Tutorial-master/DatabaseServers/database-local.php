<?php

class DATABASE_CONFIG {
    var $xd = array(
          'driver'      => 'mysql'
        , 'persistent'  =>  false
        , 'host'        => 'localhost'
        , 'login'       => 'dbuser'
        , 'password'    => 'tires123'
        , 'database'    => 'tirexd'
        , 'prefix'      => ''
    );
    var $ftp = array(
          'driver'      => 'mysql'
        , 'persistent'  =>  false
        , 'host'        => 'localhost'
        , 'login'       => 'dbuser'
        , 'password'    => 'tires123'
        , 'database'    => 'simpleinv'
        , 'prefix'      => ''
    );
    var $tcsparts = array(
          'driver'      => 'mysql'
        , 'persistent'  =>  false
        , 'host'        => 'localhost'
        , 'login'       => 'dbuser'
        , 'password'    => 'tires123'
        , 'database'    => 'tcsparts'
        , 'prefix'      => ''
    );
    var $tireguide = array(
        'driver'        => 'mysql'
        , 'persistent'  =>  false
        , 'host'        => 'localhost'
        , 'login'       => 'dbuser'
        , 'password'    => 'tires123'
        , 'database'    => 'TireGuide'
        , 'prefix'      => ''
    );
    var $tireguide_combined = array(
        'driver'        => 'mysql'
        , 'persistent'  =>  false
        , 'host'        => 'localhost'
        , 'login'       => 'dbuser'
        , 'password'    => 'tires123'
        , 'database'    => 'tireguide_combined'
        , 'prefix'      => ''
    );
    var $tgp = array(
        'driver'        => 'mysql'
        , 'persistent'  =>  false
        , 'host'        => 'localhost'
        , 'login'       => 'dbuser'
        , 'password'    => 'tires123'
        , 'database'    => 'tgp'
        , 'prefix'      => ''
    );
    var $default = array(
          'driver'      => 'mysql'
        , 'persistent'  =>  false
        , 'host'        => 'localhost'
        , 'login'       => 'dbuser'
        , 'password'    => 'tires123'
        , 'database'    => 'rpm_simpletire'
        , 'prefix'      => ''
    );
}

?>