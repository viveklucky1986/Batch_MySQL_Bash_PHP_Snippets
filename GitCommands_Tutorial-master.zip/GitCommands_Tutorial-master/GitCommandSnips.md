```bash
git init
```
Convert simple folder or directory into git empty directory usable for importing repository.

```bash
git pull
```
Pull all the branches's code into the current repository local directory

```bash
git checkout master
```
Change the Local system's head to "master" branch.

```bash
git checkout <branchname>
```
Change the Local system's head to "master" branch.

```bash
git pull origin HEAD
```
Pull all content of the HEAD branch(means branch on which HEAD pointer is set).

```bash
git clone <repo_clone_url>
git clone https://github.com/SimpleTire/frontend.git
```
Clone the remote git repository into local system git directory

```bash
curl "https://api.github.com/users/$USER/repos?page=$PAGE&per_page=100" |
	grep -e 'git_url*' |
	cut -d \" -f 4 |
	xargs -L1 git clone
```
Clone All Repositories of a User into specific directory.

```bash
#!/bin/bash
ORGANIZATION=simpletire
TOKEN=38116c18ffb616879a4ba8527f7711d96b44d75e
# for i in `curl -sS "https://api.github.com/orgs/$ORGANIZATION/repos?per_page=200&access_token=$TOKEN" |grep html_url|awk 'NR%2 == 0'|cut -d ':'  -f 2-3|tr -d '",'`; do
for i in `curl -sS "https://api.github.com/orgs/$ORGANIZATION/repos?per_page=200&access_token=$TOKEN" |grep clone_url|cut -d ':'  -f 2-3|tr -d '",'`; do
    # echo git clone $i;
    git clone $i;
    # git clone $i.git;
done
```
Clone All Repositories of an Organization into specific directory.

```bash
git status
```
Compare between your local repository branch and corresponding remote repository branch.

```bash
history -cw && reset && clear && history -cw && \
git status && \
git add -A && \
git commit -m "<Commit_Message>" && \
git push origin HEAD

# Example
history -cw && reset && clear && history -cw && \
git status && \
git add -A && \
git commit -m "SIM-3446:Query change debug" && \
git push origin HEAD
```
Daily push the changes to remote after every file/code change.

```bash
history -cw && reset && clear && history -cw && \
git checkout master && git pull && git checkout <branchname> && git pull

# Example
history -cw && reset && clear && history -cw && \
git checkout master && git pull && git checkout sim-3446 && git pull
```
If even after having your file on remote repo path, it shows 404 error in browser check, then do above.

```bash
git pull origin <branchname>
git push origin <branchname>
# Example
git pull origin sim-3446
git push origin sim-3446
```
https://stackoverflow.com/questions/39399804/updates-were-rejected-because-the-tip-of-your-current-branch-is-behind  
https://stackoverflow.com/questions/24114676/git-error-failed-to-push-some-refs-to  
If you're getting error - "Updates were rejected because the tip of your current branch is behind...."

Press Win key + R then enter following command in the RUN dialog box:
```bat
%windir%\System32\rundll32.exe sysdm.cpl,EditEnvironmentVariables
```
Open Emvironment Variables in Windows OS

```bash
sed -i 's/\r//' filename
```
Convert file format from Windows to Unix/Linux:

```bash
ssh -F ~/vagrantphp7-ssh simpletirephp7 -vvv
# OR #
ssh -F ~/vagrantphp7-ssh simpletirephp7
ssh -F ~/simplevagrant-ssh simplevagrant
ssh -F ~/simplevagrant-ssh master
```
Open Vagrant Virtual Machine in Local system
```bash
git add -N <filename>
git add -N testfile.sh
```

```bash
history -cw && reset && clear && history -cw
```
Clear Bash or Git Bash Shell history and screen

```bash
vagrant ssh-config > ~/vagrantphp7-ssh
vagrant ssh-config > ~/simplevagrant-ssh
```
Generate new configuration file for vagrant

```bash
git config --global user.email "[Email_Address]"
git config --global user.name "[Username]"
git config --global user.email "[Email_Address]" && \
git config --global user.name "[Username]"
git config --global user.email "vivek@simpletire.com"
git config --global user.name "vivek-simpletire"
git config --global user.email "vivek@simpletire.com" && \
git config --global user.name "vivek-simpletire"
```
Git Change config User Email and User Name:

```bash
history -cw && reset && clear && history -cw && \
read -p "Branch Identifier: " branchId && \
git bundle create "simple_$branchId.bundle" $branchId && \
exit
or
git bundle create "$branchId_[CurrDate].bundle" $branchId
git bundle create "_baks_/$branchId_[CurrDate].bundle" $branchId
git bundle create "sim-3808_08012018.bundle" sim-3808
git bundle create "_baks_/sim-3780_29012018.bundle" sim-3780
```
Git Bundle/Backup Specific Branch of Repository

```bash
history -cw && reset && clear && history -cw
git commit -am "[Commit Message]" && git push origin HEAD
git commit -am "[Commit Message]" && git push origin [branch_name]
git commit -am "SIM-3521:Probably final code" && git push origin HEAD
git commit -am "SIM-3521:Probably final code" && git push origin sim-3521
```
Shorthand for adding and committing files through Git Bash

```bash
git diff --name-only  master...[branch_name]
git diff --name-only  master...[branch_name] > filesModified.list
git diff --name-only  master...sim-3521
git diff --name-only  master...sim-3521 > filesModified.list
```
Get the list of files that were changed in a specific branch so far

```bash
git pull && git checkout master && git pull origin && \
git checkout [feature_branch_name] && git merge master
git pull && git checkout master && git pull origin && \
git checkout sim-3521 && git merge master
# Make sure the merge message is saved in MERGE_MSG File.
```
Final Git Commands need to run on daily once before I start work (if 2 different locations then twice) without fail

```bash
git fetch
git fetch -p
git pull --rebase
git reset --hard origin/<feature_branch_name>
git reset --hard origin/sim-3521
```
Probably for fixing the problem "Your <feature_branch> is ahead of 'origin/<feature_branch>' by n commit(s)."

```bash
git checkout <branch_name>
git branch --track
git pull origin <branch_name>
git branch -u origin/<branch_name>
git branch --set-upstream-to=origin/<branch_name> <branch_name>
git branch --set-upstream-to=origin/sim-3697 sim-3697
git branch --set-upstream-to=origin/sim-3808 sim-3808
git pull
```
Set <feature_branch> branch for tracking and pull from it.

```bash
#!/bin/bash
read -p "Feature Branch Name: " fBranch && \
git pull && git checkout master && git pull origin && \
git checkout $fBranch && git merge master
# Make sure the merge message is saved in MERGE_MSG File.
```
Script to be executed daily before start editing anything.

```bash
install -d -m 0777 app/webroot/cache_css
install -d -m 0777 app/webroot/cache_js
mkdir -m 777 webroot/cache_js
mkdir -m 777 webroot/cache_css
rm -Rf /var/www/frontend/app/tmp/cache/persistent/*
rm -Rf /var/www/frontend/app/tmp/cache/models/*
rm -Rf /var/www/frontend/app/webroot/cache_js/*
rm -Rf /var/www/frontend/app/webroot/cache_css/*
# Then add the following line in the app/Config/asset_compress.ini file:
files[] = [path/to/external_libname.js]
files[] = View/MyCart/Checkout/jquery-mask.js
cd /var/www/frontend/app && Console/cake AssetCompress.AssetCompress build --force
cd [path_to_cakephp_repo] && Console/cake AssetCompress.AssetCompress build --force
```
Cakephp Bash Code to Reload JS/CSS addition or changes

```bash
git checkout -b <branch_name>
git checkout -b sim-3521
```
Create a new branch with given <branch_name> in the any repository.

```bash
git archive sim-3521-masklib-test2 | bzip2 > sim-3521-masklib-test2.tar.bz2
git archive [branch_name] | bzip2 > [branch_name].tar.bz2
```
Export any branch's changes into archive file for backaup

```bash
git checkout <latest_branch>
git merge -s ours <outdated_branch> # Merge branches, but use our branch head
git checkout staging
git merge -s ours email # Merge branches, but use our branch head
```
Overwrite one branch's changes to another branch

```bash
git add -f app/webroot/cache_css
git add -f app/webroot/cache_css/*
git add -f [Folder_Full_Path_From_RepoRoot]
git add -f [Folder_Full_Path_From_RepoRoot]/*
```
Git add new directory and it's inner files

```bash
grep ^error_log /etc/php/7.1/fpm/php.ini
grep ^error_log /etc/php/7.1/cli/php.ini
grep ^error_log /etc/php/5.6/fpm/php.ini
grep ^error_log /etc/php/5.6/cli/php.ini
```
PHP INI File Grep Log Path in Vagrant

```cmd
start notepad++.exe "C:\Windows\System32\drivers\etc\hosts"
```
Notepad++ Open Windows Hosts file

```bash
git log --pretty=oneline | tail -n n
git log --pretty=online | tail -n 10
git log --all -- '[FilePathRoot]' > [DestFielName].txt
git log --all -- 'SimpleTire/Database.php' > GitLog.txt
git log --all -- 'SimpleTire/Database.php' > GitLog.txt | tail -n 3
```
Git Log get last n entries

```bash
git bundle create "[bundle_name].bundle" [branch_name]
git bundle create "sim-3626.bundle" sim-3626
```
Git Create Bundle of Repo Branch regularly

```bash
git stash && git checkout master
git pull origin && git checkout [branch_name]
#Example: git pull origin && git checkout sim-3626
git merge master && git stash pop
"Provide the merge message and save & exit the message file"
```
Git Stash your local changes and then merge and then pull stash

```bash
history -cw && reset && clear && history -cw
cp foo.txt {,.backup. $((date)) }
cp foo.txt foo.backup.`date`
cp my_distributors_orders_controller.php "_baks_/my_distributors_orders_controller.php.bak.`date`"
cp my_distributors_orders_controller.php "_baks_/my_distributors_orders_controller.php.bak.`date`"
cp [filename] "_baks_/[filename].bak.`date`"
cp foo.{txt,backup."`date`"}
cp foo.{txt,backup."$(date +%Y%m%d-%H%M%S)"}
cp [filename] "_baks_/[filename].bak.$(date +%Y%m%d-%H%M%S)"
cp my_distributors_orders_controller.php "_baks_/my_distributors_orders_controller.php.bak.$(date +%Y%m%d-%H%M%S)"
history -cw && reset && clear && history -cw
```
Backup files and rename with copy command

```bash
#!/bin/bash
read -p "Name of file to backup: " filename
cp "$filename" "_baks_/$filename.bak.$(date +%Y%m%d-%H%M%S)"
# cp "$filename" "_baks_/$filename.bak.`date`"
```
OR
```bash
#!/bin/bash
read -p "Name of file to backup: " filename
install -m 644 -D [filename] [/path/to/copy/file/to/any/level/filename]
install -D file -m 644 -t /path/to/copy/file/to/is/very/deep/there
install -D view.ctp -m 644 "_baks_/view.ctp"
install -m 644 -D view.ctp "_baks_/view.ctp"
```
Bash script to take backup of file

```bash
git merge -X theirs [Branch_Name]
git merge -X theirs [HEAD]
git merge -X theirs sim-3697
git merge -X theirs master
```
Reference Link - https://stackoverflow.com/questions/40517129/git-merge-with-force-overwrite  
Git Resolve Merge conflicts by overwriting HEAD file/changes by TARGET file/changes

```bash
git rev-parse --abbrev-ref HEAD
```
Git Display the current branch pointed by HEAD

```bash
git checkout [FROM_BRANCH] [path/to/filename]
git checkout master SimpleTire/functions.php
```
Git overwrite single file from {branch1} to {current_branch}

```bash
git branch -m [Old_Name] [New_Name]
git branch -m 3697 sim-3697
```
Git Rename a specific branch

```bash
git config --global alias.purgehist1 "history -cw && reset && clear && history -cw"
git config --global alias.co checkout
git config --global alias.ci commit
git config --global alias.st status
git config --global alias.br branch
git config --global alias.hist "log --pretty=format:'%h %ad | %s%d [%an]' --graph --date=short"
git config --global alias.type 'cat-file -t'
git config --global alias.dump 'cat-file -p'

OR

start notepad++.exe "C:\Program Files\Git\etc\profile.d\aliases.sh"
notepad++.exe "C:\Program Files\Git\etc\profile.d\aliases.sh"
# Then add your necessary aliases and commands like below:
alias purgehist='history -cw && reset && clear && history -cw'
alias gituploadmods='read -p "Commit message: " commit_note && git commit -am "$commit_note" && git push origin HEAD'
```
Git Command Aliases and ShortCodes

```bash
git update-index --assume-unchanged [filepath]
git update-index --assume-unchanged composer.json
# For files inside sub-directory
cd SimpleTire/
git update-index --assume-unchanged functions.php
git update-index --assume-unchanged $(git ls-files | tr '\n' ' ')
git ls-files | tr '\n' ' ' | xargs git update-index --assume-unchanged
git ls-files -z | xargs -0 git update-index --assume-unchanged
find path/to/dir -type f -exec git update-index --assume-unchanged '{}' \;
```
Git Remove file from the 'changes' memory temporarily

```bash
git push -d origin 3697
git push -d origin SIM-3697
git push -d origin [Branch_ID]
git push -d [Remote] [Branch_ID]
```
Git Remove/Delete Remote Branch by ID

```bash
git branch -d <branch_name>
git branch -d SIM-3697
```
Git Remove/Delete Local Branch by ID

```bash
git commit -am "[Commit_Message]" [File_Path]
git commit -am "SIM-3697:Memcached implement" app/Config/bootstrap.php
git commit -m "SIM-3697:Memcached implement" app/Config/bootstrap.php
```
Git Commit Single File by path

```bash
git add `git status | grep modified | sed 's/\(.*modified:\s*\)//'`
# Or
git ls-files --modified | xargs git add
```
Git only stage modified files for committing and pushing

```cmd
C:\Users\WMIND2004\AppData\Roaming\Sublime Text 3\Packages\User
start explorer "C:\Users\WMIND2004\AppData\Roaming\Sublime Text 3\Packages\User"
explorer "C:\Users\WMIND2004\AppData\Roaming\Sublime Text 3\Packages\User"
```
Sublime Text 3 Snippets Dir path

```bash
https://github.com/[OrganizationName]/[RepositoryName]/commit/[CommitId]
https://github.com/SimpleTire/frontend/commit/<CommitId>
https://github.com/SimpleTire/frontend/commit/[CommitId]
https://github.com/SimpleTire/frontend/commit/a664f1b8
```
Github Commit URL Syntax for loading it in browser

```bash
git bundle create "_baks_/[repo_name].bundle" --all
git bundle create "_baks_/api.bundle" --all
```
Git Bundle/Backup all branches of specific repository

```bash
git merge -s recursive -X theirs [branchId]
git merge -s recursive -X theirs master
git merge master --strategy=ours
```
Git Merge with master and overwrite our changes with theirs and vice versa on the spot.

```cmd
mklink c:\Windows\System32\subl.exe "c:\Program Files\Sublime Text 3\subl.exe"
subl "[Any file/dir path]"
```
Make SublimeText 3 editor accessible globally in the OS Windows 7 - 10 64Bit.

```bash
git checkout <path-to-file>
git checkout -- .
```
Git Unstage/Remove all files from the commit history.

```bash
git log sim-3780 > sim-3780.log
git log sim-3780 -- [path/to/file]
```
Git Log By Branch and File;

```bash
git reset --hard [CommitId]
git reset --hard 0f24d98ca713f20ab2d933175e38a9c9fd59879a
```
Git Revert the committed changes upto given Commit ID.

```bash
git checkout HEAD -- [path/to/file]
git checkout HEAD -- app/Controller/CatalogController.php
```
Git Reset Hard Single File

```html
https://github.com/{username}/{projectname}/archive/{commit_sha}.zip
https://github.com/{organization}/{projectname}/archive/{commit_sha}.zip
https://github.com/SimpleTire/supplier/archive/2a5a662eb7973ae7797261f78ed643855ed66bb2.zip
```
Download Commit Files of Specific Commit SHA Hash ID of any project of organization

```bash
git config --global credential.helper wincred
git config --global user.email "[Email Address]"
git config --global user.name "[Username]"

# Example
git config --global credential.helper wincred
git config --global user.email "vivek@simpletire.com"
git config --global user.name "vivek-simpletire"
```
Now run any Git command in Git Bash and enter your Username and Password once, it will get stored.
Then set the global Username and Email through Git command.
Store your Git Account's Credentials in WINCRED Windows Credentials Store permanently

```regex
Find what: [^\S\n\r]+$
Replace with:
```
Remove trailing spaces from each line in file without affecting new and blank lines.

```bash
git clean -fd
```
Git Remove the files from your staging area.

```cmd
rem Open explorer in current folder
start .
rem Open explorer in parent folder
start ..
rem Open explorer in folder related to parent folder
start "..\[FolderName]"
rem Open explorer in folder related to home folder
start "%HOMEPATH%\[FolderPath]"
start "..\frontend"
start "%HOMEPATH%\Projects\simple\frontend"
```
https://www.askvg.com/list-of-environment-variables-in-windows-xp-vista-and-7  
https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-R2-and-2012/cc755104(v=ws.11)#BKMK_examples  
https://ss64.com/nt/syntax-variables.html  

Windows Command Prompt open explorer at certain paths.

```bash
tar cvzf [Name of file].tgz --exclude .git [Name of repository]
tar cvzf backend.tgz --exclude .git backend
```
Tar your git repository folder without `.git` folder.

```cmd
control.exe /name Microsoft.NetworkAndSharingCenter /page Advanced
```
Open "Advanced Sharing Settings" from Command Prompt

```bash
git reset --hard
git fetch --all
git merge -s recursive -X theirs
# OR #
git reset --hard && git fetch --all && git merge -s recursive -X theirs
```
Fixing merging conflicts with multiple branches but generally branches other than master branch.

```bash
git rm -r --cached .
git add .
git commit -m ".gitignore is now working"
```
Make .gitignore file working again if not working.

```bash
git fetch --all
git reset --hard origin/master
git pull origin master
```
Git Fetch and Merge Master changes.

```bash
touch script
chmod 777 script
nano script
Put this to script “
#!/bin/bash
export PATH="/usr/local/bin:/usr/bin:/bin"
cd `dirname $0`
exec "$@"
“
env EDITOR=nano crontab -e
Put this to cron file "
*/1 * * * * /absolute/path/to/script/ command arg1 arg2 > /absolute/path/to/log
"
```
Bash Scrapy + Cron snippet.

```bash
# First replace the database in the "simplevagrant" repo folder and then run below commands.
vagrant halt && vagrant up && vagrant provision
# Or #
vagrant suspend && vagrant up && vagrant provision
# Or #
vagrant reload && vagrant provision
```
Update the Simpletire database in local Vagrant VM.

```bash
mkdir -m [permission] [Dir1path] [Dir2path]....
mkdir -pm [permission] [Dir1path] [Dir2path]....
mkdir -m 777 /var/www/frontend/app/webroot/cache_js /var/www/frontend/app/webroot/cache_css
mkdir -m 755 /var/www/frontend/app/webroot/cache_js /var/www/frontend/app/webroot/cache_css
mkdir -m 755 "/var/www/frontend/app/webroot/cache_js" "/var/www/frontend/app/webroot/cache_css"
mkdir -pm 755 "var/www/frontend/app/webroot/cache_js" "var/www/frontend/app/webroot/cache_css"
```
Create multiple directories with specified permissions.

```jira
{code:[LanguageName][Your code....]{code}
{code:php}echo "Hello World!!!";{code}
{code:sql}INSERT INTO rpm_simpletire.__settings VALUES (NULL, NOW(), NOW(), NOW(), 'frontend_cache_toggle', '0');{code}
```
Format the code in JIRA Tickets and Comments.

```bash
git checkout [FeatureBranch] # Only if you're not in feature branch
git pull origin master
git merge master
# OR #
git pull origin master && git merge master
# OR #
git checkout [FeatureBranch] && git pull origin master && git merge master
git checkout sim-3697 && git pull origin master && git merge master
```
Git Merge Master branch changes to feature branch.

```bash
start notepad++.exe "%HOMEDRIVE%%HOMEPATH%\.gitconfig"
subl "%HOMEDRIVE%%HOMEPATH%\.gitconfig"
git config --list --show-origin
git config --list > _baks_/gitconfig.list
gcpath=$(win2lin $HOME\\.gitconfig) && subl $gcpath
```
Git find the location of config file, configs that are already set and general path of global-config on Windows 64Bit OS.

```bash
git pull -s recursive -X theirs
git checkout master && git pull origin
git checkout master && git pull -s recursive -X theirs
git checkout master && git pull origin && git pull -s recursive -X theirs
```
Git Pull all updates with overwriting the Local changes recursively with Remote ones.

```bash
#!/bin/bash
# BakUntrackedFiles.sh
# au = !git add $(git ls-files -o --exclude-standard)
git ls-files --others --exclude-standard
CurrDir=$(PWD)
UntrackdFls=$(git ls-files --others --exclude-standard)
for file in $UntrackdFls
do
	mkdir -pm 755 "$CurrDir/_baks_"
	mv "$file" "$CurrDir/_baks_"
done
```
Backup all untracked files of specific Git Repo and move them to another directory.

```bash
git reset --hard HEAD
git fetch origin && git fetch
git merge -X theirs master
# Provide the merge comment and save with ESC + :wq + ENTER
```
Git Resolve Conflict by overwriting our source-code with theirs, escpecially when merging older branches with master.

```cmd
@echo off && start notepad++.exe "%WINDIR%\system32\drivers\etc\hosts" && exit
```
```bat
@echo off && start notepad++.exe "%WINDIR%\system32\drivers\etc\hosts" && exit
```
Open Windows Hosts File in Notepad++.

Git Add, Commit & Push only single file by path:
```bash
git add [path/to/file]
git add ~/[Path/after/home/]
git status
git commit -m "[Commit Note]" ~/[Path/after/home/]
git commit -m "[Commit Note]" [path/to/file]
git push origin [branchId]
```
