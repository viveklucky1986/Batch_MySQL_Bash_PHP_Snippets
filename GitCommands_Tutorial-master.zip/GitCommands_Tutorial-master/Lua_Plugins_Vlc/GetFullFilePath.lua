-- Place this file inside "%ProgramFiles%\VideoLAN\VLC\lua\extensions\" for accessibility by all Users
-- Place this file inside "%AppData%\VLC\lua\extensions\" for accessibility by current User

function descriptor()
    return {
        title = "URI2Clip";
        version = "1.0";
        author = "";
        url = '';
        shortdesc = "URI2Clip";
        description = "<div><b>Copy the media URI to the Windows clipboard</b></div>";
    }
end

function activate()
    local item = vlc.input.item()
    local uri = item:uri()
    uri = string.gsub(uri, '^file:///', '')
    uri = string.gsub(uri, '/', '\\')
    uri = string.gsub(uri, '%%20', ' ')
    strCmd = 'echo '..uri..' |clip'
    os.execute(strCmd)
end
