#### Adobe Flash Player for Firefox - NPAPI ####
https://fpdownload.macromedia.com/pub/flashplayer/latest/help/install_flash_player.exe  
#### Adobe Flash Player for Internet Explorer - ActiveX ####
https://fpdownload.macromedia.com/pub/flashplayer/latest/help/install_flash_player_ax.exe  
#### Adobe Flash Player for Opera and Chromium-based browsers - PPAPI ####
https://fpdownload.macromedia.com/pub/flashplayer/latest/help/install_flash_player_ppapi.exe  
